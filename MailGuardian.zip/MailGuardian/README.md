# MailGuardian OSINT — v0.24

Lokální forenzní nástroj pro porovnávání `.eml` souborů a hledání společné
infrastruktury (IP adresy, DKIM, User-Agent, styl Message-ID) mezi e-maily —
typicky když chceš zjistit, jestli tě někdo kontaktuje opakovaně z jiných adres.

Podrobný popis architektury a datového toku viz
[`docs/architecture.md`](docs/architecture.md).

Základ je čistě lokální (žádné API, žádný OAuth) - všechny online funkce
(AbuseIPDB, VirusTotal, WHOIS, DNS, Gmail sync) jsou volitelné a výchozí
vypnuté. Vezmeš `.eml` soubory, hodíš je do `emails/` (nebo je nahraješ
přes GUI, viz níž) a necháš nástroj spočítat skóre podobnosti.

## Quick Start

**Windows, bez příkazové řádky:** stáhni/rozbal projekt, dvojklikem spusť
`install.bat` (vytvoří zástupce na ploše), pak dvojklikem na zástupce
"MailGuardian" - otevře se webové GUI v prohlížeči. Podrobnosti níž
(sekce "GUI" a "Windows instalace").

**Příkazová řádka (Linux/macOS/Windows):**
```bash
cd MailGuardian
python3 main.py add emails/podezrely.eml
python3 main.py list
```

### Jak získat .eml e-mail

**Formát:** jen `.eml` (RFC 822/MIME - syrový text e-mailu se všemi
hlavičkami). Ne `.msg` (Outlook desktop formát), ne PDF export, ne
screenshot ani zkopírovaný text zprávy - ty neobsahují hlavičky
(Received řetězec, DKIM, SPF...), na kterých většina analýzy stojí.

**Velikost:** technicky bez pevného limitu, ale e-maily nad ~20MB
(typicky kvůli velké příloze) zaberou výrazně víc paměti a času - viz
`LARGE_FILE_WARNING_THRESHOLD_MB` v `modules/parser.py` a changelog
v0.22 (Python stdlib email parser spotřebuje cca 15× víc RAM, než je
velikost souboru - vlastnost stdlib, ne bug tohohle nástroje).

**Gmail** (webové rozhraní, ne appka):
1. Otevři podezřelý e-mail
2. Klikni na tři tečky vpravo nahoře v okně zprávy (⋮)
3. Vyber **"Zobrazit původní zprávu"** ("Show original")
4. V nové záložce klikni na **"Stáhnout původní zprávu"** ("Download Original")
5. Stáhne se `.eml` soubor - přesuň ho do složky `emails/`

**Outlook** (webový, outlook.com/office.com): tři tečky (⋯) u zprávy →
**"Zobrazit zdroj zprávy"** nebo rovnou **"Stáhnout"**.
**Outlook desktop** ukládá `.msg`, ne `.eml` - buď použij webovou verzi
podle kroků výše, nebo doplněk pro export do `.eml`.

**Apple Mail** (macOS): přetáhni e-mail myší na plochu/do Finderu -
uloží se rovnou jako `.eml`.

**Thunderbird:** pravé tlačítko na e-mail → **"Uložit jako" → "Soubor"**,
nebo přetažení myší do složky.

**Seznam.cz a další:** hledej v menu u zprávy **"Zobrazit zdroj"**,
**"Stáhnout originál"** nebo **"Export"**.

Případně použij `python3 main.py sync` pro přímé stažení z Gmailu (viz
sekce "Gmail sync" níž) - obchází ruční export úplně.

## Instalace

Jádro nepotřebuje nic instalovat — jen standardní knihovnu Pythonu 3.

```bash
cd MailGuardian
python3 main.py list
```

GUI (volitelné, viz sekce "GUI" níž) potřebuje navíc `streamlit` -
`pip install -r requirements-gui.txt`, nebo na Windows `install.bat`.

## Vývoj a testování

```bash
pip install -r requirements-dev.txt --break-system-packages

python3 -m pytest tests/ -v          # 161 testů, ~10-15s (vč. headless GUI smoke testů)
python3 -m ruff check .              # linting (jen skutečné chyby, ne styl)
python3 benchmark.py                 # výkonový benchmark (viz níže)
```

Testovací sada (`tests/`) pokrývá parser, scoring (Identity/Threat/
Confidence včetně brute-force testu 100% stropu - viz
`docs/architecture.md`), homoglyph detekci, MIME/Received chain analýzu,
DNS/WHOIS parsování (na ručně sestavených datech, ne živém provozu),
Case mode a Evidence mode. Fixture e-maily (`tests/fixtures/eml/`)
reprezentují různé generátory (Gmail, Exchange, Postfix) i scénáře
(newsletter, phishing, malware příloha, podvržený řetězec, minimální
hlavičky).

**Benchmark** (`benchmark.py`) měří čas a paměť pro rostoucí počet
e-mailů - reálně naměřená čísla z tohohle stroje (6 bodů, 10 až 3000
e-mailů, `python3 benchmark.py --counts 10,100,500,1000,2000,3000`):

| E-mailů | Parse+fingerprint | ms/e-mail | All-pairs porovnání | ms/pár | Peak RAM |
|---|---|---|---|---|---|
| 100 | 1,0 s | 10,3 | 0,25 s | 0,050 | 1,1 MB |
| 1000 | 11,3 s | 11,3 | 25,8 s | 0,052 | 8,0 MB |
| 2000 | 21,9 s | 11,0 | 103,4 s | 0,052 | 15,5 MB |
| 3000 | 34,4 s | 11,5 | 236,6 s | 0,053 | 23,1 MB |

Tempo na pár je pozoruhodně konstantní (0,050-0,053 ms) přes celý
naměřený rozsah - potvrzuje, že `similarity.compare()` je O(1) na pár a
celkový čas `compare-all` roste čistě z počtu párů (O(n²)), ne z toho, že
by jednotlivé porovnání s rostoucím n nějak zpomalovalo.

**5000 a 10 000 e-mailů nebylo prakticky proveditelné doměřit v jednom
běhu** (10 000 by při zachování tempa trvalo přes 45 minut jen na
`compare-all`) - dopočítáno matematicky z ověřeného tempa výše, ne
odhadem od oka:

| E-mailů | Párů celkem | Odhad `compare-all` | Odhad `parse+fingerprint` | Odhad celkem |
|---|---|---|---|---|
| 5 000 | ~12,5 milionu | ~10,8 min | ~57 s | ~11,8 min |
| 10 000 | ~50 milionů | ~43,3 min | ~113 s | ~45,2 min |

Parse+fingerprint škáluje lineárně (~11 ms/e-mail, konzistentní napříč
celým rozsahem). Porovnávání všech párů (`compare-all`, `case compare`)
škáluje kvadraticky - pro case složky v řádu tisíců e-mailů by se to
mohlo stát reálným úzkým hrdlem (u stovek e-mailů, což je typická
velikost case složky, žádný problém - pod půl minuty).

CI (`.github/workflows/ci.yml`) spouští testy a linting na Python 3.9-3.12
při každém push/PR, včetně headless GUI smoke testů (viz sekce GUI níž).

## GUI

`app.py` - lokální webové rozhraní postavené na [Streamlit](https://streamlit.io/),
pro ty, kdo nechtějí psát příkazy do terminálu. **Není to samostatná
reimplementace** - volá stejné funkce z `modules/*.py`/`main.py` jako CLI,
takže CLI a GUI nikdy nedávají rozdílný výsledek pro stejný vstup.

```bash
pip install -r requirements-gui.txt
streamlit run app.py
```
Otevře se `http://localhost:8501` (jen lokální rozhraní - Streamlit ve
výchozím nastavení naslouchá jen na `localhost`).

**5 stránek:** Přidat e-maily (nahrání přes prohlížeč), Databáze (přehled
uložených e-mailů), Porovnat (Identity Similarity mezi dvěma e-maily),
Case mode (včetně grafu vztahů přes `st.graphviz_chart`), Evidence Bundle.

**Nápověda přímo v GUI:** u každého nahrávání souboru je rozklikávací
"❓ Jak získám .eml soubor?" (Gmail/Outlook/Seznam postup, stejný obsah
jako sekce "Jak získat .eml z Gmailu" výše) - nemusíš kvůli tomu hledat
v README.

**Co GUI nedělá:** Gmail sync a živé sledování složky (`watch`) běží
zatím jen přes CLI - `python3 main.py sync` / `python3 main.py watch`.
GUI zobrazuje výsledky toho, co je v databázi, ale samo tyhle příkazy
nespouští na pozadí.

**Testováno headless přes `streamlit.testing.v1.AppTest`**
(`tests/test_app_gui.py`) - skutečné spuštění aplikace (ne jen syntax
check), simulace nahrání souboru a proklik přes všech 5 stránek,
ověření že se výsledek zapíše do databáze stejnou cestou jako CLI.
Testy se automaticky přeskočí, pokud `streamlit` není nainstalovaný
(GUI je volitelná nadstavba, ne jádro nástroje).

## Windows instalace (bez příkazové řádky)

Pro lidi, kteří nechtějí nic psát do terminálu:

1. Stáhni/rozbal projekt, dvojklikem spusť **`install.bat`**
   - zkontroluje Python (musí být 3.10+ a v PATH)
   - vytvoří virtuální prostředí (`venv`)
   - nainstaluje CLI i GUI závislosti
   - vytvoří zástupce **"MailGuardian"** na ploše
2. Dvojklik na zástupce na ploše (nebo na `Spustit MailGuardian.bat`
   v projektové složce) - otevře se GUI v prohlížeči
3. Pro CLI příkazy (`main.py add/case/sync...`) použij
   `Spustit MailGuardian CLI.bat` - otevře terminál s už aktivovaným
   virtuálním prostředím

**Žádný PyInstaller, žádné `.exe` balení, žádné druhé (tkinter) GUI** -
jen automatizace nastavení nad tím, co už funguje (Streamlit).

**Důležité upozornění:** `.bat`/`scripts/make_shortcut.ps1` soubory byly
napsané a pročtené ručně (syntaxe, žádná diakritika - klasický zdroj
`cmd.exe` chyb), ale vývojové prostředí, kde vznikly, nemá Windows, takže
je nešlo reálně spustit a ověřit. Vyzkoušej `install.bat` jako první krok
a nahlas přesné chybové hlášení, pokud něco nesedí.

## Použití

**Přidat e-maily do databáze:**
```bash
python3 main.py add emails/mail1.eml emails/mail2.eml
```

**Porovnat dva konkrétní e-maily:**
```bash
python3 main.py compare emails/mail1.eml emails/mail2.eml
```
Vypíše skóre do konzole a vygeneruje HTML report do `reports/`.

**Porovnat všechny e-maily v databázi navzájem (matice shody):**
```bash
python3 main.py compare-all
```

**Vypsat, co je uloženo v databázi:**
```bash
python3 main.py list
```

**Sledovat složku a automaticky zpracovat nové e-maily:**
```bash
# Jednorázová kontrola - zpracuje nové soubory v emails/ a porovná je se všemi ostatními
python3 main.py watch

# Průběžné sledování (kontrola každých 30s, dokud nezmáčkneš Ctrl+C)
python3 main.py watch --interval 30

# Vlastní práh pro upozornění/report (výchozí 30%) a jiná složka
python3 main.py watch --folder emails --interval 60 --threshold 40
```
Nové soubory se automaticky přidají do databáze a porovnají se všemi
existujícími e-maily. Pokud skóre přesáhne `--threshold`, vypíše se
upozornění a vygeneruje HTML report - žádné ruční `add`/`compare` pro
každou dvojici.

**Vytáhnout IOC z jednoho e-mailu:**
```bash
python3 main.py ioc emails/podezrely.eml
python3 main.py ioc emails/podezrely.eml --out iocs.json
```
Vrátí IP adresy, domény, URL, e-mailové adresy a hashe příloh -
bez porovnávání s čímkoliv dalším, jen z jednoho souboru.

**JSON export** se generuje automaticky vedle HTML reportu při každém
`compare` (i uvnitř `watch`) - `report_X_vs_Y.json` obsahuje identity
similarity, threat skóre obou e-mailů a jejich IOC ve strojově čitelném
formátu, pro navazující automatizaci.

**Vytvořit Evidence Bundle (pro archivaci/předání případu):**
```bash
python3 main.py bundle emails/mail1.eml emails/mail2.eml
python3 main.py bundle emails/mail1.eml emails/mail2.eml --out Case_001.zip
```
Vytvoří jeden `.zip` obsahující: oba originální `.eml`, HTML+JSON report,
`iocs.json`, audit log pro každý e-mail a `manifest.json` se SHA-256
hashem každého souboru v balíčku - takže lze kdykoliv později ověřit,
že se obsah od analýzy nezměnil.

## Confidence Score

Vedle Identity Similarity a Threat skóre se počítá i **Confidence** -
kolik kvalitních dat bylo k dispozici (kompletní Received řetězec, DKIM
podpis, Authentication-Results, ARC, netriviální Message-ID, HTML/MIME
tělo). Nízké Identity/Threat skóre s nízkou Confidence znamená "nemáme
dost dat, výsledek nemusí nic znamenat" - to samé skóre s vysokou
Confidence znamená "data jsou kvalitní, výsledek je spolehlivý".

## Jak se počítá skóre

Skóre (0–100 %) je vážený součet signálů — silné a vzácné signály mají
vyšší váhu než slabé/časté:

| Signál | Váha |
|---|---|
| Shodná primární IP (z Received) | 35 |
| Shoda v jiné IP z řetězce | 20 |
| Shodný DKIM (selector + doména) | 30 |
| Shodná DKIM doména (jiný selector) | 10 |
| Shodná X-Sender-IP / X-Originating-IP | 15 |
| Shodný User-Agent / X-Mailer | 10 |
| Shodný styl generování Message-ID | 10 |
| Shodná doména odesílatele | 5 |
| Shodné ASN u jiné IP (jen s nainstalovaným GeoIP) | 8 |
| Shodná cílová doména v odkazech (mimo běžné platformy) | 12 |
| Identická příloha (shodný SHA-256) | 20 |

Doména odesílatele u velkých poskytovatelů (gmail.com, seznam.cz, outlook.com...)
se u tohoto posledního signálu ignoruje, jinak by dva cizí lidi s gmailem
dostávali falešně vysoké skóre. Stejně tak odkazy na velké platformy
(google.com, youtube.com, bit.ly...) se do shody odkazů nepočítají.

Pokud nemáš nainstalovaný GeoIP modul (viz níže), signál "Shodné ASN" se
nepočítá ani do skóre, ani do maximálního možného počtu bodů - takže bez
GeoIP můžeš pořád dosáhnout 100 %, jen s méně signály k dispozici.

**Silné jednotlivé nálezy:** pokud se shoduje identická příloha, DKIM klíč
nebo primární IP, nástroj to označí jako "stojí za prověření" i když je
celkové procento nízké kvůli jinak odlišné infrastruktuře - typicky když
stejný útočník posílá ze dvou různých domén/serverů, ale se stejnou
přílohou malwaru.

**Důležité:** skóre je heuristika, ne důkaz. 60%+ znamená "stojí za bližší
prověření", ne "jistota".

## Struktura projektu

```
MailGuardian/
├── emails/              # sem házíš .eml soubory k analýze
├── database/
│   └── fingerprints.db  # SQLite - otisky + historie porovnání
├── reports/              # vygenerované HTML reporty
├── modules/
│   ├── parser.py         # čte .eml, extrahuje hlavičky/IP/DKIM/odkazy/přílohy/ARC/MIME
│   ├── fingerprint.py     # sestaví normalizovaný otisk (+ threat/confidence skóre, volitelně GeoIP)
│   ├── similarity.py      # Identity Similarity - podobnost DVOU e-mailů (původ/infra)
│   ├── threat.py           # Threat skóre - rizikovost JEDNOHO e-mailu
│   ├── confidence.py        # Confidence skóre - kolik kvalitních dat máme k dispozici
│   ├── evidence.py            # integrity manifest, verzování, deterministický JSON
│   ├── audit.py                 # audit trail (log kroků analýzy s časovými razítky)
│   ├── homoglyph.py               # detekce IDN homograph útoků a typosquattingu
│   ├── received_chain.py            # rozbor CELÉHO Received řetězce, ne jen první IP
│   ├── mime_fp.py                     # otisk MIME struktury (generátor/toolkit)
│   ├── message_id_fp.py                 # otisk Message-ID (entropie, generátor)
│   ├── html_fp.py                         # tracking pixely, formuláře, skryté prvky
│   ├── exporter.py                          # JSON export vedle HTML reportu
│   ├── ioc.py                                 # extrakce IOC (IP/domény/URL/e-maily/hashe)
│   ├── database.py                              # SQLite storage
│   ├── geoip.py                                   # volitelný GeoIP/ASN lookup (MaxMind GeoLite2)
│   ├── abuseipdb.py                                  # volitelný AbuseIPDB reputace IP (--abuseipdb)
│   ├── virustotal.py                                   # volitelný VirusTotal IP/URL/hash (--virustotal)
│   ├── whois_lookup.py                                   # volitelný WHOIS domény (--whois), syrový TCP:43
│   ├── dns_lookup.py                                       # volitelný DNS A/MX/TXT/NS (--dns), syrové UDP:53
│   ├── case.py                                               # Case mode - case složky, timeline, graf vztahů
│   ├── urls.py                                                 # extrakce odkazů, normalizace, mismatch detekce
│   ├── attachments.py                                            # SHA-256 hashe příloh
│   ├── logging_config.py                                           # debug logging (odděleno od audit trailu)
│   ├── gmail_connector.py                                            # volitelný Gmail sync (OAuth2, čistý urllib)
│   └── report.py                                                     # HTML report generátor
├── tests/                    # pytest sada (161 testů) + fixture .eml
│   └── fixtures/eml/
├── docs/
│   └── architecture.md       # popis modulů, datového toku, designových rozhodnutí
├── .github/workflows/ci.yml  # CI - testy + linting na Python 3.9-3.12
├── .streamlit/config.toml    # Streamlit GUI theme
├── scripts/make_shortcut.ps1 # vytvoří zástupce na ploše (voláno z install.bat)
├── main.py
├── app.py                    # Streamlit GUI (volitelné, viz sekce GUI)
├── benchmark.py
├── install.bat                        # Windows: jednorázová instalace + zástupce
├── Spustit MailGuardian.bat            # Windows: spustí GUI dvojklikem
├── Spustit MailGuardian CLI.bat        # Windows: terminál s aktivovaným venv
├── pytest.ini
├── pyproject.toml            # ruff/black konfigurace
├── requirements.txt
├── requirements-dev.txt
├── requirements-gui.txt      # streamlit, pandas (jen pro GUI)
├── config.ini.example
├── LICENSE
├── CONTRIBUTING.md
├── SECURITY.md
└── .gitignore
```

## Dvě oddělená skóre

Od v0.4 nástroj počítá dvě nezávislá čísla, protože odpovídají na jiné otázky:

- **Identity Similarity Score** (`similarity.py`) — "jsou tyhle dva e-maily
  ze stejného zdroje?" Počítá se při `compare`/`compare-all`, potřebuje
  dva e-maily. Vysoké číslo neznamená nebezpečný obsah, jen společný původ.
- **Threat skóre** (`threat.py`) — "jak rizikový je tenhle jeden e-mail?"
  Počítá se hned při `add`/`watch`, nepotřebuje nic porovnávat. Sleduje
  SPF/DKIM/DMARC selhání, mismatch v odkazech, homoglyph/typosquat domény
  a podezřelé přípony příloh.

Dřív se tohle míchalo do jednoho čísla, což bylo matoucí - dva e-maily
mohly mít nízkou podobnost původu, a přitom být oba vysoce rizikové
(typicky: stejný útočník, různá infrastruktura pro každou vlnu útoku).

## Co report navíc obsahuje

- **SPF/DKIM/DMARC vysvětlení** — lidsky čitelný popis, co daný verdikt znamená
  (ne jen "fail", ale proč je to podezřelé)
- **Odkazy** — všechny URL z HTML i textové části, s upozorněním na mismatch
  (zobrazený text vypadá jako jedna doména, skutečný cíl je jiný - klasický
  phishing trik)
- **Přílohy** — název, typ, velikost a SHA-256 každé přílohy (pro ruční
  dohledání ve VirusTotal/MalwareBazaar, nástroj sám nikam hash neposílá)

## GeoIP / ASN (volitelné)

Modul `geoip.py` doplní k primární IP zemi, město a ASN (síťového
poskytovatele). Je čistě volitelný - bez něj nástroj funguje úplně stejně,
jen bez jednoho doplňkového signálu.

**Instalace:**

```bash
pip install geoip2 --break-system-packages
```

**Stažení databází** (zdarma, vyžaduje registraci na MaxMind):

1. Zaregistruj se na https://www.maxmind.com/en/geolite2/signup
2. Stáhni `GeoLite2-City.mmdb` a `GeoLite2-ASN.mmdb`
3. Umísti oba soubory do kořene projektu (vedle `main.py`)

Poté se GeoIP automaticky použije při každém `add`/`compare` - žádná
další konfigurace není potřeba. Pokud soubory chybí, nástroj to potichu
přeskočí (žádná chyba, jen o jeden signál míň).

## AbuseIPDB (volitelné)

Modul `abuseipdb.py` doplní reputaci primární IP - kolik hlášení zneužití
má a s jakou "confidence" (jistotou). Na rozdíl od GeoIP jde o **živé
síťové volání s denním limitem** (free tier ~1000 dotazů/den), takže se
NEspouští automaticky - jen s `--abuseipdb` flagem u `add`/`compare`/
`watch`/`bundle`.

**Nastavení API klíče** (zdarma na https://www.abuseipdb.com/register):

```bash
export ABUSEIPDB_API_KEY="tvůj_klíč"
```
nebo vytvoř `config.ini` v kořeni projektu:
```ini
[abuseipdb]
api_key = tvůj_klíč
```

**Použití:**
```bash
python3 main.py add emails/podezrely.eml --abuseipdb
python3 main.py compare emails/mail1.eml emails/mail2.eml --abuseipdb
```

Výsledky se cachují lokálně (`database/abuseipdb_cache.db`, 7 dní), aby
se stejná IP nedotazovala opakovaně a nešel zbytečně dolů denní limit.

**Důležité k váze ve skóre:** reputace IP se do Threat skóre počítá jen
při vysoké jistotě (≥50 %) A dostatku hlášení (≥3), a i tak jen s nízkou
váhou (12 bodů z celkových ~215) - samotná reputace IP totiž není silný
důkaz proti konkrétnímu odesílateli. Velcí poskytovatelé (Gmail,
Microsoft 365) mají IP rozsahy, které se v databázi mohou objevit kvůli
zneužití jednotlivých účtů, ne proto, že by celá služba byla nebezpečná.
Nález se navíc vždy zobrazí s touhle výhradou, ne jako definitivní
verdikt. Bez `--abuseipdb` flagu funguje Threat skóre přesně stejně
jako dřív - jen bez tohohle jednoho doplňkového signálu.

## VirusTotal (volitelné)

Modul `virustotal.py` doplní reputaci přes VirusTotal API v3 - **primární
IP, odkazy v e-mailu a hashe příloh** (kolik enginů je označilo jako
malicious/harmless). Stejný vzor jako AbuseIPDB - výchozí vypnuto,
`--virustotal` flag, lokální cache (30 dní - VT reputace se mění
pomaleji než AbuseIPDB hlášení).

**Nastavení API klíče** (zdarma na https://www.virustotal.com/gui/join-us):
```bash
export VIRUSTOTAL_API_KEY="tvůj_klíč"
```
nebo `config.ini`:
```ini
[virustotal]
api_key = tvůj_klíč
```

**Použití:**
```bash
python3 main.py add emails/podezrely.eml --virustotal
python3 main.py compare emails/mail1.eml emails/mail2.eml --abuseipdb --virustotal
```

Kromě IP se `--virustotal` dotáže i na první 3 unikátní odkazy z e-mailu
a hash prvních 5 příloh - capped, aby jeden e-mail s desítkami odkazů
nezablokoval rate limit na dlouho.

**Rate limit:** VT Public API dovoluje jen 4 dotazy/minutu (přísnější než
AbuseIPDB), sdílené napříč IP/URL/hash dotazy. Modul mezi dvěma
skutečnými (necachovanými) dotazy čeká ~15 vteřin. Cache hit tohle
čekání přeskočí.

**Váha ve skóre:** reputace IP 10 bodů (mírnější práh: ≥5 malicious hlasů
A ≥10% skóre). Detekce na konkrétní **URL má vyšší váhu (22 bodů)** a na
**hash přílohy nejvyšší (28 bodů)** - shoda hashe je téměř jistá shoda
konkrétního souboru, mnohem přesnější signál než reputace celé IP
(kterou může sdílet tisíce jiných domén na stejném hostingu).

## WHOIS a DNS (volitelné)

Moduly `whois_lookup.py` a `dns_lookup.py` doplní stáří domény
odesílatele, registrara, nameservery (WHOIS) a MX/TXT/NS/A záznamy
(DNS) - `--whois`/`--dns` flag na `add`/`compare`/`watch`/`bundle`/
`case add`. Na rozdíl od AbuseIPDB/VirusTotal jde o syrové TCP/UDP
protokoly (WHOIS port 43, DNS port 53), ne HTTP API - **žádný API klíč
není potřeba**.

```bash
python3 main.py add emails/podezrely.eml --whois --dns
```

**Důležité omezení:** tyhle dva moduly nikdy nebyly ověřené proti
skutečnému DNS resolveru/WHOIS serveru - prostředí, kde vznikly, nemá
přístup na porty 43/53. Parsovací logika (DNS wire formát podle RFC 1035
včetně komprese jmen, WHOIS textové vzory) je důkladně otestovaná na
ručně sestavených datech, ale samotnou síťovou komunikaci si musíš
vyzkoušet a případně doladit sám - třeba proti pár známým doménám a
porovnat výsledek s `dig`/`whois` v terminálu.

WHOIS parsování je heuristické (regex na běžné vzory) - různé registry
mají různý formát textové odpovědi, takže přesnost se liší podle TLD.
Modul zná přímé WHOIS servery pro `.com`/`.net`/`.org`/`.cz`, pro
ostatní TLD se nejdřív zeptá IANA na referral.

**Váha ve skóre:** doména mladší 30 dní přidává do Threat skóre 18 bodů
(`young_domain`) - čerstvě zaregistrovaná doména je klasický phishing
indikátor (útočník registruje doménu těsně před kampaní), ale není to
jednoznačný důkaz - i legitimní firmy zakládají nové domény pro
kampaně/produkty.

**DNSSEC** (informační, ne skórovaný signál) - `--dns` teď navíc přečte
AD bit (Authenticated Data, RFC 4035) z hlavičky DNS odpovědi. Nastavuje
ho validující resolver sám, když už DNSSEC podpisový řetězec ověřil za
nás - jde tedy o "resolver říká, že tahle odpověď je DNSSEC-ověřená",
ne o vlastní kryptografické ověřování (to by vyžadovalo stahovat
DNSKEY/RRSIG záznamy a verifikovat podpisy samostatně, výrazně víc kódu
a riziko chyby v kryptografii bez knihovny - a porušilo by to filozofii
"0 závislostí"). **Záměrně se to nepočítá do Threat skóre** - chybějící
DNSSEC je extrémně slabý/šumový signál (drtivá většina i naprosto
legitimních malých domén ho nemá nastavený), přidávalo by to falešné
poplachy víc, než by pomáhalo. Zobrazuje se jen v reportu jako
orientační informace.

## Gmail sync (volitelné, readonly)

Modul `gmail_connector.py` umí stáhnout nové e-maily přímo z Gmailu -
`gmail.readonly` scope, nikdy nic nemaže ani neoznačuje. Napsáno čistě
přes stdlib (`urllib`, `http.server`) - **žádná externí knihovna**,
stejná filozofie jako zbytek projektu (viz `docs/architecture.md`).
OAuth2 authorization code flow s krátkodobým lokálním HTTP serverem na
zachycení redirectu (Google zrušil "out-of-band" flow kolem 2022, takže
tohle je aktuální podporovaný způsob pro desktop nástroje).

**Nastavení** (jednorázově):

1. V [Google Cloud Console](https://console.cloud.google.com/) vytvoř
   projekt, zapni Gmail API, vytvoř OAuth client ID typu **"Desktop app"**.
2. Zkopíruj `config.ini.example` na `config.ini`, vyplň `client_id`/
   `client_secret` do sekce `[gmail]`.
3. Autorizuj přístup (otevře se prohlížeč):
   ```bash
   python3 main.py gmail-auth
   ```
   Token se uloží do `token.json` (v `.gitignore`, nikdy necommitovat).

**Použití:**
```bash
python3 main.py sync                          # výchozí query/limit z config.ini
python3 main.py sync --query "has:attachment newer_than:90d" --max 100
python3 main.py sync --abuseipdb --virustotal  # + enrichment nově stažených
```

**Bezpečnostní pojistky:**
- `max_allowed` v `config.ini` (výchozí 1000) - `--max` nad tuhle hodnotu
  se rovnou odmítne, ať tě neomylem nepošle stáhnout celou schránku
- Doporučení pro úplně první sync: krátké okno + nízký limit (`newer_than:30d`,
  `--max 50`) - první běh je nejrizikovější (OAuth, DB, fingerprinty,
  případný enrichment), ať máš možnost zkontrolovat výsledek na menším vzorku
- Deduplikace podle `message_id` v samostatné `gmail_state` tabulce -
  nezávisí na Gmailových `is:unread`/`label:` příznacích, takže opakovaný
  `sync` nikdy nestáhne stejnou zprávu dvakrát

**Gmail query** je plnohodnotný vyhledávací jazyk - `has:attachment`,
`from:podezrelý@domena.com`, `subject:faktura`, kombinace přes `OR`/`AND`
apod. (stejná syntaxe jako ve webovém rozhraní Gmailu).

**Co tenhle sandbox nemohl ověřit:** skutečné přihlášení do Google účtu
v prohlížeči a živé API volání - otestováno s mockovaným `urlopen` a
dependency-injected Gmail API funkcemi (`tests/test_gmail_connector.py`,
20 testů). Lokální OAuth redirect server JE otestovaný skutečným HTTP
požadavkem na localhost (žádná externí síť potřeba). Před ostrým
použitím doporučuju `gmail-auth` a první `sync --max 5` vyzkoušet ručně.

## Case mode

Pro analýzu celé kampaně/incidentu (víc než dva související e-maily)
místo jednotlivých párů. Na rozdíl od hlavní `emails/`/`database/` (jedna
sdílená databáze pro cokoliv, co kdy analyzuješ) je case složka
**soběstačná** - obsahuje vlastní kopie originálů, vlastní databázi,
vlastní reporty. Dá se celá zabalit/přesunout/archivovat jako jeden kus.

```
cases/<jméno>/
├── original/       # kopie přidaných .eml (case vlastní svoji kopii)
├── reports/        # HTML+JSON reporty z 'case compare'
├── case.db         # SQLite - stejné schéma jako hlavní databáze
├── iocs.json       # sloučené IOC ze VŠECH e-mailů v case
├── timeline.json   # chronologický přehled podle Date hlavičky
└── manifest.json   # integrity manifest celého case (SHA-256 všeho)
```

**Použití:**
```bash
python3 main.py case create phishing_july

python3 main.py case add phishing_july mail1.eml mail2.eml mail3.eml
python3 main.py case add phishing_july mail4.eml --abuseipdb --virustotal

python3 main.py case compare phishing_july
python3 main.py case compare phishing_july --threshold 20

python3 main.py case report phishing_july

python3 main.py case graph phishing_july
python3 main.py case graph phishing_july --threshold 20

python3 main.py case list

python3 main.py case suggest emails/novy_podezrely.eml
python3 main.py case suggest emails/novy_podezrely.eml --threshold 20
```

`case add` case automaticky vytvoří, pokud ještě neexistuje - `create`
je jen pro explicitní založení předem. `case compare` porovná všechny
e-maily v case navzájem (jako `compare-all`, ale v izolované case
databázi) a vygeneruje reporty pro nálezy nad prahem. `case report`
vytvoří `iocs.json` (sloučené IOC), `timeline.json` (chronologicky podle
Date hlavičky - i s neplatným/chybějícím datem, který jde na konec bez
pádu) a `manifest.json` s integrity hashem každého souboru v case.

`case graph` vygeneruje `graph.dot` (Graphviz formát) - uzly jsou
e-maily (barva podle Threat skóre), hrany jsou Identity Similarity nad
prahem (tloušťka podle skóre). Vypíše i textové shrnutí shluků
(souvisejících skupin e-mailů) bez nutnosti graf vůbec vykreslovat.
Vykreslení: `dot -Tpng cases/<jméno>/graph.dot -o graph.png` (potřebuje
nainstalovaný Graphviz), nebo vlož obsah `.dot` souboru na
https://dreampuf.github.io/GraphvizOnline/.

`case suggest` je **dry-run** - ukáže, do kterého existujícího case by
e-mail sedl podle Identity Similarity, nic nemění. Užitečné před ručním
`case add`, když si nejsi jistý, kam mail patří.

**Automatické přiřazení do Case** (`--auto-case` flag na `add`/`sync`):
```bash
python3 main.py add emails/podezrely.eml --auto-case
python3 main.py sync --auto-case
```
Po přidání e-mailu zkusí najít nejlepší case podle Identity Similarity
(zahrnuje i shodu IOC - sdílená IP/doména/hash přílohy jsou už součástí
Identity signálů, žádná zvláštní IOC logika navíc):
- **Přesně jeden case sedí nad prahem** → e-mail se tam zkopíruje a zpracuje
- **Žádný case nesedí** → automaticky se založí nový (`auto_<datum>_<hash>`)
  - je to o vědomé rozhodnutí "radši nový case než ztracený e-mail" - a
    protože nově založený case se hned stává kandidátem pro DALŠÍ podobné
    e-maily, chová se to samo-omezujícím způsobem (druhá vlna stejné
    kampaně už spadne do prvního auto-case, ne založí třetí)
- **Sedí do víc case složek najednou** → nic se nerozhoduje automaticky,
  jen se vypíšou kandidáti a instrukce pro ruční `case add`

Case a hlavní `emails/`/`database/` workflow jsou úplně nezávislé -
stejný `.eml` můžeš mít přidaný v case i v hlavní databázi zároveň,
nijak se neovlivňují.

## Poznámka k licenci / původu kódu

Parser je vlastní implementace nad standardní knihovnou `email` (ne převzatá
z jiného projektu), takže žádné licenční omezení. Při rešerši existujících
nástrojů (EmailAnalyzer, Kain, eml_analyzer...) jsem nenašel žádný, co by
řešil přímo *porovnání dvou e-mailů* — existující nástroje umí jen analýzu
jednoho souboru najednou.

## Plánovaná rozšíření (v1.0+)

- **Plná DNSSEC verifikace** — zatím jen AD bit z odpovědi resolveru
  (viz v0.19), ne vlastní kryptografické ověření DNSKEY/RRSIG řetězce;
  vyžadovalo by balíček `cryptography` a výrazně víc kódu, zatím
  neplánováno
- **Signed report** (Ed25519) — `report.json` + `report.sig`, pro sdílení
  reportů mezi lidmi/týmy s ověřitelnou integritou; vyžaduje balíček
  `cryptography`, zatím jen navrženo, ne implementováno
- **YARA modul** — vlastní pravidla na přílohy/HTML obsah; vyžaduje
  `yara-python` (C rozšíření), plánováno otestovat přímo u tebe
- **Type hints** — postupně přidat typové anotace přes celý kód pro
  lepší IDE podporu; zatím žádné, netýká se funkčnosti
- **Konfigurační soubor** pro váhy scoringu/TTL/timeouty — zatím jsou
  natvrdo v kódu (kromě Gmail sekce, viz v0.16); odloženo, protože
  externalizace vah bez pečlivého přepočtu MAX_SCORE by mohla znovu
  zavést stejnou třídu bugu popsanou v `docs/architecture.md`
  (dynamický jmenovatel)

Formát fingerprintů a JSON exportu (viz `fingerprint_version`/
`scoring_version` v manifestu) je od v0.9 zmrazený - další verze mohou
tato čísla zvýšit, pokud změna ovlivní výsledek stejného vstupu, ale
existující pole se nebudou přejmenovávat/mazat bez dobrého důvodu.
AbuseIPDB (v0.10), VirusTotal (v0.11), Case mode + Explainability
(v0.12), WHOIS/DNS (v0.13), VT URL/hash + graf vztahů (v0.14), testy/CI
(v0.15), Gmail sync (v0.16), auto-case-assignment (v0.17), GUI/Windows
instalace (v0.18) a DNSSEC AD-bit (v0.19) integrace tohle pravidlo
dodržely (jen nová pole, nic přejmenovaného/smazaného). Verze zůstávají
na 1/1.

Plugin architektura (přesun modulů do jednotného `{findings, score,
metadata}` rozhraní) je zatím záměrně odložená - se ~24 moduly, kde má
každý jasně odlišný tvar výstupu (párové porovnání vs. per-email
hodnocení vs. syrová extrakce), by násilné sjednocení teď spíš uškodilo
čitelnosti, než pomohlo. Dává smysl znovu zvážit, až poroste počet
volitelných/zaměnitelných analyzátorů.

## Changelog

**v0.24 - Rozšířená nápověda: formát, velikost, víc poskytovatelů**
- Nápověda v GUI i README rozšířena o **podporovaný formát** (jen
  `.eml`, explicitně NE `.msg`/PDF/screenshot - ty neobsahují hlavičky,
  na kterých většina analýzy stojí) a **orientační velikostní práh**
  (~20MB, s odkazem na `LARGE_FILE_WARNING_THRESHOLD_MB` a v0.22
  changelog, kde je vysvětlené proč) - hodnota v GUI se dosazuje ze
  skutečné konstanty v `modules/parser.py`, ne je zvlášť natvrdo
  napsaná (jinak by se časem rozjely)
- **Bug nalezený vlastním testem hned při psaní:** první verze textu
  referencovala `LARGE_FILE_WARNING_THRESHOLD_MB` jako holé jméno v
  `app.py`, ale ta konstanta žije v `modules/parser.py` - `NameError`
  při skutečném spuštění GUI (ne jen syntax check, který na tohle
  nemůže přijít). Opraveno na `eml_parser.LARGE_FILE_WARNING_THRESHOLD_MB`
- Přidány kroky pro **Apple Mail** a **Thunderbird** (přetažení myší
  rovnou uloží `.eml`), doplněno varování o `.msg` u Outlook desktop
- 1 nový test ověřující, že se text formátu/velikosti skutečně zobrazí
  A že se hodnota prahu opravdu dosadila (ne zůstala jako placeholder).
  Celkem 161 testů v sadě

**v0.23 - Nápověda přímo v GUI**
- Přidána rozklikávací nápověda "❓ Jak získám .eml soubor?" (Gmail,
  Outlook webový i desktopový, Seznam.cz a další, plus odkaz na fixture
  ukázky) na **všechna 4 místa** v GUI, kde se něco nahrává (Přidat
  e-maily, Case mode → přidat do case, Case mode → navrhnout case,
  Evidence Bundle) - na žádost uživatele, ať nemusí kvůli základnímu
  postupu hledat v README. Sdílená `render_eml_help()` funkce, ne 4×
  nekonzistentně opakovaný text
- Ověřeno reálným spuštěním GUI (`streamlit.testing.v1.AppTest`), ne
  jen vizuální kontrolou kódu - včetně případu, kdy je nápověda uvnitř
  podmíněné větve (case add záložka se zobrazí, jen když existuje aspoň
  jeden case) - test si case založí, ať ověří i tuhle větev, ne jen tu
  triviální nepodmíněnou
- 3 nové testy (`tests/test_app_gui.py`). Celkem 160 testů v sadě

**v0.22 - Systematický audit + attachment paměťový DoS**
- **Audit stejné třídy chyby jinde** (navazuje na v0.20/v0.21 path
  traversal nálezy) - prošel jsem všechna místa, kde uživatelský vstup
  potenciálně staví cestu k souboru: `generate_eml_filename()` (Gmail) je
  čistě datum+hash, bez textu z e-mailu - bezpečné; CLI `--out` u
  `bundle`/`ioc` je záměrné chování (uživatel řídí vlastní stroj, ne
  zranitelnost); všech 5 `st.file_uploader` míst v GUI prochází přes
  opravenou `save_uploaded_file()`. Žádný další nález, ale stálo za to
  ověřit systematicky, ne čekat na náhodu
- **Attachment paměťový DoS - nalezeno měřením, ne odhadem.** Peak RAM
  roste ~15x rychleji než velikost `.eml` souboru (změřeno: 1/10/50MB
  příloha → 15/152/738MB peak). Zjištěno přesné místo: multiplikace
  vzniká UVNITŘ `email.message_from_bytes()` (Python stdlib), ne v
  našem kódu (`extract_attachments()` k peaku nic nepřidává) - ověřeno
  krokovým měřením `tracemalloc` mezi jednotlivými fázemi parsování.
  Nejde to "opravit" bez architektonické změny (přechod na starší
  `compat32` policy by rozbil strukturované parsování hlaviček, na
  kterém stojí zbytek projektu), takže místo opravy: transparentní
  `WARNING` log nad `LARGE_FILE_WARNING_THRESHOLD_MB` (20MB) s odhadem
  očekávané spotřeby RAM. Záměrně NEBLOKUJE zpracování - obří příloha
  může být legitimní důkaz, který chce analytik prohlédnout, jen o
  spotřebě paměti dopředu ví
- **Zip bomb přes Evidence Bundle - prověřeno, čisté.** `cmd_bundle`
  jen VYTVÁŘÍ zip z vlastních důvěryhodných souborů, nikde v kódu se
  nerozbaluje uploadovaný/přijatý zip (přílohy se jen hashují, nikdy
  neotevírají). Vektor neexistuje
- 2 nové testy (`tests/test_parser_fuzz.py`) - warning nad prahem,
  žádný warning pod prahem. Celkem 157 testů v sadě

**v0.21 - Bezpečnostní/robustnostní kolo: path traversal v GUI uploadu, MIME DoS, poškozená databáze**
- **Path traversal přes název nahrávaného souboru v GUI** - `uploaded_
  file.name` je string, kterým se prohlížeč klienta chlubí, ne
  důvěryhodný vstup. Bez sanitizace by `../../../tmp/evil.eml` jako
  název nahrávaného souboru zapsal MIMO `emails/uploaded/`. Ověřeno
  end-to-end (skutečně vytvořený soubor v `/tmp`, selhalo jen náhodou u
  prvního testu kvůli neexistujícímu cíli - ne díky ochraně). Opraveno
  v `app.py` `save_uploaded_file()` (`os.path.basename()` + extra
  kontrola na holé `.`/`..`, protože basename() samo o sobě `..` beze
  změny propustí)
- **RecursionError → DoS na extrémně hluboce vnořeném MIME** - MIME
  fuzzing (~1000+ úrovní vnoření) našel pád přímo uvnitř stdlib
  `email.message_from_bytes()`, tedy DŘÍV, než se spustí jakýkoliv náš
  kód - hloubkový limit přidaný do `mime_fp.py` (`MAX_MIME_DEPTH=50`,
  zachytí do 500 úrovní) tenhle konkrétní pád nezachytí. Přidána
  `parser.UnparseableEmailError` (zachytává `RecursionError` kolem
  `message_from_bytes()`)
- **Vedlejší, závažnější nález při opravě výše:** `_process_file()`
  původně volalo `sys.exit()` na chybu - v CLI kontextu neškodné, ale
  když `app.py` volá `cli._process_file()` přímo (bez `main()`/
  `args.func()` obalu), `sys.exit()` uvnitř Streamlit skriptu vede k
  **zaseknutí celého GUI běhu na timeout**, ne k hezké chybě - ověřeno
  reálně (`AppTest.run()` timeoutovalo po 30s na přesně tomhle útoku).
  Opraveno: `_process_file()` už `sys.exit()` nevolá vůbec, jen
  propouští výjimku - CLI ji zachytává centrálně v `main()`, GUI ji
  zachytává na všech 4 vlastních volacích místech (`st.error()` místo
  pádu/zaseknutí). `cmd_add` navíc nezastaví celou dávku kvůli jednomu
  špatnému souboru - přeskočí ho a pokračuje s dalšími
- **Odolnost proti poškozené databázi** - `fingerprint_json` sloupec
  deserializovaný přímo do `similarity.compare()`/`threat.assess()`,
  které bezpodmínečně předpokládají dict. Poškozený/upravený řádek
  (ruční zásah, bitová chyba na disku, útočník s přístupem k souboru
  databáze) by se dřív dostal jako ne-dict hodnota tiše dál a spadl by
  matoucím způsobem hluboko ve scoringu. Přidána validace u zdroje
  (`database._load_fingerprint_json()`) - poškozený záznam se zaloguje
  a nahradí prázdným dictem, zbytek běhu pokračuje
- **Ověřeno, ne jen tvrzeno:** HTML injection do reportů (`<script>`,
  `onerror=`, `onload=` v Subject/HTML těle/URL) - skutečně vygenerován
  report se zlomyslným obsahem, potvrzeno `&lt;`/`&gt;`/`&quot;`
  escapování v HTML výstupu. Jméno odesílatele (display name) se navíc
  vůbec neukládá (`parseaddr()[1]` bere jen adresu) - bezpečné by
  design, ne díky escapování
- **Zvažováno, ale záměrně NEimplementováno:** obranné typové kontroly
  uvnitř `similarity.py`/`threat.py`/`confidence.py` proti ne-dict
  vstupu - `fp` parametr těchhle funkcí je vždycky interně sestavený
  dict, nikdy přímo nedůvěryhodný vstup (na rozdíl od DB deserializace
  výše, kde reálná cesta ven existuje). Přidávat obranu tam, kudy
  neexistuje útočná cesta, jen zvyšuje složitost bez bezpečnostního
  přínosu
- 10 nových testů (`tests/test_parser_fuzz.py` ×2 hluboké zanoření,
  `tests/test_mime_and_chain.py` ×1 hloubkový limit, `tests/test_app_gui.py`
  ×1 GUI zaseknutí, `tests/test_database_resilience.py` ×5). Celkem
  155 testů v sadě

**v0.20 - Bezpečnostní oprava: path traversal přes jméno case**
- **Nalezeno vlastní bezpečnostní kontrolou** (ne fuzzingem) - `case
  create '../../tmp/evil'` vytvořilo adresář KDEKOLIV, kam měl proces
  právo zapisovat, ne jen uvnitř `cases/`. Ověřeno end-to-end (skutečně
  vytvořený adresář v `/tmp` mimo projekt), ne jen teoreticky odvozeno
- Přidána `case_module.InvalidCaseName` výjimka + validace v
  `case_dir()` (centrální bod, kterým procházejí všechny ostatní case
  funkce - `case_db_path`, `create_case`, `case_exists` atd. validaci
  zdědily automaticky). Odmítá: `..`/`.` komponenty, absolutní cesty,
  oddělovače cesty (`/` i `\` - **explicitně oba, nezávisle na
  platformě**, ne přes `os.sep`/`os.altsep`, protože jméno vytvořené na
  Linuxu s `\` by na Windows bylo nebezpečné, i když by ho tehdejší
  kontrola přes `os.sep` propustila), prázdné jméno, nulový bajt
- Hezké zpracování chyby na obou rozhraních - CLI (`cmd_case` dispatcher
  odchytí a vypíše `[!] ...` místo syrového tracebacku) i GUI (`st.error`
  v Case mode stránce, ověřeno skutečným proklikem přes
  `streamlit.testing.v1.AppTest` se zlomyslným jménem v textovém poli -
  žádná neošetřená výjimka, nic se nevytvořilo)
- 20 nových testů (`tests/test_case_name_security.py`) - parametrizované
  přes 13 zlomyslných a 5 legitimních jmen, plus dva end-to-end testy
  ověřující, že ani `create_case()` se zlomyslným jménem nikdy nezapíše
  mimo `CASES_ROOT`. Celkem 145 testů v sadě

**v0.19 - DNSSEC AD-bit, fuzzing, ověřený benchmark**
- **DNSSEC (jednoduchá varianta)** - `dns_lookup.py` teď čte AD bit
  (Authenticated Data, RFC 4035, bit 10 v DNS hlavičce) z odpovědi
  resolveru. NE vlastní kryptografické ověření DNSKEY/RRSIG řetězce -
  vědomé rozhodnutí, plná verze by vyžadovala balíček `cryptography` a
  výrazně víc kódu s rizikem chyby v kryptografii. Otestováno na ručně
  sestavených paketech (stejný vzor jako zbytek DNS testů) - odpověď s/
  bez AD bitu, agregace přes `is_dnssec_authenticated()`. Zobrazuje se
  jen informačně v reportu, **záměrně se nepočítá do Threat skóre**
  (chybějící DNSSEC je příliš šumový signál - i drtivá většina
  legitimních malých domén ho nemá)
- **Property-based + mutation-based fuzzing parseru**
  (`tests/test_parser_fuzz.py`, `hypothesis`) - **skutečně spuštěno, ne
  jen napsáno**: 1500 čistě náhodných bajtů, 200+100 cílených
  hypothesis příkladů (uťaté adresové hlavičky, rozbitá MIME struktura),
  a 10 000 mutací (bit-flip/delete/insert/truncate/duplicate-line) nad
  reálnými fixture soubory - **našlo 2 nezávisle reprodukované pády**:
  1) uťatá adresová hlavička (`From: Jméno <` bez ukončení) vyhazovala
     `IndexError` přímo z cpython stdlib parseru
     (`email._header_value_parser.get_angle_addr`), 2) RFC 5322 group
     adresa (`undisclosed-recipients:;`) vyhazovala `AttributeError`
     (`'Group' object has no attribute 'local_part'`) ze stejného
     volání, ale JINÝ typ výjimky - proto první oprava (vyjmenované
     typy) nestačila, musel se rozšířit na `except Exception` se
     zdůvodněným komentářem (bezpečný fallback na syrový text hlavičky,
     vše se loguje). Obě opravy ověřené 10 000 dalšími mutacemi bez
     dalšího pádu
- **Třetí bug, jiná třída** - mutation fuzzing našel i pád v
  `received_chain.py`: odečet dvou `datetime` objektů, kde jeden byl
  timezone-aware a druhý naive (RFC 2822 `-0000` = "neznámý offset" dá
  naive datetime, `+0200` dá aware - reálný scénář u poškozených/
  spamových generátorů, ne jen fuzzing artefakt), vyhazoval `TypeError`,
  který existující `except ValueError:` nezachytával. Opraveno
  rozšířením na `except (ValueError, TypeError):`
- **Benchmark ověřen na reálných datech, ne převzat** - 6 měřených bodů
  (10 až 3000 e-mailů, dřívější benchmark šel jen do 1000), potvrzeno
  konstantní tempo ~0,052 ms/pár napříč celým rozsahem. 5000/10000
  nebylo prakticky proveditelné doměřit v jednom běhu (10k by trvalo
  ~45 minut) - dopočítáno matematicky z ověřeného tempa, ne odhadnuto
- 6 nových testů (`test_parser_fuzz.py` ×5, `test_mime_and_chain.py`
  regresní test na naive/aware datetime), celkem 125 v sadě

**v0.18 - Streamlit GUI + Windows instalace**
- Přidán `app.py` - lokální webové GUI (Streamlit), 5 stránek (Přidat,
  Databáze, Porovnat, Case mode + graf vztahů, Evidence Bundle). Volá
  stejné funkce jako CLI, žádná duplicitní logika. Vzniklo sloučením
  dvou rozdvojených vývojových linií projektu (viz níž) - GUI a Windows
  launchery z jedné, delší testovaná CLI historie (Gmail sync,
  auto-case-assignment) z druhé
- **Ověřeno skutečným spuštěním, ne jen čtením kódu** - přes
  `streamlit.testing.v1.AppTest` (headless): aplikace nastartuje bez
  výjimky, všech 5 stránek se načte, reálné nahrání fixture e-mailu a
  proklik celým pipeline až po zápis do databáze a zobrazení Threat/
  Confidence `st.metric` widgetů. 9 nových testů (`tests/test_app_gui.py`),
  celkem 119 v sadě. Testy se automaticky přeskočí bez nainstalovaného
  `streamlit` (GUI je volitelná nadstavba)
- **Bug nalezený a opravený vlastním testem:** `case_module.CASES_ROOT`
  byla čistě relativní cesta (`'cases'`), zatímco `main.py`'s `DB_PATH`/
  `REPORTS_DIR`/`CONFIG_PATH` jsou ukotvené k umístění projektu -
  `case create`/`case add` by tak vytvářely `cases/` složku kamkoliv,
  odkud zrovna běžíš `main.py`, zatímco `add`/`compare` by pořád mířily
  do stejné centrální databáze. Nekonzistentní chování mezi příkazy.
  Opraveno stejným ukotvením jako zbytek `main.py`
- **Druhý bug, tentokrát v mém vlastním testu:** `test_upload_and_process_
  writes_to_database` používal `monkeypatch.chdir(tmp_path)` pro izolaci,
  ale `DB_PATH`/`CASES_ROOT` jsou ukotvené k `__file__`, ne k cwd - test
  by tak tiše zapisoval do SKUTEČNÉ projektové databáze/case složky a
  neuklízel po sobě. Opraveno přímým čištěním skutečné ukotvené cesty
  po testu (`try`/`finally`), respektive `monkeypatch.setattr` přímo na
  `CASES_ROOT` tam, kde to jde
- `case.py` rozšířen o `suggest_cases_for_fingerprint()` (bohatší verze
  `find_matching_cases()` - navíc `shared_domains`/`shared_ips`/
  `shared_attachment_sha256`, `email_count`, `strong_signal_hit`) a
  `should_auto_assign()` s dvouúrovňovým prahem (`DEFAULT_SUGGEST_
  THRESHOLD` 30 % pro "ukázat jako kandidáta", `AUTO_ASSIGN_CONFIRM_
  THRESHOLD` 60 % nebo silný jednotlivý nález pro "smí se přiřadit BEZ
  potvrzení") - přesnější než původní jednoúrovňový práh z v0.17.
  `find_matching_cases()` zůstává jako zpětně kompatibilní zjednodušená
  obálka. CLI (`--auto-case`, `case suggest`) i GUI teď sdílí identickou
  rozhodovací logiku
- Opravena zavádějící hláška v GUI ("žádná Gmail integrace") - Gmail
  sync je dostupný přes CLI (`python3 main.py sync`), GUI na něj jen
  zatím nemá vlastní stránku
- `install.bat`, `Spustit MailGuardian.bat`, `Spustit MailGuardian CLI.bat`,
  `scripts/make_shortcut.ps1` - žádný PyInstaller, žádné `.exe` balení,
  žádné druhé (tkinter) GUI, jen automatizace nastavení nad Streamlitem.
  **Nešlo ověřit tady** - vývojové prostředí nemá Windows/PowerShell,
  soubory jsou ručně zkontrolované (syntaxe, žádná diakritika kvůli
  `cmd.exe` kódování), ale nikdy reálně nespuštěné
- CI (`ci.yml`) rozšířeno o syntax check `app.py` a instalaci GUI
  závislostí, ať headless GUI testy běží i tam
- **Poučení pro příště, zapsané záměrně:** stejný projekt souběžně
  upravovaný ve víc AI konverzacích/nástrojích bez jasného "tohle
  vlákno je zdroj pravdy" vede přesně k tomuhle - rozdvojeným větvím,
  které je pak potřeba ručně slučovat a rozhodovat, co je čí práce

**v0.17 - Automatické přiřazení do Case**
- Nová funkce `case_module.find_matching_cases()` — porovná nový
  fingerprint proti VŠEM existujícím case složkám, vrátí seřazený
  seznam kandidátů nad prahem (nebo se silným jednotlivým nálezem -
  stejná konvence jako `watch`/`case compare`). Záměrně nepočítá shodu
  IOC zvlášť - `similarity.compare()` už sdílenou IP/doménu/hash přílohy
  zahrnuje jako Identity signály, samostatný IOC průchod by byl
  duplicitní logika
- Nový příkaz `case suggest <soubor>` — dry-run, ukáže kam by e-mail
  sedl, nic nemění. Bezpečný způsob, jak si to nejdřív ověřit
- Nový `--auto-case` flag na `add`/`sync` se třemi větvemi chování
  (rozhodnuto vědomě, ne náhodně): **žádná shoda** → automaticky založí
  nový case (`auto_<datum>_<hash8>` - samo-omezující se, protože další
  podobný mail už spadne do právě založeného case, ne založí třetí);
  **přesně jedna shoda** → přiřadí tam; **víc shod najednou** → jen
  vypíše žebříček kandidátů, NEROZHODUJE se automaticky samo
- `generate_auto_case_name()` bere explicitní parametry (datum, hash),
  ne fingerprint dict - fingerprint samotný datum hlavičky neobsahuje,
  bylo by matoucí předstírat, že jde vytáhnout odtud
- Přidán `database.get_email()` (dotaz na jeden záznam podle id) - ať
  se po `--auto-case` nemusí zbytečně re-parsovat `.eml` znovu jen kvůli
  datu, když už je uložené v DB z prvního zpracování
- 9 nových testů (`tests/test_case_auto_assign.py`), celkem 105 v sadě.
  Otestováno na reálných fixture variantách (stejná infrastruktura,
  jiný obsah - simulace druhé vlny kampaně): žádná shoda, jedna shoda,
  víc shod najednou, prázdný case se nepočítá jako kandidát
- **Vědomě odloženo/zjednodušeno:** `gmail_state` tabulka zůstává beze
  změny (žádné `case_id`/`analysis_id` sloupce) - `--auto-case` na
  `sync` řeší přiřazení až PO stažení, ne uvnitř `gmail_state` samotné,
  takže netřeba měnit její schéma

**v0.16 - Gmail sync**
- Přidán modul `gmail_connector.py` — stahování nových e-mailů přímo z
  Gmailu, `gmail.readonly` scope (nikdy nic nemaže/neoznačuje). Vědomé
  architektonické rozhodnutí: OAuth2 + Gmail REST API napsané čistě
  přes stdlib (`urllib`, `http.server`, `webbrowser`), ŽÁDNÁ závislost
  na `google-auth-oauthlib`/`google-api-python-client` - drží se to
  filozofie zbytku projektu (0 externích knihoven pro jádro)
- **OAuth2 authorization code flow s lokálním redirect serverem**
  (Google zrušil "out-of-band" flow kolem 2022) - otestováno SKUTEČNÝM
  HTTP požadavkem na localhost (žádný mock, žádná externí síť potřeba):
  úspěšná autorizace, zamítnutí přístupu uživatelem, timeout
- **Stavová deduplikace** (`gmail_state` tabulka - jen `message_id`/
  `internal_date`/`sha256`/`file_path`, žádné předčasné sloupce jako
  `case_id`/`analysis_id` "do zásoby" - přidají se až bude existovat
  funkce, která je skutečně použije) - nezávisí na Gmail `is:unread`
  příznaku, ověřeno testem přes dva po sobě jdoucí sync běhy
- **Bezpečnostní pojistky**: `max_allowed` limit v `config.ini` (chrání
  proti překlepu typu `--max 100000`), doporučený konzervativní výchozí
  dotaz pro první sync (`newer_than:30d`, max 50)
- **Bug nalezený a opravený vlastním testem:** `sync_gmail_emails()`
  měl `list_fn=list_messages` jako výchozí hodnotu parametru - v Pythonu
  se defaultní hodnoty vážou na funkci JEDNOU při definici modulu, ne
  při každém volání, takže `unittest.mock.patch.object()` na modulovou
  úroveň by v `main.py`'s `cmd_gmail_sync` (kde se `list_fn` nepředává
  explicitně) neměl žádný efekt - testy by tiše testovaly něco jiného,
  než co se skutečně spustí v CLI. Opraveno pozdním vyhledáním jména
  uvnitř těla funkce (`if list_fn is None: list_fn = list_messages`)
- 20 nových testů (`tests/test_gmail_connector.py`), celkem 97 v sadě
- **Vědomě odloženo:** automatické přiřazení nového mailu do Case podle
  Identity Similarity - viz sekce "Plánovaná rozšíření" níž, proč zrovna
  teď ne (žádná polovičatá databázová příprava bez funkční logiky)
- **Co nešlo ověřit tady:** skutečné přihlášení do Google účtu v
  prohlížeči a živé Gmail API volání - vyžaduje reálné OAuth credentials
  a síťový přístup na accounts.google.com/gmail.googleapis.com, které
  tenhle sandbox nemá. Nutno vyzkoušet u tebe (`gmail-auth` +
  `sync --max 5` jako první opatrný test)

**v0.15 - Testy, CI, dokumentace, GitHub připravenost**
- **Pytest sada** (`tests/`, 77 testů, ~0,5s) — formalizuje ad-hoc
  testování z předchozích verzí do trvalé regresní sady: parser (7
  fixture e-mailů: Gmail/Exchange/Postfix styl, newsletter, phishing,
  malware příloha, podvržený řetězec, minimální hlavičky), Identity/
  Threat scoring (brute-force test stropu 100 % přes 3072, resp. 32
  kombinací signálů), Confidence, homoglyph detekce, MIME/Received
  chain, DNS/WHOIS parsování (na ručně sestavených RFC-kompatibilních
  datech), Case mode (create/add/compare/report/graph v izolovaném
  `tmp_path`), Evidence mode (determinismus, integrity manifest)
- **Regresní dataset** (`tests/fixtures/eml/`) — 7 reprezentativních
  e-mailů pokrývajících různé generátory a scénáře, znovupoužitelné
  napříč testy přes `conftest.py`
- **`benchmark.py`** — skutečně naměřené (ne odhadnuté) výkonové
  charakteristiky: parse+fingerprint škáluje lineárně (~15 ms/e-mail),
  `compare-all`/`case compare` škáluje O(n²) - u 1000 e-mailů dominuje
  celkovému času (46s vs 16s na parsování)
- **`docs/architecture.md`** — popis vrstev, datového toku, tří
  nezávislých skóre, vzoru "dynamický jmenovatel" (a proč je kritický),
  Case mode designu, determinismu pro Evidence mode, a zdůvodnění, proč
  zatím ne plugin architektura
- **`ruff` linting** — nastaveno jen na skutečné chyby (`F`, `E9`), ne
  styl/formátování; spuštěno proti celému kódu, nalezeno 9 kosmetických
  nálezů (nepoužité importy, zbytečný f-string prefix), žádné skutečné
  bugy. Zapojeno do CI
- **GitHub scaffolding** — `LICENSE` (MIT, k potvrzení), `CONTRIBUTING.md`
  (jak přispívat, na co dát pozor kvůli historii bugů s dynamickým
  jmenovatelem), `SECURITY.md`, `.github/workflows/ci.yml` (testy +
  linting na Python 3.9-3.12) - CI kroky ověřeny ruční simulací lokálně
  (skutečný GitHub Actions runner nejde v tomhle sandboxu spustit)
- **`logging_config.py`** — standardní DEBUG/INFO/WARNING/ERROR logging
  (na stderr, oddělené od `audit.py`, který je forenzní záznam, ne
  ladicí nástroj). Zapojeno do `except Exception` bloků síťových modulů
  (AbuseIPDB/VirusTotal/WHOIS/DNS) - reaguje na dřívější review
  připomínku, že široký except bez logování může tiše maskovat
  programátorskou chybu; graceful degradace zůstává, ale už není tichá

**v0.14 - VirusTotal URL/hash + graf vztahů**
- **VirusTotal rozšířen na URL a hash příloh** (dřív jen IP) - `virustotal.py`
  refaktorovaný na sdílenou `_do_lookup()` implementaci pro IP/URL/hash
  najednou. VT identifikuje URL přes base64url encoding bez paddingu -
  ověřeno round-trip testem. `--virustotal` teď dotazuje i první 3
  unikátní odkazy a hash prvních 5 příloh (capped kvůli rate limitu)
- **Bug nalezený a opravený vlastním testem:** rozšíření cache o URL/hash
  vyžadovalo změnu schématu (sloupec `ip` → obecný `key`) - stará cache
  z v0.11-v0.13 by bez migrace jen tiše přestala fungovat (zachyceno
  existujícím except blokem, žádný pád, ale zbytečné). Přidána explicitní
  migrace, ověřená testem na simulované staré cache
- Dva nové threat signály: `virustotal_url_malicious` (22b.) a
  `virustotal_attachment_malicious` (28b., nejvyšší ze všech signálů) -
  shoda hashe přílohy je nejpřesnější dostupný signál, mnohem víc než
  reputace celé IP. Ověřeno na 32 kombinacích (2⁵) všech volitelných
  zdrojů, strop zůstává přesně 100 %
- **Graf vztahů v Case mode** (`case graph <jméno>`) - Graphviz DOT export,
  uzly=e-maily (barva podle Threat skóre), hrany=Identity Similarity nad
  prahem. Textové shrnutí shluků přes union-find, bez nutnosti graf
  vykreslovat. Ověřeno reálným `dot` binary (dostupný v tomhle sandboxu,
  na rozdíl od DNS/WHOIS) - syntaxe i sémantika (víceřádkové labely)
  ověřená vygenerovaným SVG, ne jen "vypadá to správně"
- **Druhý bug nalezený stejným testem:** escapovací funkce pro DOT labely
  aplikovaná na CELÝ složený label (včetně záměrně vloženého `\n` pro
  zalomení řádku) escapovala i tenhle backslash, takže by graf zobrazil
  doslovné „\n" místo zalomení řádku. `dot` to zpracoval bez syntaktické
  chyby (proto to prvním testem neprošlo), odhalilo se to až kontrolou
  vykresleného SVG. Opraveno escapováním jen syrových textových částí
  před složením labelu
- **Třetí bug, tentokrát z editace:** při vkládání nových funkcí do
  `case.py` se ztratila řádka s definicí `build_timeline()` - funkce
  zůstala bez hlavičky. Odhaleno okamžitě regresním testem `case report`
  (byl by to nepříjemný "AttributeError" pro každého, kdo by si stáhl
  balíček bez tohohle testu) a opraveno v rámci stejného kola

**v0.13 - WHOIS + DNS**
- Přidán modul `dns_lookup.py` — syrová implementace DNS protokolu
  (RFC 1035) přes UDP bez externí závislosti (Python stdlib nemá
  vestavěnou podporu MX/TXT/NS, jen A/AAAA). Podporuje kompresi jmen
  (pointer 0xC0), A/MX/TXT/NS záznamy. Otestováno na ručně sestavených
  bytech podle RFC (včetně komprimovaného jména v MX exchange poli -
  klasický zdroj chyb DNS parserů), NXDOMAIN, špatném transaction ID
  (ochrana proti podvržené odpovědi), a mockovaném end-to-end běhu
  včetně timeoutu
- Přidán modul `whois_lookup.py` — syrový WHOIS klient (RFC 3912, TCP
  port 43) s IANA referral resolucí pro neznámé TLD. Parsování stáří
  domény/registrara/nameserverů je heuristické (regex, různé registry
  mají různý formát) - otestováno na syntetických odpovědích ve stylu
  .com/.cz/.uk
- **Bug nalezený a opravený vlastním testem:** regex pro "Registered on:"
  (britský styl datumu, `15-Jan-2020`) měl character class `[\d\-]`,
  která neumí písmena měsíce - ořízlo by to datum na "15-". Opraveno na
  `[\d\w\-]`, ověřeno regresním testem ostatních formátů
- Nový threat signál `young_domain` (18b.) — doména mladší 30 dní, jen
  pokud byl WHOIS dotaz proveden (`--whois`). Bezpečný dynamický
  jmenovatel stejně jako u AbuseIPDB/VT - ověřeno na všech 8 kombinacích
  tří volitelných zdrojů (abuse/VT/whois), všechny dávají přesně 100%
- **Důležité omezení, uvedené i v README:** na rozdíl od AbuseIPDB/VT
  (HTTP API, otestováno mockovaným `urlopen`) jde u WHOIS/DNS o syrové
  TCP/UDP protokoly na porty 43/53, ke kterým tenhle sandbox nemá vůbec
  přístup (ani přes povolenou doménu). Parsovací logika je důkladně
  testovaná, ale skutečná síťová komunikace nikdy nebyla ověřená proti
  reálnému resolveru/WHOIS serveru - nutno vyzkoušet a případně doladit
  na vlastním stroji

**v0.12 - Explainability + Case mode**
- **Explainability** — Threat i Confidence skóre teď mají stejnou úroveň
  vysvětlitelnosti jako Identity Similarity (ta ji měla od začátku).
  Každý nález/kritérium se zobrazuje s konkrétní váhou (`+20 SPF=fail...`,
  `+0 ARC řetězec přítomný (chybí, možných +10)`), seřazené podle dopadu
  sestupně - hned vidíš, CO nejvíc přispělo k výslednému číslu. CLI má
  navíc `verbose` přepínač (detailní rozpad jen u `compare`, stručný
  přehled u `add`/`watch`, ať to není zahlcující při hromadném přidávání)
- **Case mode** (`modules/case.py`, příkaz `case create/add/compare/
  report/list`) — samostatné, přenositelné case složky pro analýzu celé
  kampaně/incidentu (víc než pár e-mailů), ne jednotlivé páry. Vlastní
  databáze, vlastní kopie originálů, agregované IOC, chronologický
  timeline, integrity manifest. Otestováno end-to-end na simulované
  2-wave phishing kampani (48,4% shoda mezi vlnami, 0% k nesouvisejícímu
  mailu), včetně idempotence (opakovaný `add`/`compare`/`create`),
  ověření hashe v manifestu a korektního řazení timeline i s neplatným/
  chybějícím Date headerem (bez pádu)
- Hlavní `emails/`/`database/` workflow a Case mode jsou úplně nezávislé
  (oddělené SQLite databáze) - ověřeno explicitním regresním testem

**v0.11**
- Přidán modul `virustotal.py` — reputace IP přes VirusTotal API v3,
  stejný vzor jako AbuseIPDB (`--virustotal` flag, cache, gracefully
  degradace), navíc s rate limiterem (VT Public API dovoluje jen 4
  dotazy/minutu - přísnější než AbuseIPDB). Otestováno end-to-end s
  mockovaným API klíčem, mockovanou HTTP odpovědí a mockovaným
  `time.sleep` (ověřeno, že rate limiter čeká mezi dvěma skutečnými
  dotazy, ale ne při cache hitu)
- Nižší váha (10 b.) než AbuseIPDB (12 b.) — žádný jeden externí zdroj
  nemá ve skóre dominantní vliv; stejný bezpečný vzor dynamického
  jmenovatele jako u AbuseIPDB, ověřeno na všech 4 kombinacích
  dostupnosti (bez obou / jen AbuseIPDB / jen VT / oboje) — všechny
  správně dosahují přesně 100% strop
- **Opraven bug v `watch`** (nalezeno externím review) — sledování podle
  cesty souboru (`known_paths`) tiše přeskočilo soubor, který byl smazaný
  a znovu vytvořený se stejným jménem, ale jiným obsahem. Opraveno tak,
  že `watch` teď zpracovává všechny soubory při každém běhu a spoléhá na
  `store_email`ovu SHA-256 detekci změny obsahu (`store_email` teď vrací
  `(id, was_changed)` místo jen `id`)
- Sekce síťové reputace (AbuseIPDB/VirusTotal) v HTML reportu přesunuta
  ze vnitřku Received chain karty do vlastní samostatné sekce - technicky
  nejde o součást Received řetězce
- Přidán probabilistický cache cleanup (AbuseIPDB i VirusTotal) proti
  neomezenému růstu cache databáze

**v0.10**
- Přidán modul `abuseipdb.py` — reputace IP přes AbuseIPDB API, čistě
  volitelné (`--abuseipdb` flag na `add`/`compare`/`watch`/`bundle`),
  protože jde o živé síťové volání s denním limitem (na rozdíl od GeoIP,
  který je lokální databázový soubor). API klíč přes proměnnou prostředí
  nebo `config.ini`, lokální cache (7 dní) proti zbytečnému vyčerpání
  limitu. Otestováno end-to-end s mockovaným API klíčem a mockovanou
  HTTP odpovědí (bez skutečné sítě - `api.abuseipdb.com` není v
  povoleném seznamu domén tohohle sandboxu)
- **Bug odhalený a opravený při implementaci:** kdyby se váha AbuseIPDB
  signálu přidala napevno do jmenovatele Threat skóre, žádný e-mail bez
  `--abuseipdb` (tedy většina) by nikdy nemohl dosáhnout 100 % - stejný
  vzorec chyby, jakou jsem opravoval v `similarity.py` v v0.1.2. Opraveno
  dynamickým jmenovatelem (váha se počítá jen když byl dotaz skutečně
  proveden) a ověřeno na 3 scénářích (bez dat, se všemi daty, jen s
  AbuseIPDB nálezem)
- **Druhý bug:** `store_email` dedup podle SHA-256 obsahu by tiše
  ignoroval nově obohacená data, kdyby se stejný `.eml` spustil podruhé
  jen s `--abuseipdb` navíc (obsah souboru se přece nezměnil). Přidán
  `force_update` parametr - enrichment flag teď vynutí přepis i beze
  změny obsahu
- Nízká váha (12 b.) a konzervativní práh (confidence ≥50 % A ≥3 hlášení)
  reflektují riziko false positive u velkých poskytovatelů (Gmail,
  M365) - nález se vždy zobrazuje s explicitní výhradou, ne jako
  definitivní verdikt

**v0.9 - Evidence mode**
- Přidán modul `evidence.py` — integrity manifest (SHA-256 originálního
  `.eml`, HTML reportu, JSON exportu, IOC), verzování (`tool_version`,
  `fingerprint_version`, `scoring_version`) pro pozdější ověření, že se
  od analýzy nic nezměnilo a jakou verzí nástroje byl výsledek vytvořen
- Přidán modul `audit.py` — lehký audit trail, loguje kroky analýzy
  (parsování hlaviček, IP/DKIM, odkazy/přílohy, Received řetězec, MIME/
  Message-ID/HTML otisky, Threat/Confidence skóre) s časovými razítky
- **Deterministická JSON serializace** — `sort_keys=True` napříč exportem,
  ověřeno testem: stejný `.eml` naparsovaný a otisknutý dvakrát nezávisle
  dá bitově identický fingerprint JSON (jediná výjimka je záměrně
  `analysis_time_utc` v manifestu, který se logicky mění při každém běhu)
- Nový příkaz `main.py bundle mail1.eml mail2.eml` — vytvoří **Evidence
  Bundle** (`Case_<datum>.zip`): oba originální `.eml`, HTML+JSON report,
  IOC export, audit log pro každý e-mail, integrity manifest. Otestováno
  end-to-end včetně ověření, že hash v manifestu skutečně odpovídá
  obsahu přiloženého souboru
- **Vědomě odloženo:** signed report (Ed25519) — přidává závislost na
  `cryptography` jen pro sdílení mezi lidmi/týmy, což zatím není potřeba;
  Case mode (skupiny e-mailů, graf vztahů) — až po v1.0

**v0.7**
- Přidán modul `message_id_fp.py` — otisk Message-ID: Shannonova entropie
  lokální části, délka, doména, orientační rozpoznání generátoru (Gmail,
  Exim, Postfix, Microsoft Exchange, Python stdlib, UUID/hash styl).
  Otestováno na 5 reálných formátech, včetně opravy Exchange vzoru
  (skutečná struktura je `[2 písmena][1-2 číslice]PR[číslice]MB[číslice]`,
  ne to, co jsem zkusil napoprvé)
- Přidán modul `html_fp.py` — tracking pixely (1×1 obrázky), formuláře,
  skryté prvky (`display:none`/`visibility:hidden`), base64/externí
  obrázky, inline CSS. Tři nové threat signály: `tracking_pixel` (8b.),
  `hidden_content` (15b.), `embedded_form` (15b.)
- Nový identity signál `message_id_generator_match` (8b.) — vynechává
  "neznámý/vlastní formát", protože shoda dvou neznámých nic neznamená.
  Ověřeno hrubou silou přes 3072 kombinací, že strop identity similarity
  zůstává přesně 100 %
- **Přidán Confidence Score** (`confidence.py`) — třetí, nezávislé číslo
  vedle Identity a Threat: "kolik kvalitních dat máme k dispozici", ne
  "jak podobné" nebo "jak nebezpečné". Nízké skóre s nízkou confidence
  ("nemáme dost dat") je jinak interpretovatelné než stejné skóre s
  vysokou confidence ("data jsou kvalitní, výsledek je spolehlivý").
  Zobrazuje se u `add`/`watch`/`compare` a je součástí JSON exportu

**v0.6**
- Přidán modul `mime_fp.py` — otisk MIME struktury (pořadí částí,
  vnořené multiparty, styl boundary řetězce s orientační klasifikací
  generátoru - Python stdlib, JavaMail, Outlook/Exchange, Apple Mail...),
  nový identity signál `mime_structure_match` (10b.), vynechává triviální
  single-part text/plain|html shody, protože ty nic neznamenají
- Přidán modul `exporter.py` — JSON export vedle HTML reportu při
  `compare`/`watch` (`report_X_vs_Y.json`), strojově čitelný formát pro
  navazující automatizaci/SIEM
- Přidán modul `ioc.py` a příkaz `main.py ioc <soubor.eml>` — vytáhne
  IP/domény/URL/e-mailové adresy/hashe příloh z jednoho e-mailu do JSON
- Ověřeno hrubou silou přes 1536 kombinací signálů, že strop identity
  similarity zůstává přesně 100 % i s novým MIME signálem
- **Vědomě odloženo:** plugin architektura (zdůvodnění výše), YARA
  (potřebuje C rozšíření, chci otestovat u tebe, ne slepě poslat)

**v0.5**
- Přidán modul `received_chain.py` — rozbor CELÉHO Received řetězce po
  jednotlivých hopech (ne jen první veřejná IP): klasifikace IP
  (public/private/loopback), rozpoznání známých cloud relayů (Google,
  Microsoft 365, SendGrid...), časy mezi hopy, a hlavně **kontrola
  návaznosti řetězce** ('from' hopu N musí odpovídat 'by' hopu N+1) -
  nesedí-li to, jde o možný náznak ručně vložených/upravených hlaviček
- Nové pole `origin_public_ip` — nejstarší veřejná IP v řetězci (nejblíž
  odesílateli), na rozdíl od dosavadního `primary_ip` (nejblíž příjemci,
  často jen infrastruktura vlastního poskytovatele, stejná napříč
  veškerou příchozí poštou)
- Přidána podpora **ARC** (Authenticated Received Chain) — parsuje
  ARC-Seal a ARC-Authentication-Results po instancích, důležité hlavně
  u přeposílaných zpráv, kde běžné SPF/DKIM selže i u legitimní pošty
- Nový threat signál `broken_chain` — přerušená návaznost Received
  řetězce se teď promítá do threat skóre
- HTML report rozšířen o vizualizaci celého hop-by-hop řetězce s
  anomáliemi
- **Bug nalezený a opravený při implementaci:** kontrola návaznosti
  řetězce měla obrácenou logiku (porovnávala `by` hopu N s `from` hopu N+1
  místo `from` hopu N s `by` hopu N+1) - hlásila by falešné anomálie na
  každém naprosto normálním e-mailu. Opraveno a ověřeno na čistém i
  uměle přerušeném řetězci.
- Anomálie teď strukturovaná data (`{type, hop_index, detail}`), ne
  prostý text - `threat.py` filtruje podle `type`, ne matchováním
  podřetězců (křehčí a méně udržovatelné)

**v0.4**
- **Rozdělení skóre na Identity Similarity a Threat** (viz sekce výše) —
  architektonická změna, aby se nemíchala otázka "kdo to poslal" s
  "jak je to nebezpečné"
- Přidán modul `homoglyph.py` — detekce IDN homograph útoků (smíchané
  Unicode skripty v doméně) a typosquattingu (edit distance vůči známým
  doménám), včetně dekódování punycode a normalizace vizuálně zaměnitelných
  znaků (např. celá cyrilická doména vypadající jako "paypal.com")
- Přidán modul `threat.py` — skóre rizikovosti jednoho e-mailu (SPF/DKIM/
  DMARC selhání, URL mismatch, homoglyph domény, podezřelé/zamaskované
  přípony příloh), počítá se hned při `add`/`watch`
- Přidán URL normalizer (`urls.py`) — `https://x.com` a `https://x.com/`
  a `HTTP://X.COM:80/` se teď správně považují za stejnou adresu
- `add`, `watch` a `list` teď rovnou ukazují threat skóre a nálezy,
  ne až při porovnání dvou e-mailů
- Otestováno: cyrilická homoglyph doména (plná i smíchaná s latinkou),
  punycode dekódování, dvojitá přípona přílohy (.pdf.exe), URL mismatch,
  end-to-end pipeline s vysoce rizikovým a čistým e-mailem

**v0.3**
- Přidán modul `urls.py` — extrakce odkazů z HTML i textu (vestavěný
  `html.parser`, ne regex na HTML), detekce mismatch mezi zobrazeným textem
  odkazu a skutečným cílem (phishing indikátor)
- Přidán modul `attachments.py` — SHA-256 hash každé přílohy
- Přidáno vysvětlení SPF/DKIM/DMARC verdiktů v prostém jazyce
- Přidány 2 nové scoring signály: shodná doména v odkazech (12 b.),
  identická příloha (20 b.) — nekonfliktní s existujícími signály,
  ověřeno hrubou silou přes 768 kombinací, že strop zůstává přesně 100 %
- **Silné jednotlivé nálezy** — pokud sedí identická příloha/DKIM/primární IP,
  nástroj to označí jako "stojí za prověření" i při nízkém celkovém skóre
  (typicky: stejný útočník, jiná infrastruktura, ale stejný malware v příloze)
- HTML report rozšířen o sekce s odkazy, přílohami a vysvětlením autentizace,
  všechna pole escapovaná proti XSS

**v0.2**
- Přidán příkaz `watch` — automatická detekce a porovnání nově přidaných
  `.eml` souborů ve sledované složce, jednorázově nebo v opakované smyčce
  (`--interval`), s konfigurovatelným prahem pro upozornění/report
  (`--threshold`). Otestováno na prázdné složce, postupném přidávání
  souborů i běhu na pozadí s intervalem.


**v0.1.2 (audit)**
- **Oprava normalizace skóre** — `MAX_SCORE` byl počítaný jako prostý součet všech vah,
  ale několik signálů se vzájemně vylučuje (IP shoda/přesah, DKIM key/doména, GeoIP bonus).
  Důsledek: i naprosto identický fingerprint nikdy nedosáhl 100 % (reálný strop byl ~73-78 %).
  Opraveno na správný, skutečně dosažitelný strop (105 bodů) — ověřeno hrubou silou přes
  192 kombinací signálů.
- **Oprava zastaralého fingerprintu** — pokud se `.eml` na stejné cestě přepsal (jiný obsah,
  jiný SHA-256) a spustil se znovu `add`, nástroj tiše používal starý fingerprint.
  Teď se záznam při změně obsahu automaticky přepíše.
- **Přidána podpora IPv6** v Received hlavičkách (dřív se extrahovaly jen IPv4 adresy).
- Ověřeno: parametrizované SQL dotazy odolávají injection pokusům v obsahu e-mailu;
  žádné pády na prázdném/binárním/poškozeném `.eml` souboru.

**v0.1.1**
- Oprava normalizace skóre tak, aby chybějící GeoIP nesnižovalo max. dosažitelné skóre
  *(pozn.: tato oprava byla neúplná, viz v0.1.2 výše)*
- Escapování polí z e-mailu (předmět, odesílatel...) v HTML reportu proti HTML/JS injekci
  ze škodlivého e-mailu
- Deduplikace řádků v historii porovnání při opakovaném `compare-all`
- Přidán `.gitignore`
- Přidán volitelný GeoIP/ASN modul
