#!/usr/bin/env python3
"""
benchmark.py
Změří čas a paměť pipeline (parse -> fingerprint -> similarity) pro
rostoucí počet e-mailů. Spouštět z kořene projektu:

    python3 benchmark.py [--counts 10,100,500] [--out benchmark_results.json]

Generuje syntetické .eml soubory (variace fixture vzorků), aby nebylo
potřeba mít po ruce tisíce reálných e-mailů. Výsledky se dají porovnávat
mezi verzemi, aby šlo zachytit regrese výkonu.
"""

import argparse
import json
import os
import random
import shutil
import sys
import tempfile
import time
import tracemalloc

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from modules import parser as eml_parser
from modules import fingerprint as fp_module
from modules import similarity


TEMPLATE = """From: "Sender {i}" <sender{i}@domain{dom}.com>
Message-ID: <msg{i}.{ts}@mail.domain{dom}.com>
Date: Mon, 06 Jul 2026 {hour:02d}:00:00 +0200
Authentication-Results: mx.google.com; spf={spf}; dkim={dkim}; dmarc={dmarc}
Received: from mail.domain{dom}.com (mail.domain{dom}.com [{ip}]) by mx.google.com; Mon, 06 Jul 2026 {hour:02d}:00:00 +0200
Content-Type: text/html

<html><body><p>Test message {i}</p><a href="https://example{dom}.com/link">click</a></body></html>
"""


def generate_synthetic_emails(n: int, out_dir: str):
    verdicts = ['pass', 'fail']
    for i in range(n):
        dom = i % 20  # 20 "domén", ať similarity engine má i shody, ne jen unikáty
        ip = f"45.33.{dom}.{i % 254 + 1}"
        content = TEMPLATE.format(
            i=i, dom=dom, ts=1720000000 + i, hour=i % 24, ip=ip,
            spf=random.choice(verdicts), dkim=random.choice(verdicts), dmarc=random.choice(verdicts),
        )
        with open(os.path.join(out_dir, f"synth_{i:05d}.eml"), 'w') as f:
            f.write(content)


def run_benchmark(n: int) -> dict:
    tmp_dir = tempfile.mkdtemp(prefix='mg_bench_')
    try:
        generate_synthetic_emails(n, tmp_dir)
        files = sorted(os.path.join(tmp_dir, f) for f in os.listdir(tmp_dir))

        tracemalloc.start()
        t0 = time.perf_counter()

        fingerprints = []
        for f in files:
            parsed = eml_parser.parse_eml(f)
            fp = fp_module.build_fingerprint(parsed, enable_geoip=False)
            fingerprints.append(fp)

        t1 = time.perf_counter()
        parse_time = t1 - t0

        # all-pairs similarity - O(n^2), nejdražší část při velkém n
        t2 = time.perf_counter()
        comparisons = 0
        for i in range(len(fingerprints)):
            for j in range(i + 1, len(fingerprints)):
                similarity.compare(fingerprints[i], fingerprints[j])
                comparisons += 1
        t3 = time.perf_counter()
        compare_time = t3 - t2

        current, peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()

        return {
            'email_count': n,
            'parse_and_fingerprint_seconds': round(parse_time, 3),
            'parse_and_fingerprint_per_email_ms': round(parse_time / n * 1000, 3),
            'all_pairs_compare_seconds': round(compare_time, 3),
            'comparisons_count': comparisons,
            'compare_per_pair_ms': round(compare_time / comparisons * 1000, 4) if comparisons else 0,
            'peak_memory_mb': round(peak / 1024 / 1024, 2),
        }
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)


def main():
    parser = argparse.ArgumentParser(description="MailGuardian benchmark")
    parser.add_argument('--counts', default='10,100,500',
                         help="Čárkou oddělený seznam počtů e-mailů k otestování (výchozí: 10,100,500)")
    parser.add_argument('--out', default=None, help="Uložit výsledky jako JSON")
    args = parser.parse_args()

    counts = [int(c.strip()) for c in args.counts.split(',')]
    results = []

    print(f"{'Počet e-mailů':>15} | {'Parse+FP (s)':>13} | {'ms/email':>9} | "
          f"{'Compare (s)':>12} | {'ms/pár':>8} | {'Peak RAM (MB)':>13}")
    print("-" * 90)

    for n in counts:
        r = run_benchmark(n)
        results.append(r)
        print(f"{n:>15} | {r['parse_and_fingerprint_seconds']:>13} | "
              f"{r['parse_and_fingerprint_per_email_ms']:>9} | "
              f"{r['all_pairs_compare_seconds']:>12} | {r['compare_per_pair_ms']:>8} | "
              f"{r['peak_memory_mb']:>13}")

    if args.out:
        with open(args.out, 'w') as f:
            json.dump({'python_version': sys.version, 'results': results}, f, indent=2)
        print(f"\nVýsledky uloženy: {args.out}")

    print("\nPoznámka: all-pairs compare roste O(n²) - pro velké case složky "
          "(stovky+ e-mailů) bude tahle část dominovat celkovému času.")


if __name__ == '__main__':
    main()
