# Přispívání do MailGuardian OSINT

## Rychlý start

```bash
git clone <repo>
cd MailGuardian
pip install -r requirements-dev.txt --break-system-packages
python3 -m pytest tests/ -v
```

Všechny testy by měly projít předtím, než začneš cokoliv měnit - pokud
neprojdou na čistém checkoutu, nahlas to jako issue.

## Než pošleš Pull Request

1. **Spusť testy:** `python3 -m pytest tests/ -v`
2. **Spusť linter:** `python3 -m ruff check .`
3. Pokud přidáváš nový scoring signál do `similarity.py` nebo
   `threat.py`, přečti si sekci "Vážený scoring - dynamický jmenovatel"
   v [`docs/architecture.md`](docs/architecture.md) - tahle třída bugu
   (naivní součet vah u vzájemně se vylučujících/volitelných signálů)
   se v projektu stala dvakrát a je potřeba jí předcházet testem.
4. Pokud přidáváš nový modul s enrichmentem (síťové/API volání), dodrž
   vzor v `docs/architecture.md` sekci "Optional enrichment": `is_available()`
   bez síťového volání, hlavní funkce nikdy nevyhazuje výjimku.
5. Přidej test pokrývající novou funkcionalitu do `tests/`.

## Struktura testů

- `tests/fixtures/eml/` - ukázkové e-maily (Gmail/Exchange/Postfix styl,
  newsletter, phishing, malware příloha, podvržený řetězec, minimální
  hlavičky). Nové testy typicky použijí existující fixture přes
  `build_fp('nazev.eml')` z `conftest.py`, ne vlastní inline `.eml` text.
- Testy síťových modulů (`abuseipdb.py`, `virustotal.py`, `dns_lookup.py`,
  `whois_lookup.py`) testují PARSOVACÍ logiku na ručně sestavených/
  mockovaných datech, nikdy neprovádí skutečné síťové volání - CI nemá
  (a neměl by mít) přístup k živým API.

## Styl kódu

- Komentáře a docstringy v češtině (konzistentní s existujícím kódem).
- `ruff check .` musí projít bez chyb (kontroluje jen `F`/`E9` pravidla -
  skutečné chyby jako nepoužité importy, ne styl/formátování).
- Preferuj graceful degradaci před vyhazováním výjimek v modulech, které
  volají externí služby - viz existující vzor v `abuseipdb.py`.

## Formát fingerprintu je zmrazený

Od v0.9 (viz README) je formát polí ve `fingerprint.build_fingerprint()`
výstupu zmrazený - nová pole se dají přidávat, ale existující se
nepřejmenovávají ani nemažou bez zvýšení `fingerprint_version`/
`scoring_version` v `modules/evidence.py`. Pokud tvoje změna mění
výsledek pro stejný vstup (nová váha, jiný práh), zvyš `SCORING_VERSION`.

## Hlášení bezpečnostních problémů

Viz [`SECURITY.md`](SECURITY.md) - nehlásit přes veřejné issues.
