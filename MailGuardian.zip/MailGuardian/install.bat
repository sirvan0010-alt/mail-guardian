@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo ================================================
echo   MailGuardian - prvotni instalace (Windows)
echo ================================================
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo [!] Python nebyl nalezen v PATH.
    echo     Nainstaluj Python 3.10+ z https://www.python.org/downloads/
    echo     Pri instalaci ZASKRTNI "Add python.exe to PATH".
    echo.
    pause
    exit /b 1
)

echo [1/4] Vytvarim virtualni prostredi (venv)...
if exist venv (
    echo       venv uz existuje, preskakuji.
) else (
    python -m venv venv
    if errorlevel 1 (
        echo [!] Vytvoreni venv selhalo.
        pause
        exit /b 1
    )
)

echo [2/4] Instaluji zavislosti pro CLI...
call venv\Scripts\python.exe -m pip install --upgrade pip --quiet
call venv\Scripts\pip.exe install -r requirements.txt
if errorlevel 1 (
    echo [!] Instalace requirements.txt selhala.
    pause
    exit /b 1
)

echo [3/4] Instaluji zavislosti pro webove GUI (Streamlit)...
call venv\Scripts\pip.exe install -r requirements-gui.txt
if errorlevel 1 (
    echo [!] Instalace requirements-gui.txt selhala.
    pause
    exit /b 1
)

echo [4/4] Vytvarim zastupce na plose...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\make_shortcut.ps1"
if errorlevel 1 (
    echo [!] Zastupce se nepodarilo vytvorit - GUI ale i tak spustis
    echo     dvojklikem na "Spustit MailGuardian.bat" v teto slozce.
)

echo.
echo ================================================
echo   Hotovo!
echo ================================================
echo   Na plose je zastupce "MailGuardian" - dvojklikem
echo   se otevre webove GUI v prohlizeci.
echo.
echo   (Pro pristup k CLI pouzij "Spustit MailGuardian CLI.bat"
echo   v teto slozce - otevre terminal s aktivovanym venv.)
echo ================================================
pause
