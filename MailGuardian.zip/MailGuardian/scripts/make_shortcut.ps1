# make_shortcut.ps1
# Vytvori zastupce "MailGuardian" na plose, ktery spousti "Spustit MailGuardian.bat"
# ve slozce projektu. Volano z install.bat, nemusi se spoustet rucne.
#
# Pouziva jen COM objekt WScript.Shell, ktery je soucasti Windows - zadna
# externi zavislost, zadny modul k instalaci.

$ErrorActionPreference = "Stop"

$projectDir = Split-Path -Parent $PSScriptRoot
$targetBat  = Join-Path $projectDir "Spustit MailGuardian.bat"
$desktop    = [Environment]::GetFolderPath("Desktop")
$shortcutPath = Join-Path $desktop "MailGuardian.lnk"

if (-not (Test-Path $targetBat)) {
    Write-Host "[!] Nenalezen 'Spustit MailGuardian.bat' - zastupce se nevytvoril."
    exit 1
}

$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = $targetBat
$shortcut.WorkingDirectory = $projectDir
$shortcut.Description = "MailGuardian OSINT - webove GUI"
# shell32.dll ikona c. 13 je stit (bezpecnost) - zadny vlastni .ico soubor
# neni potreba, pouziva se systemova ikona, ktera uz na Windows existuje.
$shortcut.IconLocation = "$env:SystemRoot\System32\shell32.dll,13"
$shortcut.Save()

Write-Host "Zastupce vytvoren: $shortcutPath"
