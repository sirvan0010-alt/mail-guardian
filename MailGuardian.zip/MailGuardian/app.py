"""
app.py
Lokální webové rozhraní pro MailGuardian postavené na Streamlitu.

DŮLEŽITÉ: nejde o samostatnou reimplementaci logiky - všechny výpočty
(parsování, fingerprint, scoring, Identity Similarity, case suggestion,
Evidence Bundle) volají STEJNÉ funkce z modules/*.py a main.py, jaké
používá CLI. Tenhle soubor je čistě prezentační vrstva. Cíl: v CLI a GUI
nikdy neexistují dvě různé verze téže logiky vedle sebe.

Spuštění:
    streamlit run app.py
Otevře se http://localhost:8501 (jen lokální síťové rozhraní - Streamlit
ve výchozím nastavení naslouchá jen na localhost, žádná autentizace navíc
není potřeba pro čistě lokální použití).

GUI samo o sobě nemá stránku pro Gmail sync - .eml soubory se nahrávají
přes prohlížeč (st.file_uploader). Gmail sync (jen čtení, viz
modules/gmail_connector.py) i sledování složky pořád dělá CLI:
`python3 main.py sync` / `python3 main.py watch` (viz README) - GUI je
zatím nespouští na pozadí, jen zobrazuje výsledky toho, co je v databázi.
"""

import os
import sys
import tempfile
import hashlib
import argparse
from datetime import datetime

import streamlit as st
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from modules import parser as eml_parser
from modules import fingerprint as fp_module
from modules import similarity as similarity_module
from modules import database
from modules import report as report_module
from modules import exporter as exporter_module
from modules import ioc as ioc_module
from modules import case as case_module
import main as cli  # sdílená logika s CLI (_process_file, cmd_bundle, DB_PATH...)

st.set_page_config(page_title="MailGuardian", page_icon="🛡️", layout="wide")

UPLOAD_DIR = os.path.join(os.path.dirname(__file__), 'emails', 'uploaded')
os.makedirs(UPLOAD_DIR, exist_ok=True)


# ---------------------------------------------------------------------------
# Sdílené pomocné funkce
# ---------------------------------------------------------------------------

def render_eml_help():
    """Rozklikávací nápověda 'jak získat .eml soubor' - stejný text na
    každém místě v GUI, kde se něco nahrává (Přidat, Case add, Suggest,
    Evidence Bundle), ať to není na každé stránce jinak/nekonzistentně."""
    with st.expander("❓ Jak získám .eml soubor? Jaký formát/velikost?"):
        st.markdown(f"""
**Formát:** jen `.eml` (RFC 822/MIME - syrový text e-mailu se všemi
hlavičkami). **NE** `.msg` (Outlook desktop formát), **NE** PDF export,
**NE** screenshot ani zkopírovaný text zprávy - ty neobsahují hlavičky
(Received řetězec, DKIM, SPF...), na kterých většina analýzy stojí.

**Velikost:** technicky bez pevného limitu, ale e-maily nad
~{eml_parser.LARGE_FILE_WARNING_THRESHOLD_MB}MB (typicky kvůli velké příloze)
zaberou výrazně víc paměti a času - běžný e-mail bez velkých příloh je
řádově desítky KB až jednotky MB, tam žádný rozdíl nepoznáš.

---

**Gmail (webové rozhraní, ne appka):**
1. Otevři podezřelý e-mail
2. Klikni na tři tečky vpravo nahoře v okně zprávy (⋮)
3. Vyber **"Zobrazit původní zprávu"** ("Show original")
4. V nové záložce klikni na **"Stáhnout původní zprávu"** ("Download Original")
5. Stáhne se `.eml` soubor - přetáhni ho sem nebo ho vyber přes tlačítko níž

**Outlook (webový, outlook.com/office.com):**
1. Otevři e-mail → tři tečky (⋯) v pravém horním rohu zprávy
2. **"Zobrazit" → "Zobrazit zdroj zprávy"**, nebo rovnou **"Stáhnout"**

**Outlook (desktopová aplikace, Windows):**
- Přetažení e-mailu ze seznamu zpráv do složky v počítači uloží `.msg`,
  ne `.eml` - MailGuardian `.msg` neumí
- Funguje: nainstalovat doplněk/skript pro export do `.eml`, nebo
  otevřít stejnou schránku přes **outlook.com** ve webovém prohlížeči
  a postupovat podle kroků výše

**Apple Mail (macOS):**
1. Vyber e-mail v seznamu zpráv
2. Přetáhni ho myší přímo na plochu nebo do složky ve Finderu -
   uloží se rovnou jako `.eml`
   (alternativně: **Soubor → Uložit jako…**)

**Thunderbird:**
1. Klikni pravým tlačítkem na e-mail → **"Uložit jako" → "Soubor"**,
   nebo ho přetáhni myší do složky v počítači - obojí uloží `.eml`

**Seznam.cz a další poskytovatelé:** hledej v menu u zprávy něco jako
**"Zobrazit zdroj"**, **"Stáhnout originál"** nebo **"Export"** - název
se liší, princip (stáhnout syrová data zprávy, ne jen přečíst text) je
stejný.

**Nemáš žádný z těchhle a chceš to jen vyzkoušet?** V balíčku jsou
ukázkové e-maily v `tests/fixtures/eml/` (např. `spoofed_phishing.eml`),
klidně je nahraj a podívej se, jak výstup vypadá.
        """)


def save_uploaded_file(uploaded_file, dest_dir: str) -> str:
    """Uloží soubor nahraný přes st.file_uploader na disk a vrátí cestu.

    Bezpečnost: `uploaded_file.name` je STRING, který si o sobě tvrdí
    prohlížeč na klientovi - plně pod kontrolou toho, kdo GUI používá,
    ne důvěryhodný vstup. Bez sanitizace (`../../../tmp/evil.eml` jako
    název nahrávaného souboru) by šlo zapsat mimo `dest_dir` - stejná
    třída zranitelnosti jako path traversal přes jméno case (viz
    modules/case.py `_validate_case_name`, v0.20). `os.path.basename()`
    samo o sobě NESTAČÍ - basename('..') vrátí '..' beze změny (žádné
    lomítko k oříznutí), a `os.path.join(dest_dir, '..')` by pořád
    unikl o úroveň výš, proto extra kontrola na '.'/'..'/prázdný název.

    Pozor na kolizi jmen: pokud v dest_dir už existuje soubor se stejným
    názvem, ale JINÝM obsahem, přidá se k názvu krátký hash obsahu - jinak
    by druhý upload tiše přepsal první (stejná past, jakou jsme narazili a
    zdokumentovali u case-add v v0.17 - dva zdrojové soubory se stejným
    jménem se v případě case ukládání kolidují na stejné cestě)."""
    raw = uploaded_file.getvalue()
    safe_name = os.path.basename(uploaded_file.name or '')
    if not safe_name or safe_name in ('.', '..'):
        safe_name = 'upload.eml'
    dest_path = os.path.join(dest_dir, safe_name)
    if os.path.exists(dest_path):
        with open(dest_path, 'rb') as f:
            existing = f.read()
        if existing != raw:
            stem, ext = os.path.splitext(safe_name)
            suffix = hashlib.sha256(raw).hexdigest()[:8]
            dest_path = os.path.join(dest_dir, f"{stem}_{suffix}{ext}")
    with open(dest_path, 'wb') as f:
        f.write(raw)
    return dest_path


def get_main_conn():
    return database.connect(cli.DB_PATH)


def _threat_badge(score: float) -> str:
    """Stejné prahy jako case.build_relationship_graph() - 60/30 - ať je
    barevné kódování konzistentní napříč celým GUI, ne jen v grafu."""
    if score >= 60:
        return "🟥"
    if score >= 30:
        return "🟨"
    return "🟩"


def _confidence_badge(score) -> str:
    """Confidence je opačně orientované než threat (vyšší = lepší pokrytí
    dat), takže barvy jsou zrcadlené, ne stejné prahy jako u threat."""
    if score is None:
        return "⬜"
    if score >= 60:
        return "🟩"
    if score >= 30:
        return "🟨"
    return "🟥"


def render_scores(fp: dict):
    """Threat + Confidence skóre s barevným odznakem (🟥/🟨/🟩) - stejná
    data jako CLI `_print_threat()`, jen vizuálně čitelnější na první pohled."""
    threat = fp.get('threat') or {}
    confidence = fp.get('confidence') or {}
    col1, col2 = st.columns(2)
    with col1:
        score = threat.get('score_pct', 0)
        st.metric(f"{_threat_badge(score)} Threat skóre", f"{score}%", help=threat.get('verdict', ''))
        if threat.get('verdict'):
            st.caption(threat['verdict'])
    with col2:
        cscore = confidence.get('score_pct')
        st.metric(f"{_confidence_badge(cscore)} Confidence skóre", f"{cscore}%" if cscore is not None else "—",
                   help=confidence.get('verdict', ''))
        if confidence.get('verdict'):
            st.caption(confidence['verdict'])

    if threat.get('findings'):
        with st.expander(f"Threat nálezy ({len(threat['findings'])})"):
            for finding in threat['findings']:
                st.markdown(f"- {finding}")


def render_case_suggestions(candidates: list, container=st):
    for c in candidates:
        marker = " 🔴 silný samostatný signál" if c['strong_signal_hit'] else ""
        with container.expander(f"case '{c['case_name']}' — shoda {c['best_score']}%{marker} "
                                 f"({c['email_count']} e-mailů)"):
            if c['best_match_file']:
                st.write(f"Nejbližší e-mail: `{os.path.basename(c['best_match_file'])}`")
            if c['shared_domains']:
                st.write(f"Shodné domény: {', '.join(c['shared_domains'])}")
            if c['shared_ips']:
                st.write(f"Shodné IP: {', '.join(c['shared_ips'])}")
            if c['shared_attachment_sha256']:
                st.write(f"Shodné hashe příloh: {', '.join(h[:16] + '…' for h in c['shared_attachment_sha256'])}")
            auto = " (přidalo by se automaticky s --auto-case)" if case_module.should_auto_assign(c) else ""
            st.caption(f"Práh pro automatické přidání: {case_module.AUTO_ASSIGN_CONFIRM_THRESHOLD}%{auto}")


# ---------------------------------------------------------------------------
# Stránka: Přidat e-maily
# ---------------------------------------------------------------------------

def page_add():
    st.title("📥 Přidat e-maily")
    st.caption("Nahraj .eml soubory z prohlížeče - stejná logika jako `python3 main.py add`.")

    with st.expander("Volitelný enrichment (živá síťová volání)"):
        c1, c2, c3, c4 = st.columns(4)
        enable_abuseipdb = c1.checkbox("AbuseIPDB", help="Reputace primární IP (vyžaduje API klíč)")
        enable_virustotal = c2.checkbox("VirusTotal", help="Reputace IP/URL/hash (vyžaduje API klíč)")
        enable_whois = c3.checkbox("WHOIS", help="Stáří/registrátor domény odesílatele")
        enable_dns = c4.checkbox("DNS", help="A/MX/TXT/NS domény odesílatele")
    auto_case = st.checkbox("Po přidání zkusit automaticky zařadit do existujícího case (--auto-case)")

    render_eml_help()
    uploaded_files = st.file_uploader("Vyber .eml soubory", type=['eml'], accept_multiple_files=True)

    if uploaded_files and st.button("Zpracovat", type="primary"):
        conn = get_main_conn()
        for uf in uploaded_files:
            path = save_uploaded_file(uf, UPLOAD_DIR)
            try:
                with st.spinner(f"Zpracovávám {uf.name}…"):
                    email_id, fp, was_changed = cli._process_file(
                        conn, path, enable_abuseipdb=enable_abuseipdb, enable_virustotal=enable_virustotal,
                        enable_whois=enable_whois, enable_dns=enable_dns,
                    )
            except eml_parser.UnparseableEmailError as e:
                # cli._process_file() sám sys.exit() nevolá (viz v0.21) -
                # tohle je "normální" cesta jak se o chybě dozvíme.
                st.error(f"{uf.name}: {e}")
                st.divider()
                continue
            st.success(f"[{email_id}] {uf.name}" + ("" if was_changed else " (beze změny oproti minulému běhu)"))
            render_scores(fp)

            if auto_case:
                candidates = case_module.suggest_cases_for_fingerprint(fp)
                if not candidates:
                    st.info("Žádný existující case neodpovídá.")
                else:
                    top = candidates[0]
                    if case_module.should_auto_assign(top):
                        case_name = top['case_name']
                        if not case_module.case_exists(case_name):
                            case_module.create_case(case_name)
                        case_conn = database.connect(case_module.case_db_path(case_name))
                        import shutil
                        dest = os.path.join(case_module.case_originals_dir(case_name), os.path.basename(path))
                        shutil.copy2(path, dest)
                        cli._process_file(case_conn, dest)
                        reason = "silný samostatný signál" if top['strong_signal_hit'] else f"{top['best_score']}% shoda"
                        st.success(f"➜ automaticky přidáno do case **{case_name}** ({reason})")
                    else:
                        st.warning("Možná shoda pod prahem pro automatické přidání - zkontroluj ručně:")
                    render_case_suggestions(candidates)
            st.divider()


# ---------------------------------------------------------------------------
# Stránka: Databáze
# ---------------------------------------------------------------------------

def page_database():
    st.title("📊 Databáze e-mailů")
    conn = get_main_conn()
    emails = database.get_all_emails(conn)

    if not emails:
        st.info("Databáze je zatím prázdná. Přidej e-maily na stránce '📥 Přidat e-maily'.")
        return

    rows = []
    for e in emails:
        fp = e.get('fingerprint') or {}
        threat = fp.get('threat') or {}
        rows.append({
            'id': e['id'],
            'soubor': os.path.basename(e['filepath']),
            'od': e.get('from_addr'),
            'předmět': e.get('subject'),
            'datum': e.get('date_header'),
            'threat %': threat.get('score_pct', 0),
            'verdikt': threat.get('verdict', ''),
        })
    df = pd.DataFrame(rows)
    st.dataframe(
        df, width='stretch', hide_index=True,
        column_config={
            'threat %': st.column_config.ProgressColumn('threat %', min_value=0, max_value=100, format="%d%%"),
        },
    )
    st.caption(f"Celkem {len(emails)} e-mailů.")

    selected_id = st.selectbox(
        "Zobrazit detail", options=[e['id'] for e in emails],
        format_func=lambda i: next(os.path.basename(e['filepath']) for e in emails if e['id'] == i),
    )
    if selected_id is not None:
        email = next(e for e in emails if e['id'] == selected_id)
        fp = email.get('fingerprint') or {}
        st.subheader(os.path.basename(email['filepath']))
        render_scores(fp)

        iocs = ioc_module.extract_iocs(fp)
        with st.expander("IOC"):
            for category, values in iocs.items():
                if values:
                    st.write(f"**{category}**: {', '.join(str(v) for v in values)}")

        whois_data, dns_data = fp.get('whois'), fp.get('dns')
        if whois_data or dns_data:
            with st.expander("WHOIS / DNS"):
                if whois_data and whois_data.get('available'):
                    age = whois_data.get('domain_age_days')
                    st.write(f"Registrováno: {whois_data.get('creation_date') or 'neznámo'} "
                             f"({age if age is not None else '?'} dní), "
                             f"registrátor: {whois_data.get('registrar') or '—'}")
                elif whois_data:
                    st.caption(f"WHOIS dotaz selhal: {whois_data.get('error')}")
                if dns_data:
                    mx_records = dns_data.get('MX', {}).get('records', [])
                    txt_records = dns_data.get('TXT', {}).get('records', [])
                    mx_text = ', '.join(r['value'] for r in mx_records[:3]) or '—'
                    spf = next((r['value'] for r in txt_records if 'spf1' in (r.get('value') or '')), None)
                    st.write(f"MX: {mx_text}")
                    st.write(f"SPF: {spf or 'chybí'}")

        import json as json_lib
        st.download_button(
            "Stáhnout fingerprint (JSON)",
            data=json_lib.dumps(fp, indent=2, ensure_ascii=False, default=str),
            file_name=f"fingerprint_{os.path.basename(email['filepath'])}.json",
            mime="application/json",
        )


# ---------------------------------------------------------------------------
# Stránka: Porovnat dva e-maily
# ---------------------------------------------------------------------------

def page_compare():
    st.title("🔍 Porovnat dva e-maily")
    conn = get_main_conn()
    emails = database.get_all_emails(conn)

    if len(emails) < 2:
        st.info("Potřebuješ aspoň 2 e-maily v databázi - přidej je na stránce '📥 Přidat e-maily'.")
        return

    options = {e['id']: os.path.basename(e['filepath']) for e in emails}
    col1, col2 = st.columns(2)
    id_a = col1.selectbox("E-mail A", options=list(options), format_func=lambda i: options[i])
    id_b = col2.selectbox("E-mail B", options=list(options), format_func=lambda i: options[i],
                           index=min(1, len(options) - 1))

    if id_a == id_b:
        st.warning("Vyber dva různé e-maily.")
        return

    if st.button("Porovnat", type="primary"):
        email_a = next(e for e in emails if e['id'] == id_a)
        email_b = next(e for e in emails if e['id'] == id_b)
        result = similarity_module.compare(email_a['fingerprint'], email_b['fingerprint'])
        database.store_comparison(conn, id_a, id_b, result)

        st.metric(f"{_threat_badge(result['score_pct'])} Identity Similarity", f"{result['score_pct']}%",
                   help=result['verdict'])
        st.caption(result['verdict'])

        if result.get('breakdown'):
            breakdown_df = pd.DataFrame(
                sorted(result['breakdown'].items(), key=lambda kv: kv[1], reverse=True),
                columns=['signál', 'váha'],
            )
            st.bar_chart(breakdown_df.set_index('signál'))

        with tempfile.TemporaryDirectory() as tmp:
            html_path = os.path.join(tmp, 'report.html')
            report_module.generate_html(email_a, email_b, result, html_path)
            with open(html_path, encoding='utf-8') as f:
                html_content = f.read()
            st.download_button("Stáhnout HTML report", data=html_content,
                                file_name=f"report_{options[id_a]}_vs_{options[id_b]}.html", mime="text/html")

            json_data = exporter_module.comparison_export(email_a, email_b, result)
            import json as json_lib
            st.download_button("Stáhnout JSON report", data=json_lib.dumps(json_data, indent=2, ensure_ascii=False),
                                file_name=f"report_{options[id_a]}_vs_{options[id_b]}.json", mime="application/json")

        with st.expander("Zobrazit HTML report v prohlížeči"):
            st.components.v1.html(html_content, height=800, scrolling=True)


# ---------------------------------------------------------------------------
# Stránka: Case mode
# ---------------------------------------------------------------------------

def page_case():
    st.title("🗂️ Case mode")

    tab_overview, tab_create, tab_suggest = st.tabs(["Přehled", "Vytvořit / přidat", "Návrh case (suggest-case)"])

    with tab_overview:
        cases = case_module.list_cases()
        if not cases:
            st.info("Zatím žádné case složky. Vytvoř první v záložce 'Vytvořit / přidat'.")
        else:
            selected_case = st.selectbox("Case", options=cases)
            conn = database.connect(case_module.case_db_path(selected_case))
            case_emails = database.get_all_emails(conn)
            comparisons = database.get_all_comparisons(conn)

            st.metric("E-mailů v case", len(case_emails))

            if case_emails:
                timeline = case_module.build_timeline(case_emails)
                st.subheader("Timeline")
                st.dataframe(pd.DataFrame(timeline), width='stretch', hide_index=True)

                st.subheader("Graf vztahů")
                threshold = st.slider("Práh pro hranu v grafu (%)", 0, 100, 30, key=f"graph_th_{selected_case}")
                dot = case_module.build_relationship_graph(case_emails, comparisons, threshold=threshold)
                st.graphviz_chart(dot)

    with tab_create:
        new_case_name = st.text_input("Název nového case")
        if st.button("Vytvořit case") and new_case_name:
            try:
                if case_module.case_exists(new_case_name):
                    st.warning(f"Case '{new_case_name}' už existuje.")
                else:
                    case_module.create_case(new_case_name)
                    st.success(f"Case '{new_case_name}' vytvořen.")
                    st.rerun()
            except case_module.InvalidCaseName as e:
                st.error(f"Neplatný název case: {e}")

        st.divider()
        st.subheader("Přidat e-mail do case")
        existing_cases = case_module.list_cases()
        if existing_cases:
            target_case = st.selectbox("Cílový case", options=existing_cases, key="add_target_case")
            render_eml_help()
            uf = st.file_uploader("E-mail (.eml)", type=['eml'], key="case_add_upload")
            if uf and st.button("Přidat do case"):
                path = save_uploaded_file(uf, UPLOAD_DIR)
                import shutil
                dest = os.path.join(case_module.case_originals_dir(target_case), os.path.basename(path))
                shutil.copy2(path, dest)
                case_conn = database.connect(case_module.case_db_path(target_case))
                try:
                    email_id, fp, _ = cli._process_file(case_conn, dest)
                except eml_parser.UnparseableEmailError as e:
                    st.error(f"{uf.name}: {e}")
                else:
                    st.success(f"Přidáno do case '{target_case}' (id={email_id})")
                    render_scores(fp)
        else:
            st.caption("Nejdřív vytvoř case výše.")

    with tab_suggest:
        st.caption("Read-only - nic se nezapíše, jen se ukáže, kam by e-mail mohl patřit.")
        render_eml_help()
        uf = st.file_uploader("E-mail (.eml)", type=['eml'], key="suggest_upload")
        threshold = st.slider("Minimální Identity Similarity pro návrh (%)", 0, 100,
                               int(case_module.DEFAULT_SUGGEST_THRESHOLD))
        if uf and st.button("Navrhnout case"):
            path = save_uploaded_file(uf, UPLOAD_DIR)
            try:
                parsed = eml_parser.parse_eml(path)
            except eml_parser.UnparseableEmailError as e:
                st.error(f"{uf.name}: {e}")
            else:
                fp = fp_module.build_fingerprint(parsed)
                candidates = case_module.suggest_cases_for_fingerprint(fp, suggest_threshold=threshold)
                if not candidates:
                    st.info("Žádný existující case neodpovídá.")
                else:
                    render_case_suggestions(candidates)


# ---------------------------------------------------------------------------
# Stránka: Evidence Bundle
# ---------------------------------------------------------------------------

def page_evidence():
    st.title("📦 Evidence Bundle")
    st.caption("Zip s originály, HTML+JSON reportem, IOC exportem, audit logy a manifestem SHA-256 hashů - "
               "stejný formát jako `python3 main.py bundle`.")

    render_eml_help()
    uf_a = st.file_uploader("E-mail A", type=['eml'], key="bundle_a")
    uf_b = st.file_uploader("E-mail B", type=['eml'], key="bundle_b")

    c1, c2, c3, c4 = st.columns(4)
    enable_abuseipdb = c1.checkbox("AbuseIPDB", key="bundle_abuse")
    enable_virustotal = c2.checkbox("VirusTotal", key="bundle_vt")
    enable_whois = c3.checkbox("WHOIS", key="bundle_whois")
    enable_dns = c4.checkbox("DNS", key="bundle_dns")

    if uf_a and uf_b and st.button("Vytvořit Evidence Bundle", type="primary"):
        path_a = save_uploaded_file(uf_a, UPLOAD_DIR)
        path_b = save_uploaded_file(uf_b, UPLOAD_DIR)
        with tempfile.TemporaryDirectory() as tmp:
            out_path = os.path.join(tmp, f"Case_{datetime.now().strftime('%Y-%m-%d_%H%M%S')}.zip")
            args = argparse.Namespace(
                file_a=path_a, file_b=path_b, out=out_path,
                abuseipdb=enable_abuseipdb, virustotal=enable_virustotal,
                whois=enable_whois, dns=enable_dns,
            )
            try:
                with st.spinner("Generuji bundle…"):
                    cli.cmd_bundle(args)
            except eml_parser.UnparseableEmailError as e:
                st.error(str(e))
                st.stop()
            with open(out_path, 'rb') as f:
                bundle_bytes = f.read()
        st.success("Evidence Bundle vytvořen.")
        st.download_button("Stáhnout Evidence Bundle (.zip)", data=bundle_bytes,
                            file_name=os.path.basename(out_path), mime="application/zip")


# ---------------------------------------------------------------------------
# Navigace
# ---------------------------------------------------------------------------

def main():
    st.sidebar.title("🛡️ MailGuardian")
    st.sidebar.caption("Lokální forenzní analýza e-mailů - vše běží nad soubory, co nahraješ. "
                        "Gmail sync (jen čtení) je dostupný přes CLI: python3 main.py sync")

    pages = {
        "📥 Přidat e-maily": page_add,
        "📊 Databáze": page_database,
        "🔍 Porovnat": page_compare,
        "🗂️ Case mode": page_case,
        "📦 Evidence Bundle": page_evidence,
    }
    choice = st.sidebar.radio("Navigace", list(pages))
    st.sidebar.divider()
    st.sidebar.caption(
        "Živé sledování složky (bez GUI) pořád jede přes:\n\n`python3 main.py watch --folder emails/prichozi`"
    )
    pages[choice]()


if __name__ == '__main__':
    main()
