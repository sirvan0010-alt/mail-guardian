# Bezpečnostní politika

## Nahlášení zranitelnosti

Pokud najdeš bezpečnostní problém v MailGuardian OSINT, prosím
**nehlas ho přes veřejné GitHub issue**. Místo toho kontaktuj
udržovatele přímo (viz kontakt v profilu repozitáře) s popisem
problému a případně kroky k reprodukci.

## Co je v rozsahu

- Chyby v parsování `.eml`, které by mohly vést ke spuštění
  neočekávaného kódu (např. přes záludně sestavené hlavičky/přílohy)
- Únik API klíčů nebo citlivých dat (např. do logů, cache, reportů)
- Chyby v gracefully degradaci síťových modulů, které by mohly
  odeslat data někam jinam, než uživatel čeká

## Co NENÍ bezpečnostní problém (nahlas jako běžné issue)

- Nepřesnosti v heuristické detekci (homoglyph, MIME fingerprint,
  Message-ID generátor) - jsou to záměrně "orientační" nástroje, ne
  garantovaně přesné, viz `docs/architecture.md`
- Chybějící DNS/WHOIS funkcionalita nebo chyby v ní - tyhle moduly
  nebyly nikdy ověřené proti živému provozu (viz README), hlaš je jako
  běžné bugy s konkrétním příkladem odpovědi, na které to selhalo

## Známá omezení (ne zranitelnosti, ale stojí za zmínku)

- WHOIS/DNS moduly (`whois_lookup.py`, `dns_lookup.py`) implementují
  syrové síťové protokoly bez ověření proti reálným serverům -
  parsovací logika je testovaná, síťová komunikace ne
- Cache soubory (`database/*_cache.db`) obsahují API odpovědi v čistém
  textu - nejsou šifrované, drž je mimo sdílené/veřejné prostředí
- `config.ini` s API klíči by se nikdy neměl commitovat (je v
  `.gitignore`, ale zkontroluj to před prvním pushem)
