# Architektura MailGuardian OSINT

Tenhle dokument popisuje, jak jednotlivé moduly zapadají do sebe, jaká
data mezi sebou předávají, a proč je to postavené zrovna takhle. Pro
"jak to použít" viz hlavní [README](../README.md).

## Vrstvy

```
┌─────────────────────────────────────────────────────────┐
│  main.py (CLI)                                            │
│  Parsuje argumenty, orchestruje moduly, tiskne výstup.     │
│  Neobsahuje žádnou analytickou logiku samu o sobě.          │
└─────────────────────────────────────────────────────────┘
                          │
        ┌─────────────────┼─────────────────┐
        ▼                 ▼                 ▼
┌───────────────┐ ┌───────────────┐ ┌───────────────┐
│  EXTRAKCE      │ │  SCORING       │ │  ENRICHMENT    │
│  parser.py     │ │  similarity.py │ │  geoip.py       │
│  urls.py       │ │  threat.py     │ │  abuseipdb.py   │
│  attachments.py│ │  confidence.py │ │  virustotal.py  │
│  mime_fp.py    │ │                │ │  whois_lookup.py│
│  message_id_fp │ │                │ │  dns_lookup.py  │
│  html_fp.py    │ │                │ │                 │
│  received_chain│ │                │ │                 │
│  homoglyph.py  │ │                │ │                 │
└───────────────┘ └───────────────┘ └───────────────┘
        │                 │                 │
        └─────────────────┼─────────────────┘
                          ▼
                ┌───────────────────┐
                │  fingerprint.py     │
                │  Skládá výstupy      │
                │  extrakce+enrichmentu │
                │  do jednoho fp dictu,  │
                │  spouští scoring.       │
                └───────────────────┘
                          │
        ┌─────────────────┼─────────────────┐
        ▼                 ▼                 ▼
┌───────────────┐ ┌───────────────┐ ┌───────────────┐
│  PERZISTENCE   │ │  VÝSTUP        │ │  FORENZNÍ       │
│  database.py   │ │  report.py     │ │  evidence.py    │
│                │ │  exporter.py   │ │  audit.py       │
│                │ │  ioc.py        │ │                 │
└───────────────┘ └───────────────┘ └───────────────┘
```

`case.py` je samostatná nadstavba nad stejnými moduly - viz sekce Case
mode níž.

## Datový tok jednoho e-mailu

1. **`parser.parse_eml(filepath)`** načte `.eml`, vrátí `parsed: dict`
   se surovými/napůl zpracovanými daty: hlavičky, IP adresy, DKIM,
   Authentication-Results, odkazy, přílohy, ARC řetězec, Received
   řetězec (přes `received_chain.py`), MIME otisk (`mime_fp.py`),
   Message-ID otisk (`message_id_fp.py`), HTML otisk (`html_fp.py`).
   Tahle funkce nikdy nedělá síťové volání.

2. **`fingerprint.build_fingerprint(parsed, ...)`** vezme `parsed` a
   sestaví `fp: dict` - normalizovaný "otisk" e-mailu. Tady se volitelně
   (přes `enable_*` parametry) spouští síťový enrichment (GeoIP,
   AbuseIPDB, VirusTotal, WHOIS, DNS). Na konci zavolá `threat.assess(fp)`
   a `confidence.assess(fp)` a výsledky přidá do `fp['threat']` /
   `fp['confidence']`.

3. **`database.store_email(conn, parsed, fp)`** uloží `fp` jako JSON blob
   do SQLite (`fingerprint_json` sloupec). Dedup podle SHA-256 obsahu
   souboru - stejný obsah na stejné cestě se neukládá znovu (pokud
   `force_update=True`, např. kvůli enrichmentu, přepíše se i tak).

4. **`similarity.compare(fp_a, fp_b)`** porovná DVA fingerprinty, vrátí
   Identity Similarity skóre. Nezávisle na tom `fp['threat']` a
   `fp['confidence']` už jsou hotové z kroku 2 - není potřeba nic dalšího
   počítat pro zobrazení threat/confidence u jednotlivého e-mailu.

5. **`report.generate_html(...)`** / **`exporter.comparison_export(...)`**
   vezmou dva uložené e-mail záznamy (s `fp` uvnitř) + výsledek
   `similarity.compare()` a vyrenderují HTML/JSON výstup.

## Tři nezávislá skóre

Tohle je nejdůležitější architektonické rozhodnutí v projektu (viz
README changelog v0.4) - tři čísla odpovídají na tři různé otázky a
záměrně se nemíchají do jednoho:

| Skóre | Otázka | Vstup | Kde se počítá |
|---|---|---|---|
| **Identity Similarity** | Jsou tyhle DVA e-maily ze stejného zdroje? | 2 fingerprinty | `similarity.compare()` |
| **Threat** | Jak rizikový je TENHLE JEDEN e-mail? | 1 fingerprint | `threat.assess()`, uvnitř `build_fingerprint()` |
| **Confidence** | Kolik kvalitních dat máme k dispozici? | 1 fingerprint | `confidence.assess()`, uvnitř `build_fingerprint()` |

## Vážený scoring - dynamický jmenovatel

`similarity.py` a `threat.py` používají vážený součet signálů
normalizovaný na 0-100 %. Kritické pravidlo, na které narazily DVĚ
samostatné třídy bugů během vývoje (viz README changelog v0.1.2 a
v0.10):

**Jmenovatel (MAX_SCORE / threat_max) NESMÍ být prostý součet všech
možných vah**, pokud:
- některé signály jsou vzájemně se vylučující (např. `primary_ip` vs
  `any_ip_overlap` - nikdy nemůžou nastat obě najednou), NEBO
- některé signály se počítají jen když byl proveden volitelný
  enrichment (AbuseIPDB/VirusTotal/WHOIS - výchozí vypnuto).

V obou případech by naivní součet způsobil, že 100 % skóre by bylo
nedosažitelné pro (podmnožinu) uživatelů, i kdyby úplně všechno sedělo.
Řešení: jmenovatel se počítá buď jako explicitní "nejlepší reálně
dosažitelná kombinace" (`similarity.py` - `MAX_SCORE` je ručně sečtená
kombinace vylučujících se skupin), nebo dynamicky za běhu podle toho,
který enrichment byl skutečně proveden (`threat.py` - `threat_max` roste
o váhu jen když `fp.get('abuseipdb')` apod. není `None`).

Testovací sada (`tests/test_similarity.py`,
`tests/test_threat.py`) obsahuje brute-force test přes stovky/tisíce
kombinací signálů, který ověřuje, že skóre nikdy nepřekročí 100 % a v
nejlepším případě ho přesně dosáhne. Kdykoliv se přidává nový signál do
`WEIGHTS`/`THREAT_WEIGHTS`, tenhle test musí zůstat zelený.

## Case mode

`case.py` je tenká vrstva NAD stejnými moduly, ne duplicitní
implementace. Klíčový trik: `_process_file()`, `database.*`,
`similarity.compare()`, `report.generate_html()` už berou `conn`/cestu
jako parametr, takže Case mode jen předá jinou (izolovanou) SQLite
databázi (`cases/<jméno>/case.db`) a jiný cílový adresář - žádná
existující funkce nemusela vědět, že běží "v case".

## Evidence mode a determinismus

`fingerprint.build_fingerprint()` je navržený tak, aby stejný `.eml`
vstup vždy dal bitově identický `fp` výstup (ověřeno testem
`test_deterministic_parse_same_file_twice`). To je nutná podmínka pro
to, aby `evidence.py` mohl hashovat JSON export jako "otisk" analýzy -
kdyby se pořadí položek v listech/dictech měnilo mezi běhy, hash by se
měnil, i když se obsah nezměnil.

Praktický důsledek pro budoucí vývoj: kdykoliv přibude nové pole do
`fp`, které NENÍ deterministické (např. timestamp analýzy), patří do
samostatného `manifest.json`/`audit.log`, ne do `fp` samotného.

## Optional enrichment - společný vzor

Všech pět síťových/API modulů (`geoip.py`, `abuseipdb.py`,
`virustotal.py`, `whois_lookup.py`, `dns_lookup.py`) sdílí stejný tvar:

- `is_available()` - zjistí, jestli je modul vůbec použitelný (API klíč
  nastavený / databáze existuje), BEZ síťového volání
- hlavní `lookup()`/`query()` funkce NIKDY nevyhazuje výjimku - při
  jakémkoliv problému vrátí `{'available': False, 'error': '...'}`
- výchozí chování nástroje je BEZ enrichmentu - zapíná se explicitně
  (`--abuseipdb`, `--virustotal`, `--whois`, `--dns`) nebo automaticky
  jen pokud jde o lokální zdarma dostupnou databázi (GeoIP)

Tenhle vzor umožňuje, aby `threat.py`/`fingerprint.py` volaly enrichment
bez `try/except` na volajícím konci - odpovědnost za "nikdy nespadnout"
je uvnitř enrichment modulu.

## Proč ne plugin architektura (zatím)

Zvažováno opakovaně (viz README), zatím záměrně odloženo. Důvod: ~22
modulů má zásadně odlišné tvary výstupu - `parser.py` vrací syrová data,
`similarity.py` porovnává DVA fingerprinty, `threat.py`/`confidence.py`
hodnotí JEDEN, `evidence.py` počítá hashe. Vynucení jednotného
`{findings, score, metadata}` rozhraní by buď zploštilo užitečné rozdíly
mezi těmahle kategoriemi, nebo by rozhraní muselo být tak obecné, že by
nic nezjednodušilo. Dává smysl přehodnotit, až/pokud poroste počet
skutečně ZAMĚNITELNÝCH analyzátorů (např. víc než jeden reputační zdroj
téhož typu dat).

## Výkon

Viz [`benchmark.py`](../benchmark.py) - parse+fingerprint škáluje
lineárně (~15ms/e-mail na běžném stroji), ale `compare-all`/`case
compare` škáluje **O(n²)** (porovnává každý pár). Pro stovky e-mailů to
není problém (desítky vteřin), ale pro case složky s tisíci e-mailů by
se to mohlo stát úzkým hrdlem - zatím neřešeno, protože reálné case
složky bývají řádově menší. Pokud by to jednou byl problém, řešení by
bylo buď (a) předfiltrovat páry k porovnání podle nějakého levného
indexu (stejná doména/IP) místo všech-se-všemi, nebo (b) paralelizovat.
