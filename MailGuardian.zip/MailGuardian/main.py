#!/usr/bin/env python3
"""
MailGuardian OSINT - main.py
Lokální forenzní nástroj pro porovnávání .eml souborů a hledání shodné
infrastruktury (IP, DKIM, User-Agent, styl Message-ID) mezi e-maily.

Použití:
    python3 main.py add emails/mail1.eml emails/mail2.eml ...
        -> naparsuje a uloží e-maily do databáze

    python3 main.py compare emails/mail1.eml emails/mail2.eml
        -> naparsuje (pokud ještě nejsou v DB), porovná a vypíše skóre + HTML report

    python3 main.py compare-all
        -> porovná všechny e-maily uložené v databázi mezi sebou (matice shody)

    python3 main.py list
        -> vypíše všechny uložené e-maily

    python3 main.py watch
        -> jednorázově zkontroluje složku (výchozí emails/), zpracuje nové .eml
           soubory a porovná je se všemi ostatními; s --interval SEC běží stále
           dokola (Ctrl+C pro ukončení)

    python3 main.py ioc emails/mail1.eml
        -> vytáhne IOC (IP, domény, URL, e-maily, hashe příloh) do JSON

    python3 main.py bundle emails/mail1.eml emails/mail2.eml
        -> vytvoří Evidence Bundle (zip): originály .eml, HTML+JSON report,
           IOC, integrity manifest (SHA-256 všeho) a audit log
"""

import argparse
import configparser
import glob
import os
import shutil
import sys
import tempfile
import time
import zipfile

from modules import parser as eml_parser
from modules import fingerprint as fp_module
from modules import similarity
from modules import database
from modules import report
from modules import exporter
from modules import ioc as ioc_module
from modules import evidence
from modules import case as case_module
from modules import gmail_connector
from modules.audit import AuditLog

DB_PATH = os.path.join(os.path.dirname(__file__), 'database', 'fingerprints.db')
REPORTS_DIR = os.path.join(os.path.dirname(__file__), 'reports')
CONFIG_PATH = os.path.join(os.path.dirname(__file__), 'config.ini')
GMAIL_EMAILS_DIR = os.path.join(os.path.dirname(__file__), 'emails', 'gmail')


def _gmail_config() -> dict:
    """Čte [gmail] sekci z config.ini. Nejde o obecný konfigurační modul
    pro celý projekt (viz docs/architecture.md - proč zatím ne pro váhy
    scoringu), jen pro Gmail sync nastavení, které se scoringem vůbec
    nesouvisí, takže riziko je jiné."""
    defaults = {
        'client_id': None,
        'client_secret': None,
        'default_query': 'label:INBOX newer_than:30d',
        'default_max': 50,
        'max_allowed': 1000,
    }
    if not os.path.exists(CONFIG_PATH):
        return defaults
    cfg = configparser.ConfigParser()
    cfg.read(CONFIG_PATH)
    if not cfg.has_section('gmail'):
        return defaults
    return {
        'client_id': cfg.get('gmail', 'client_id', fallback=None),
        'client_secret': cfg.get('gmail', 'client_secret', fallback=None),
        'default_query': cfg.get('gmail', 'default_query', fallback=defaults['default_query']),
        'default_max': cfg.getint('gmail', 'default_max', fallback=defaults['default_max']),
        'max_allowed': cfg.getint('gmail', 'max_allowed', fallback=defaults['max_allowed']),
    }


def _process_file(conn, filepath: str, audit=None, enable_abuseipdb: bool = False,
                   enable_virustotal: bool = False, enable_whois: bool = False, enable_dns: bool = False):
    """Naparsuje .eml, vytvoří fingerprint, uloží do DB, vrátí (id, fingerprint, was_changed).
    audit: volitelný AuditLog - pokud předán, zaloguje kroky parsování.
    enable_abuseipdb / enable_virustotal / enable_whois / enable_dns: pokud
    True, dotáže se na příslušné obohacení (síťové volání - viz
    modules/abuseipdb.py, modules/virustotal.py, modules/whois_lookup.py,
    modules/dns_lookup.py)."""
    if not os.path.exists(filepath):
        print(f"[!] Soubor nenalezen: {filepath}")
        sys.exit(1)
    parsed = eml_parser.parse_eml(filepath, audit=audit)
    fp = fp_module.build_fingerprint(parsed, enable_abuseipdb=enable_abuseipdb,
                                      enable_virustotal=enable_virustotal,
                                      enable_whois=enable_whois, enable_dns=enable_dns, audit=audit)
    # force_update: pokud si uživatel řekl o enrichment, chceme ho uložit i
    # když se obsah souboru od minula nezměnil (jinak by store_email tiše
    # vrátil starý fingerprint bez enrichmentu).
    any_enrichment = enable_abuseipdb or enable_virustotal or enable_whois or enable_dns
    email_id, was_changed = database.store_email(conn, parsed, fp, force_update=any_enrichment)
    return email_id, fp, was_changed


def _print_threat(fp: dict, indent: str = "    ", verbose: bool = False):
    threat = fp.get('threat') or {}
    confidence = fp.get('confidence') or {}
    if confidence:
        print(f"{indent}ℹ Confidence: {confidence.get('score_pct')}% - {confidence.get('verdict')}")
        if verbose:
            for line in confidence.get('explain', []):
                print(f"{indent}    {line}")
    if threat.get('score_pct', 0) > 0:
        print(f"{indent}⚠ Threat skóre: {threat['score_pct']}% - {threat['verdict']}")
        for finding in threat.get('findings', []):
            print(f"{indent}    {finding}")


def cmd_add(args):
    conn = database.connect(DB_PATH)
    for path in args.files:
        try:
            email_id, fp, _ = _process_file(conn, path, enable_abuseipdb=args.abuseipdb,
                                             enable_virustotal=args.virustotal,
                                             enable_whois=args.whois, enable_dns=args.dns)
        except eml_parser.UnparseableEmailError as e:
            # Jeden zlomyslný/rozbitý soubor v dávce nesmí zastavit
            # zpracování zbytku - vypíšeme chybu a pokračujeme dál.
            print(f"[!] {e}")
            continue
        print(f"[+] Uloženo: {path} (id={email_id})")
        _print_threat(fp)
        if getattr(args, 'auto_case', False):
            stored = database.get_email(conn, email_id)
            _auto_assign_to_case(path, stored['date_header'], fp, enable_abuseipdb=args.abuseipdb,
                                  enable_virustotal=args.virustotal)


def cmd_compare(args):
    conn = database.connect(DB_PATH)
    id_a, _, _ = _process_file(conn, args.file_a, enable_abuseipdb=args.abuseipdb, enable_virustotal=args.virustotal,
                                         enable_whois=args.whois, enable_dns=args.dns)
    id_b, _, _ = _process_file(conn, args.file_b, enable_abuseipdb=args.abuseipdb, enable_virustotal=args.virustotal,
                                         enable_whois=args.whois, enable_dns=args.dns)

    all_emails = {e['id']: e for e in database.get_all_emails(conn)}
    email_a, email_b = all_emails[id_a], all_emails[id_b]

    result = similarity.compare(email_a['fingerprint'], email_b['fingerprint'])
    database.store_comparison(conn, id_a, id_b, result)

    print("\n=== IDENTITY SIMILARITY (podobnost původu) ===")
    print(f"A: {args.file_a}")
    print(f"B: {args.file_b}\n")
    for key, points in sorted(result['breakdown'].items(), key=lambda kv: kv[1], reverse=True):
        label = report.LABELS.get(key, key)
        print(f"  +{points} {label}")
    print(f"\nCelková podobnost: {result['score_pct']} %")
    print(f"Hodnocení: {result['verdict']}")

    print("\n=== THREAT SKÓRE (rizikovost jednotlivých e-mailů) ===")
    print(f"A ({os.path.basename(args.file_a)}):")
    _print_threat(email_a["fingerprint"], indent="  ", verbose=True)
    print(f"B ({os.path.basename(args.file_b)}):")
    _print_threat(email_b["fingerprint"], indent="  ", verbose=True)

    os.makedirs(REPORTS_DIR, exist_ok=True)
    out_name = f"report_{os.path.basename(args.file_a)}_vs_{os.path.basename(args.file_b)}"
    html_path = os.path.join(REPORTS_DIR, out_name + '.html')
    json_path = os.path.join(REPORTS_DIR, out_name + '.json')
    report.generate_html(email_a, email_b, result, html_path)
    exporter.write_json(exporter.comparison_export(email_a, email_b, result), json_path)
    print(f"\nHTML report: {html_path}")
    print(f"JSON export: {json_path}")


def cmd_compare_all(args):
    conn = database.connect(DB_PATH)
    emails = database.get_all_emails(conn)
    if len(emails) < 2:
        print("[!] V databázi jsou méně než 2 e-maily. Nejdřív přidej pomocí 'add'.")
        return

    print(f"\n=== MATICE SHODY ({len(emails)} e-mailů) ===\n")
    for i in range(len(emails)):
        for j in range(i + 1, len(emails)):
            a, b = emails[i], emails[j]
            result = similarity.compare(a['fingerprint'], b['fingerprint'])
            database.store_comparison(conn, a['id'], b['id'], result)
            noteworthy = result['score_pct'] >= 30 or 'SILNÝ JEDNOTLIVÝ NÁLEZ' in result['verdict']
            flag = " <-- " + result['verdict'] if noteworthy else ""
            print(f"{os.path.basename(a['filepath'])} vs {os.path.basename(b['filepath'])}: "
                  f"{result['score_pct']}%{flag}")


def cmd_list(args):
    conn = database.connect(DB_PATH)
    emails = database.get_all_emails(conn)
    if not emails:
        print("Databáze je prázdná.")
        return
    for e in emails:
        threat = (e['fingerprint'] or {}).get('threat', {})
        threat_flag = f" ⚠ threat={threat['score_pct']}%" if threat.get('score_pct', 0) > 0 else ""
        print(f"[{e['id']}] {e['filepath']} | od: {e['from_addr']} | předmět: {e['subject']}{threat_flag}")


def cmd_watch(args):
    conn = database.connect(DB_PATH)

    mode = f"opakovaně po {args.interval}s" if args.interval else "jednorázově"
    print(f"[*] Sleduji složku '{args.folder}' ({mode}), práh upozornění: {args.threshold}%")
    if args.interval:
        print("[*] Ctrl+C pro ukončení")

    try:
        while True:
            found = sorted(glob.glob(os.path.join(args.folder, '*.eml')))
            changed_files = []

            # Zpracujeme VŠECHNY soubory ve složce (ne jen "nové podle cesty") -
            # store_email uvnitř porovná SHA-256 obsahu a řekne nám, jestli se
            # opravdu něco změnilo. Tohle správně zachytí i případ, kdy se
            # soubor na stejné cestě smazal a znovu vytvořil s jiným obsahem -
            # dřívější verze to sledováním jen podle cesty tiše přeskakovala.
            for f in found:
                email_id, fp, was_changed = _process_file(conn, f, enable_abuseipdb=args.abuseipdb, enable_virustotal=args.virustotal,
                                         enable_whois=args.whois, enable_dns=args.dns)
                if was_changed:
                    changed_files.append(f)
                    print(f"\n[+] Nový/změněný soubor: [{email_id}] {f}")
                    _print_threat(fp, indent="      ")

            if changed_files:
                all_emails = database.get_all_emails(conn)
                by_path = {e['filepath']: e for e in all_emails}
                new_records = [by_path[f] for f in changed_files]

                for new_email in new_records:
                    for other in all_emails:
                        if other['id'] == new_email['id']:
                            continue
                        result = similarity.compare(new_email['fingerprint'], other['fingerprint'])
                        database.store_comparison(conn, new_email['id'], other['id'], result)
                        noteworthy = (result['score_pct'] >= args.threshold
                                      or 'SILNÝ JEDNOTLIVÝ NÁLEZ' in result['verdict'])
                        if noteworthy:
                            print(f"    ⚠ {os.path.basename(new_email['filepath'])} vs "
                                  f"{os.path.basename(other['filepath'])}: "
                                  f"{result['score_pct']}% - {result['verdict']}")
                            os.makedirs(REPORTS_DIR, exist_ok=True)
                            out_name = (f"report_{os.path.basename(new_email['filepath'])}"
                                        f"_vs_{os.path.basename(other['filepath'])}")
                            report.generate_html(
                                new_email, other, result, os.path.join(REPORTS_DIR, out_name + '.html')
                            )
                            exporter.write_json(
                                exporter.comparison_export(new_email, other, result),
                                os.path.join(REPORTS_DIR, out_name + '.json')
                            )
            elif not args.interval:
                print("[*] Žádné nové soubory.")

            if not args.interval:
                break
            time.sleep(args.interval)
    except KeyboardInterrupt:
        print("\n[*] Ukončeno.")


def cmd_ioc(args):
    conn = database.connect(DB_PATH)
    email_id, fp, _ = _process_file(conn, args.file)
    iocs = ioc_module.extract_iocs(fp)

    print(f"=== IOC: {args.file} ===")
    for category, values in iocs.items():
        print(f"\n{category} ({len(values)}):")
        for v in values:
            print(f"  {v}")

    if args.out:
        exporter.write_json(iocs, args.out)
        print(f"\nUloženo do: {args.out}")


def cmd_bundle(args):
    conn = database.connect(DB_PATH)
    audit_a, audit_b = AuditLog(), AuditLog()

    id_a, fp_a, _ = _process_file(conn, args.file_a, audit=audit_a, enable_abuseipdb=args.abuseipdb, enable_virustotal=args.virustotal,
                                         enable_whois=args.whois, enable_dns=args.dns)
    id_b, fp_b, _ = _process_file(conn, args.file_b, audit=audit_b, enable_abuseipdb=args.abuseipdb, enable_virustotal=args.virustotal,
                                         enable_whois=args.whois, enable_dns=args.dns)
    all_emails = {e['id']: e for e in database.get_all_emails(conn)}
    email_a, email_b = all_emails[id_a], all_emails[id_b]

    result = similarity.compare(email_a['fingerprint'], email_b['fingerprint'])
    database.store_comparison(conn, id_a, id_b, result)
    audit_a.log("Spočítána Identity Similarity vůči druhému e-mailu")
    audit_b.log("Spočítána Identity Similarity vůči druhému e-mailu")

    combined_iocs = {}
    for category in ('ips', 'domains', 'urls', 'emails', 'attachment_sha256'):
        vals = set(ioc_module.extract_iocs(fp_a).get(category, []))
        vals |= set(ioc_module.extract_iocs(fp_b).get(category, []))
        combined_iocs[category] = sorted(vals)

    with tempfile.TemporaryDirectory() as tmp:
        orig_a = os.path.join(tmp, f"original_a_{os.path.basename(args.file_a)}")
        orig_b = os.path.join(tmp, f"original_b_{os.path.basename(args.file_b)}")
        shutil.copy2(args.file_a, orig_a)
        shutil.copy2(args.file_b, orig_b)

        html_path = os.path.join(tmp, 'report.html')
        json_path = os.path.join(tmp, 'report.json')
        iocs_path = os.path.join(tmp, 'iocs.json')
        audit_a_path = os.path.join(tmp, 'audit_a.log')
        audit_b_path = os.path.join(tmp, 'audit_b.log')
        manifest_path = os.path.join(tmp, 'manifest.json')

        report.generate_html(email_a, email_b, result, html_path)
        exporter.write_json(exporter.comparison_export(email_a, email_b, result), json_path)
        evidence.write_canonical_json(combined_iocs, iocs_path)
        audit_a.log("Vygenerován HTML+JSON report a IOC export")
        audit_b.log("Vygenerován HTML+JSON report a IOC export")
        audit_a.write(audit_a_path)
        audit_b.write(audit_b_path)

        manifest = evidence.build_manifest({
            'original_a': orig_a, 'original_b': orig_b,
            'report_html': html_path, 'report_json': json_path, 'iocs': iocs_path,
        })
        evidence.write_canonical_json(manifest, manifest_path)

        out_path = args.out or f"Case_{time.strftime('%Y-%m-%d_%H%M%S')}.zip"
        with zipfile.ZipFile(out_path, 'w', zipfile.ZIP_DEFLATED) as zf:
            for path in (orig_a, orig_b, html_path, json_path, iocs_path,
                         audit_a_path, audit_b_path, manifest_path):
                zf.write(path, arcname=os.path.basename(path))

    print(f"Evidence Bundle vytvořen: {out_path}")
    print(f"  Nástroj: {evidence.TOOL_NAME} v{evidence.TOOL_VERSION} "
          f"(fingerprint v{evidence.FINGERPRINT_VERSION}, scoring v{evidence.SCORING_VERSION})")
    print(f"  Identity Similarity: {result['score_pct']}% - {result['verdict']}")


def cmd_case_create(args):
    if case_module.case_exists(args.name):
        print(f"[!] Case '{args.name}' už existuje: {case_module.case_dir(args.name)}")
        return
    d = case_module.create_case(args.name)
    print(f"[+] Case vytvořen: {d}")


def cmd_case_add(args):
    if not case_module.case_exists(args.name):
        case_module.create_case(args.name)
        print(f"[+] Case '{args.name}' neexistoval, vytvořen automaticky.")

    conn = database.connect(case_module.case_db_path(args.name))
    originals_dir = case_module.case_originals_dir(args.name)

    for src_path in args.files:
        if not os.path.exists(src_path):
            print(f"[!] Soubor nenalezen: {src_path}")
            continue
        dest_path = os.path.join(originals_dir, os.path.basename(src_path))
        shutil.copy2(src_path, dest_path)
        email_id, fp, was_changed = _process_file(
            conn, dest_path, enable_abuseipdb=args.abuseipdb, enable_virustotal=args.virustotal,
                                         enable_whois=args.whois, enable_dns=args.dns
        )
        print(f"[+] Case '{args.name}': {os.path.basename(src_path)} (id={email_id})")
        _print_threat(fp)


def cmd_case_compare(args):
    if not case_module.case_exists(args.name):
        print(f"[!] Case '{args.name}' neexistuje. Nejdřív 'case add {args.name} <soubory>'.")
        return

    conn = database.connect(case_module.case_db_path(args.name))
    emails = database.get_all_emails(conn)
    if len(emails) < 2:
        print(f"[!] Case '{args.name}' má míň než 2 e-maily, není co porovnávat.")
        return

    reports_dir = case_module.case_reports_dir(args.name)
    print(f"\n=== MATICE SHODY - case '{args.name}' ({len(emails)} e-mailů) ===\n")
    for i in range(len(emails)):
        for j in range(i + 1, len(emails)):
            a, b = emails[i], emails[j]
            result = similarity.compare(a['fingerprint'], b['fingerprint'])
            database.store_comparison(conn, a['id'], b['id'], result)
            noteworthy = result['score_pct'] >= args.threshold or 'SILNÝ JEDNOTLIVÝ NÁLEZ' in result['verdict']
            flag = " <-- " + result['verdict'] if noteworthy else ""
            print(f"{os.path.basename(a['filepath'])} vs {os.path.basename(b['filepath'])}: "
                  f"{result['score_pct']}%{flag}")
            if noteworthy:
                os.makedirs(reports_dir, exist_ok=True)
                out_name = f"report_{os.path.basename(a['filepath'])}_vs_{os.path.basename(b['filepath'])}"
                report.generate_html(a, b, result, os.path.join(reports_dir, out_name + '.html'))
                exporter.write_json(exporter.comparison_export(a, b, result),
                                     os.path.join(reports_dir, out_name + '.json'))


def cmd_case_report(args):
    if not case_module.case_exists(args.name):
        print(f"[!] Case '{args.name}' neexistuje.")
        return

    conn = database.connect(case_module.case_db_path(args.name))
    emails = database.get_all_emails(conn)
    if not emails:
        print(f"[!] Case '{args.name}' je prázdný.")
        return

    cdir = case_module.case_dir(args.name)

    combined_iocs = {}
    for category in ('ips', 'domains', 'urls', 'emails', 'attachment_sha256'):
        vals = set()
        for e in emails:
            vals |= set(ioc_module.extract_iocs(e['fingerprint']).get(category, []))
        combined_iocs[category] = sorted(vals)
    iocs_path = os.path.join(cdir, 'iocs.json')
    evidence.write_canonical_json(combined_iocs, iocs_path)

    timeline = case_module.build_timeline(emails)
    timeline_path = os.path.join(cdir, 'timeline.json')
    evidence.write_canonical_json({'timeline': timeline}, timeline_path)

    file_hashes = {'iocs': iocs_path, 'timeline': timeline_path, 'case_db': case_module.case_db_path(args.name)}
    for e in emails:
        label = f"original_{os.path.basename(e['filepath'])}"
        file_hashes[label] = e['filepath']
    manifest = evidence.build_manifest(file_hashes)
    manifest['case_name'] = args.name
    manifest['email_count'] = len(emails)
    manifest_path = os.path.join(cdir, 'manifest.json')
    evidence.write_canonical_json(manifest, manifest_path)

    threats = sorted(
        ((e['fingerprint'].get('threat') or {}).get('score_pct', 0), e['filepath']) for e in emails
    )
    print(f"\n=== REPORT - case '{args.name}' ===")
    print(f"E-mailů: {len(emails)}")
    print(f"IOC: {sum(len(v) for v in combined_iocs.values())} celkem "
          f"({len(combined_iocs['ips'])} IP, {len(combined_iocs['domains'])} domén, "
          f"{len(combined_iocs['urls'])} URL, {len(combined_iocs['attachment_sha256'])} hashů příloh)")
    if threats:
        print(f"Nejrizikovější: {threats[-1][1]} ({threats[-1][0]}%)")
    print("\nVygenerováno:")
    print(f"  {iocs_path}")
    print(f"  {timeline_path}")
    print(f"  {manifest_path}")


def cmd_case_list(args):
    cases = case_module.list_cases()
    if not cases:
        print("Žádné case složky. Vytvoř první: python3 main.py case create <jméno>")
        return
    for name in cases:
        try:
            conn = database.connect(case_module.case_db_path(name))
            count = len(database.get_all_emails(conn))
        except Exception:
            count = '?'
        print(f"  {name}  ({count} e-mailů)")


def cmd_case_suggest(args):
    """Dry-run - jen ukáže, do kterého case by e-mail sedl, nic nemění."""
    if not os.path.exists(args.file):
        print(f"[!] Soubor nenalezen: {args.file}")
        sys.exit(1)
    parsed = eml_parser.parse_eml(args.file)
    fp = fp_module.build_fingerprint(parsed, enable_geoip=False)
    candidates = case_module.suggest_cases_for_fingerprint(fp, suggest_threshold=args.threshold)

    if not candidates:
        auto_name = case_module.generate_auto_case_name(parsed.get('date'), parsed.get('file_sha256'))
        print(f"[i] Žádný existující case nesedí (práh {args.threshold}%).")
        print(f"    Automaticky založený case by se jmenoval: {auto_name}")
        return

    print(f"=== Kandidáti pro {args.file} ===")
    for c in candidates:
        signals = ', '.join(f"{k} (+{v})" for k, v in c['top_signals'])
        auto_tag = " [dost jisté pro --auto-case bez potvrzení]" if case_module.should_auto_assign(c) else ""
        print(f"  {c['case_name']}: {c['best_score']}% - {c['verdict']}{auto_tag}")
        print(f"      nejblíž: {os.path.basename(c['best_match_file'])} ({c['email_count']} e-mailů v case) "
              f"| signály: {signals}")
        if c['shared_ips']:
            print(f"      sdílené IP: {', '.join(c['shared_ips'])}")
        if c['shared_domains']:
            print(f"      sdílené domény: {', '.join(c['shared_domains'])}")
        if c['shared_attachment_sha256']:
            print(f"      sdílené hashe příloh: {', '.join(h[:16] + '…' for h in c['shared_attachment_sha256'])}")

    if len(candidates) > 1:
        print("\n[!] Víc než jeden case sedí nad prahem - vyber ručně:")
        print(f"    python3 main.py case add <jméno> {args.file}")


def _auto_assign_to_case(filepath: str, date_header: str, fp: dict, threshold: float = None,
                          enable_abuseipdb: bool = False, enable_virustotal: bool = False):
    """Sdílená logika pro --auto-case flag na 'add'/'sync' (stejná logika
    jako GUI - viz app.py) - najde nejlepší case a podle dvouúrovňového
    prahu rozhodne:
      - 0 kandidátů -> založí nový case
      - 1 kandidát A je dost jistý (should_auto_assign) -> přiřadí tam
      - 1 kandidát, ale NENÍ dost jistý -> jen ukáže, nerozhodne sám
      - 2+ kandidátů -> jen ukáže žebříček, nerozhodne sám
    Práh pro "ukázat" (DEFAULT_SUGGEST_THRESHOLD, 30 %) je nižší než
    práh pro "tiše přiřadit bez potvrzení" (AUTO_ASSIGN_CONFIRM_THRESHOLD,
    60 %, nebo silný jednotlivý nález) - u forenzního nástroje je lepší
    nízkojistotnou shodu jen ukázat, ne ji potichu zapsat jako fakt."""
    if threshold is None:
        threshold = case_module.DEFAULT_SUGGEST_THRESHOLD
    candidates = case_module.suggest_cases_for_fingerprint(fp, suggest_threshold=threshold)

    if len(candidates) == 0:
        target_case = case_module.generate_auto_case_name(date_header, fp.get('file_sha256'))
        print(f"    → Žádná shoda, zakládám nový case: '{target_case}'")
    elif len(candidates) == 1 and case_module.should_auto_assign(candidates[0]):
        target_case = candidates[0]['case_name']
        print(f"    → Case shoda: '{target_case}' ({candidates[0]['best_score']}%)")
    elif len(candidates) == 1:
        c = candidates[0]
        print(f"    → Možná shoda s '{c['case_name']}' ({c['best_score']}%), ale pod prahem pro "
              f"automatické přiřazení bez potvrzení - zkontroluj ručně:")
        print(f"        python3 main.py case add {c['case_name']} {filepath}")
        return
    else:
        print(f"    → Sedí do {len(candidates)} case složek najednou, nerozhoduji sám:")
        for c in candidates:
            print(f"        {c['case_name']}: {c['best_score']}%")
        print(f"      Přiřaď ručně: python3 main.py case add <jméno> {filepath}")
        return

    case_module.create_case(target_case)
    conn = database.connect(case_module.case_db_path(target_case))
    dest = os.path.join(case_module.case_originals_dir(target_case), os.path.basename(filepath))
    shutil.copy2(filepath, dest)
    _process_file(conn, dest, enable_abuseipdb=enable_abuseipdb, enable_virustotal=enable_virustotal)
    print(f"    → Přidáno do case '{target_case}'")


def cmd_case_graph(args):
    if not case_module.case_exists(args.name):
        print(f"[!] Case '{args.name}' neexistuje.")
        return

    conn = database.connect(case_module.case_db_path(args.name))
    emails = database.get_all_emails(conn)
    comparisons = database.get_all_comparisons(conn)
    if len(emails) < 2:
        print(f"[!] Case '{args.name}' má míň než 2 e-maily, graf nemá smysl.")
        return

    summary = case_module.graph_summary(emails, comparisons, threshold=args.threshold)
    print(f"\n=== GRAF VZTAHŮ - case '{args.name}' ===")
    print(f"E-mailů: {summary['node_count']}, hran nad prahem {args.threshold}%: {summary['edge_count']}")
    print(f"Shluků: {summary['cluster_count']} (největší: {summary['largest_cluster_size']} e-mailů)")
    for i, cluster in enumerate(summary['clusters'], 1):
        names = ', '.join(os.path.basename(f) for f in cluster)
        print(f"  Shluk {i} ({len(cluster)}): {names}")

    dot = case_module.build_relationship_graph(emails, comparisons, threshold=args.threshold)
    out_path = os.path.join(case_module.case_dir(args.name), 'graph.dot')
    with open(out_path, 'w', encoding='utf-8') as f:
        f.write(dot)
    print(f"\nDOT graf uložen: {out_path}")
    print(f"Vykreslit: dot -Tpng {out_path} -o graph.png  (potřebuje nainstalovaný Graphviz)")
    print("nebo vlož obsah na https://dreampuf.github.io/GraphvizOnline/")


def cmd_case(args):
    dispatch = {
        'create': cmd_case_create,
        'add': cmd_case_add,
        'compare': cmd_case_compare,
        'report': cmd_case_report,
        'list': cmd_case_list,
        'graph': cmd_case_graph,
        'suggest': cmd_case_suggest,
    }
    try:
        dispatch[args.case_command](args)
    except case_module.InvalidCaseName as e:
        print(f"[!] {e}")
        sys.exit(1)


def cmd_gmail_auth(args):
    cfg = _gmail_config()
    client_id = args.client_id or cfg['client_id']
    client_secret = args.client_secret or cfg['client_secret']
    if not client_id or not client_secret:
        print("[!] Chybí client_id/client_secret. Zadej je přes --client-id/--client-secret,")
        print("    nebo je nastav v config.ini:")
        print("    [gmail]")
        print("    client_id = ...")
        print("    client_secret = ...")
        print("    (získáš je v Google Cloud Console - OAuth client typu 'Desktop app')")
        sys.exit(1)
    try:
        gmail_connector.run_oauth_flow(client_id, client_secret)
        print(f"[+] Autorizace úspěšná, token uložen: {gmail_connector.TOKEN_PATH}")
    except (TimeoutError, PermissionError) as e:
        print(f"[!] Autorizace selhala: {e}")
        sys.exit(1)


def cmd_gmail_sync(args):
    cfg = _gmail_config()
    client_id = cfg['client_id']
    client_secret = cfg['client_secret']
    if not client_id or not client_secret:
        print("[!] Chybí client_id/client_secret v config.ini [gmail] sekci.")
        sys.exit(1)

    query = args.query or cfg['default_query']
    max_results = args.max if args.max is not None else cfg['default_max']

    try:
        downloaded = gmail_connector.sync_gmail_emails(
            database.connect(DB_PATH), client_id, client_secret, query, max_results,
            cfg['max_allowed'], GMAIL_EMAILS_DIR,
        )
    except FileNotFoundError as e:
        print(f"[!] {e}")
        sys.exit(1)
    except ValueError as e:
        print(f"[!] {e}")
        sys.exit(1)
    except PermissionError as e:
        print(f"[!] {e}")
        sys.exit(1)

    print(f"[+] Staženo {len(downloaded)} nových zpráv z Gmailu (dotaz: '{query}')")
    if not downloaded:
        return

    conn = database.connect(DB_PATH)
    for filepath in downloaded:
        email_id, fp, _ = _process_file(conn, filepath, enable_abuseipdb=args.abuseipdb,
                                         enable_virustotal=args.virustotal)
        print(f"    [{email_id}] {os.path.basename(filepath)}")
        _print_threat(fp)
        if getattr(args, 'auto_case', False):
            stored = database.get_email(conn, email_id)
            _auto_assign_to_case(filepath, stored['date_header'], fp, enable_abuseipdb=args.abuseipdb,
                                  enable_virustotal=args.virustotal)


def main():
    parser = argparse.ArgumentParser(description="MailGuardian OSINT - lokální porovnávač e-mailů")
    sub = parser.add_subparsers(dest='command', required=True)

    p_add = sub.add_parser('add', help='Přidat .eml soubory do databáze')
    p_add.add_argument('files', nargs='+')
    p_add.add_argument('--abuseipdb', action='store_true',
                        help='Dotázat se na reputaci primární IP přes AbuseIPDB (vyžaduje API klíč, síťové volání)')
    p_add.add_argument('--virustotal', action='store_true',
                          help='Dotázat se na reputaci primární IP přes VirusTotal (vyžaduje API klíč, síťové volání)')
    p_add.add_argument('--whois', action='store_true',
                          help='Dotázat se na WHOIS domény odesílatele (stáří, registrar, nameservery) - síťové volání, žádný API klíč')
    p_add.add_argument('--dns', action='store_true',
                          help='Dotázat se na DNS domény odesílatele (A/MX/TXT/NS) - síťové volání, žádný API klíč')
    p_add.add_argument('--auto-case', action='store_true', dest='auto_case',
                        help='Po přidání zkusit e-mail automaticky přiřadit do existujícího/nového case '
                             '(viz "python3 main.py case suggest" pro dry-run bez side-effectů)')
    p_add.set_defaults(func=cmd_add)

    p_cmp = sub.add_parser('compare', help='Porovnat dva konkrétní .eml soubory')
    p_cmp.add_argument('file_a')
    p_cmp.add_argument('file_b')
    p_cmp.add_argument('--abuseipdb', action='store_true',
                        help='Dotázat se na reputaci primární IP přes AbuseIPDB')
    p_cmp.add_argument('--virustotal', action='store_true',
                          help='Dotázat se na reputaci primární IP přes VirusTotal')
    p_cmp.add_argument('--whois', action='store_true',
                          help='Dotázat se na reputaci primární IP přes WHOIS (stáří domény, registrar, nameservery)')
    p_cmp.add_argument('--dns', action='store_true',
                          help='Dotázat se na reputaci primární IP přes DNS (A/MX/TXT/NS pro doménu odesílatele)')
    p_cmp.set_defaults(func=cmd_compare)

    p_all = sub.add_parser('compare-all', help='Porovnat všechny e-maily v databázi navzájem')
    p_all.set_defaults(func=cmd_compare_all)

    p_list = sub.add_parser('list', help='Vypsat uložené e-maily')
    p_list.set_defaults(func=cmd_list)

    p_watch = sub.add_parser('watch', help='Sledovat složku a automaticky zpracovat nové .eml soubory')
    p_watch.add_argument('--folder', default='emails', help='Složka ke sledování (výchozí: emails)')
    p_watch.add_argument('--interval', type=int, default=None,
                          help='Interval v sekundách pro opakované sledování (bez zadání = jednorázový běh)')
    p_watch.add_argument('--threshold', type=float, default=30.0,
                          help='Minimální skóre pro upozornění a HTML report (výchozí: 30)')
    p_watch.add_argument('--abuseipdb', action='store_true',
                          help='Dotázat se na reputaci primární IP přes AbuseIPDB pro nové soubory')
    p_watch.add_argument('--virustotal', action='store_true',
                          help='Dotázat se na reputaci primární IP přes VirusTotal pro nové soubory')
    p_watch.add_argument('--whois', action='store_true',
                          help='Dotázat se na reputaci primární IP přes WHOIS (stáří domény, registrar, nameservery) pro nové soubory')
    p_watch.add_argument('--dns', action='store_true',
                          help='Dotázat se na reputaci primární IP přes DNS (A/MX/TXT/NS pro doménu odesílatele) pro nové soubory')
    p_watch.set_defaults(func=cmd_watch)

    p_ioc = sub.add_parser('ioc', help='Vytáhnout IOC (IP/domény/URL/e-maily/hashe) z jednoho e-mailu')
    p_ioc.add_argument('file')
    p_ioc.add_argument('--out', default=None, help='Cesta pro uložení jako JSON (nepovinné)')
    p_ioc.set_defaults(func=cmd_ioc)

    p_bundle = sub.add_parser('bundle', help='Vytvořit Evidence Bundle (zip s manifestem, audit logem, IOC)')
    p_bundle.add_argument('file_a')
    p_bundle.add_argument('file_b')
    p_bundle.add_argument('--out', default=None, help='Cesta k výslednému .zip (výchozí: Case_<datum>.zip)')
    p_bundle.add_argument('--abuseipdb', action='store_true',
                           help='Dotázat se na reputaci primární IP přes AbuseIPDB pro oba e-maily')
    p_bundle.add_argument('--virustotal', action='store_true',
                          help='Dotázat se na reputaci primární IP přes VirusTotal pro oba e-maily')
    p_bundle.add_argument('--whois', action='store_true',
                          help='Dotázat se na reputaci primární IP přes WHOIS (stáří domény, registrar, nameservery) pro oba e-maily')
    p_bundle.add_argument('--dns', action='store_true',
                          help='Dotázat se na reputaci primární IP přes DNS (A/MX/TXT/NS pro doménu odesílatele) pro oba e-maily')
    p_bundle.set_defaults(func=cmd_bundle)

    p_case = sub.add_parser('case', help='Case mode - skupina souvisejících e-mailů (kampaň/incident)')
    case_sub = p_case.add_subparsers(dest='case_command', required=True)

    p_case_create = case_sub.add_parser('create', help='Vytvořit nový case')
    p_case_create.add_argument('name')

    p_case_add = case_sub.add_parser('add', help='Přidat .eml soubory do case (vytvoří case, pokud neexistuje)')
    p_case_add.add_argument('name')
    p_case_add.add_argument('files', nargs='+')
    p_case_add.add_argument('--abuseipdb', action='store_true', help='Dotázat se na reputaci přes AbuseIPDB')
    p_case_add.add_argument('--virustotal', action='store_true', help='Dotázat se na reputaci přes VirusTotal')
    p_case_add.add_argument('--whois', action='store_true', help='Dotázat se na WHOIS (stáří domény, registrar)')
    p_case_add.add_argument('--dns', action='store_true', help='Dotázat se na DNS (A/MX/TXT/NS)')

    p_case_compare = case_sub.add_parser('compare', help='Porovnat všechny e-maily v case navzájem')
    p_case_compare.add_argument('name')
    p_case_compare.add_argument('--threshold', type=float, default=30.0,
                                 help='Minimální skóre pro report (výchozí: 30)')

    p_case_report = case_sub.add_parser('report', help='Vygenerovat IOC, timeline a manifest pro case')
    p_case_report.add_argument('name')

    case_sub.add_parser('list', help='Vypsat existující case složky')

    p_case_graph = case_sub.add_parser('graph', help='Vygenerovat graf vztahů mezi e-maily v case (Graphviz DOT)')
    p_case_graph.add_argument('name')
    p_case_graph.add_argument('--threshold', type=float, default=30.0,
                               help='Minimální skóre pro hranu v grafu (výchozí: 30)')

    p_case_suggest = case_sub.add_parser('suggest',
                                          help='Ukázat, do kterého case by e-mail sedl (dry-run, nic nemění)')
    p_case_suggest.add_argument('file')
    p_case_suggest.add_argument('--threshold', type=float, default=30.0,
                                 help='Minimální skóre pro navržení shody (výchozí: 30)')

    p_case.set_defaults(func=cmd_case)

    p_gmail_auth = sub.add_parser('gmail-auth', help='Prvotní OAuth2 autorizace Gmail přístupu (jen čtení)')
    p_gmail_auth.add_argument('--client-id', default=None, help='OAuth client ID (nebo v config.ini)')
    p_gmail_auth.add_argument('--client-secret', default=None, help='OAuth client secret (nebo v config.ini)')
    p_gmail_auth.set_defaults(func=cmd_gmail_auth)

    p_sync = sub.add_parser('sync', help='Synchronizovat nové e-maily z Gmailu (gmail.readonly, jen čtení)')
    p_sync.add_argument('--query', default=None,
                         help='Gmail vyhledávací dotaz (výchozí z config.ini nebo "label:INBOX newer_than:30d")')
    p_sync.add_argument('--max', type=int, default=None,
                         help='Maximální počet zpráv ke kontrole (výchozí z config.ini nebo 50)')
    p_sync.add_argument('--abuseipdb', action='store_true', help='Dotázat se na reputaci přes AbuseIPDB pro nové zprávy')
    p_sync.add_argument('--virustotal', action='store_true', help='Dotázat se na reputaci přes VirusTotal pro nové zprávy')
    p_sync.add_argument('--auto-case', action='store_true', dest='auto_case',
                         help='Nově stažené zprávy automaticky přiřadit do existujícího/nového case')
    p_sync.set_defaults(func=cmd_gmail_sync)

    args = parser.parse_args()
    try:
        args.func(args)
    except eml_parser.UnparseableEmailError as e:
        # Centralizované ošetření - _process_file() sám o sobě sys.exit()
        # nevolá (viz v0.21 oprava: GUI import main.py přímo volá
        # _process_file() bez args.func()/main() obalu, a sys.exit() uvnitř
        # by v Streamlitu způsobil zaseknutí skriptu na timeout, ne hezkou
        # chybu - ověřeno reálně přes AppTest). CLI cestu (spuštěnou přes
        # main()) tady zachytáváme centrálně na jednom místě.
        print(f"[!] {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
