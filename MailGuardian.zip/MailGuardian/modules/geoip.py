"""
geoip.py
Volitelný modul pro GeoIP + ASN lookup pomocí MaxMind GeoLite2 databází.

Databáze se NEstahují automaticky (maxmind.com vyžaduje registraci a není
v seznamu povolených domén pro automatizované stahování) - je potřeba je
stáhnout ručně, viz README.md.

Pokud knihovna `geoip2` není nainstalovaná nebo databáze chybí, modul
vrací prázdný výsledek a zbytek nástroje funguje dál beze změny -
GeoIP je čistě doplňkový signál, nikdy není vyžadován.
"""

import os

try:
    import geoip2.database
    GEOIP_LIB_AVAILABLE = True
except ImportError:
    GEOIP_LIB_AVAILABLE = False

# Výchozí umístění databází - kořen projektu
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_CITY_DB = os.path.join(_PROJECT_ROOT, 'GeoLite2-City.mmdb')
DEFAULT_ASN_DB = os.path.join(_PROJECT_ROOT, 'GeoLite2-ASN.mmdb')

_EMPTY = {'country': None, 'city': None, 'asn': None, 'org': None, 'available': False}


def is_available(city_db: str = DEFAULT_CITY_DB, asn_db: str = DEFAULT_ASN_DB) -> bool:
    """True pokud je knihovna nainstalovaná a aspoň jedna databáze existuje."""
    return GEOIP_LIB_AVAILABLE and (os.path.exists(city_db) or os.path.exists(asn_db))


def lookup(ip: str, city_db: str = DEFAULT_CITY_DB, asn_db: str = DEFAULT_ASN_DB) -> dict:
    """Vrátí {'country', 'city', 'asn', 'org', 'available'} pro danou IP.
    Nikdy nevyhazuje výjimku - při jakémkoliv problému vrací prázdný výsledek."""
    if not ip or not GEOIP_LIB_AVAILABLE:
        return dict(_EMPTY)

    result = dict(_EMPTY)

    if os.path.exists(city_db):
        try:
            with geoip2.database.Reader(city_db) as reader:
                response = reader.city(ip)
                result['country'] = response.country.name or response.country.iso_code
                result['city'] = response.city.name
                result['available'] = True
        except Exception:
            pass

    if os.path.exists(asn_db):
        try:
            with geoip2.database.Reader(asn_db) as reader:
                response = reader.asn(ip)
                result['asn'] = f"AS{response.autonomous_system_number}"
                result['org'] = response.autonomous_system_organization
                result['available'] = True
        except Exception:
            pass

    return result
