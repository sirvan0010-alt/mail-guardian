"""
evidence.py
Integrity manifest pro forenzní použití - umožňuje zpětně ověřit, že
analyzovaný .eml ani vygenerované reporty nebyly od analýzy změněny.

Verze fingerprintu/scoringu se zvyšují ručně při jakékoliv změně, která by
mohla změnit výsledek stejného vstupu (nová váha signálu, změna prahu
verdiktu...) - manifest s starou verzí je varování, že reprodukce
výsledku vyžaduje starou verzi nástroje, ne aktuální.
"""

import hashlib
import json
from datetime import datetime, timezone

TOOL_NAME = "MailGuardian OSINT"
TOOL_VERSION = "0.24"
FINGERPRINT_VERSION = 1
SCORING_VERSION = 1


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(65536), b''):
            h.update(chunk)
    return h.hexdigest()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def build_manifest(file_hashes: dict) -> dict:
    """file_hashes: dict {label: filepath} pro soubory, které mají být
    zahrnuty do manifestu (originální .eml, HTML report, JSON export...).
    Vrátí manifest se SHA-256 každého souboru + metadata nástroje."""
    hashes = {}
    for label, path in file_hashes.items():
        if path:
            try:
                hashes[f'{label}_sha256'] = sha256_file(path)
            except (FileNotFoundError, IsADirectoryError):
                hashes[f'{label}_sha256'] = None

    return {
        'tool': TOOL_NAME,
        'tool_version': TOOL_VERSION,
        'fingerprint_version': FINGERPRINT_VERSION,
        'scoring_version': SCORING_VERSION,
        'analysis_time_utc': datetime.now(timezone.utc).isoformat(),
        **hashes,
    }


def write_canonical_json(data: dict, path: str):
    """Zapíše JSON deterministicky (seřazené klíče, pevná separace) -
    stejná data vždy vyprodukují bitově stejný soubor, takže jde hashovat
    a použít jako důkaz integrity."""
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2, sort_keys=True, default=str)
