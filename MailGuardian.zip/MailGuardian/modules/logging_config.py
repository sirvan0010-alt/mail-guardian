"""
logging_config.py
Standardní debug logging (INFO/WARNING/ERROR/DEBUG) pro ladění -
oddělené od audit.py, který je forenzní záznam kroků analýzy (co se
stalo s KONKRÉTNÍM e-mailem), zatímco tohle je běžný vývojářský log
(co dělá NÁSTROJ samotný, chyby, výkon...).

Výchozí úroveň WARNING (tichý běžný provoz). Zapnout podrobnější výstup:
    MAILGUARDIAN_LOG_LEVEL=DEBUG python3 main.py add mail.eml

Log jde na stderr, ne stdout - ať se nemíchá s běžným výstupem nástroje
(ten je na stdout a je určený pro čtení/parsování uživatelem).
"""

import logging
import os
import sys

_configured = False


def get_logger(name: str = 'mailguardian') -> logging.Logger:
    """Vrátí nakonfigurovaný logger. Bezpečné volat opakovaně - konfiguruje
    handlery jen jednou (jinak by se log řádky duplikovaly)."""
    global _configured
    logger = logging.getLogger(name)

    if not _configured:
        level_name = os.environ.get('MAILGUARDIAN_LOG_LEVEL', 'WARNING').upper()
        level = getattr(logging, level_name, logging.WARNING)

        handler = logging.StreamHandler(sys.stderr)
        handler.setFormatter(logging.Formatter(
            '%(asctime)s %(levelname)-8s %(name)s: %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        ))
        root = logging.getLogger('mailguardian')
        root.addHandler(handler)
        root.setLevel(level)
        root.propagate = False
        _configured = True

    return logger
