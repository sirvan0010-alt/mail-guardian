"""
homoglyph.py
Detekce IDN homograph útoků (smíchané skripty ve stejné doméně, např.
"micrоsoft.com" s cyrilickým "о") a typosquattingu (edit distance vůči
známým doménám, např. "paypaI.com" s velkým "I" místo "l").

Důležité: čistě NEúmyslné je mít doménu celou v jiném skriptu (existují
legitimní cyrilické/řecké/arabské domény) - podezřelé je až SMÍCHÁNÍ
skriptů v jednom labelu, protože Latinka+Cyrilice v jednom slově nemá
žádný legitimní důvod (žádný jazyk to takhle nepíše).
"""

import unicodedata

# Domény, vůči kterým kontrolujeme typosquatting - rozšiř podle potřeby
WELL_KNOWN_DOMAINS = [
    'google.com', 'microsoft.com', 'paypal.com', 'apple.com', 'amazon.com',
    'facebook.com', 'gmail.com', 'outlook.com', 'seznam.cz', 'csob.cz',
    'kb.cz', 'airbank.cz', 'ceskasporitelna.cz', 'moneta.cz',
    'raiffeisenbank.cz', 'o2.cz', 'vodafone.cz', 'dhl.com', 'fedex.com',
    'netflix.com', 'instagram.com', 'linkedin.com', 'dropbox.com',
]

_SCRIPT_PREFIXES = ('LATIN', 'CYRILLIC', 'GREEK', 'ARMENIAN', 'HEBREW', 'ARABIC')

# Běžně zneužívané vizuálně zaměnitelné znaky -> jejich latinský ekvivalent.
# Neúplný seznam (nejde vyjmenovat všechny Unicode confusables), ale pokrývá
# nejčastěji zneužívané znaky v reálných phishingových kampaních.
CONFUSABLES = {
    '\u0430': 'a', '\u0435': 'e', '\u043e': 'o', '\u0440': 'p', '\u0441': 'c',
    '\u0443': 'y', '\u0445': 'x', '\u0455': 's', '\u0456': 'i', '\u0458': 'j',
    '\u04bb': 'h', '\u0501': 'd', '\u051b': 'q',
    '\u03bf': 'o', '\u03b1': 'a', '\u03c1': 'p', '\u03c5': 'y', '\u03b9': 'i',
}


def _confusable_normalize(s: str) -> str:
    return ''.join(CONFUSABLES.get(ch, ch) for ch in s)


def _try_decode_punycode(domain: str) -> str:
    """Pokud je doména (nebo její label) v punycode (xn--...), zkusí dekódovat
    na Unicode - ať homoglyph detekce funguje i na hlavičkách, kde e-mailový
    klient doménu nerozbalil sám. Při selhání vrátí původní vstup beze změny."""
    try:
        labels = []
        for label in domain.split('.'):
            if label.startswith('xn--'):
                labels.append(label.encode('ascii').decode('idna'))
            else:
                labels.append(label)
        return '.'.join(labels)
    except Exception:
        return domain


def _char_script(ch: str):
    """Odhadne unicode skript znaku z jeho oficiálního jména (hrubá heuristika,
    ale pro účely detekce míchání skriptů dostatečná)."""
    try:
        name = unicodedata.name(ch)
    except ValueError:
        return None
    for script in _SCRIPT_PREFIXES:
        if script in name:
            return script
    return None


def _detect_mixed_script(label: str) -> set:
    scripts = set()
    for ch in label:
        if ch.isalpha():
            s = _char_script(ch)
            if s:
                scripts.add(s)
    return scripts


def _levenshtein(a: str, b: str) -> int:
    if a == b:
        return 0
    if not a:
        return len(b)
    if not b:
        return len(a)
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        curr = [i] + [0] * len(b)
        for j, cb in enumerate(b, 1):
            cost = 0 if ca == cb else 1
            curr[j] = min(prev[j] + 1, curr[j - 1] + 1, prev[j - 1] + cost)
        prev = curr
    return prev[-1]


def analyze_domain(domain: str) -> list:
    """Vrátí seznam nálezů pro danou doménu (prázdný list = nic podezřelého)."""
    if not domain:
        return []
    domain = domain.lower().strip()
    domain = _try_decode_punycode(domain)
    findings = []

    for label in domain.split('.'):
        scripts = _detect_mixed_script(label)
        if len(scripts) > 1:
            findings.append({
                'type': 'mixed_script',
                'label': label,
                'scripts': sorted(scripts),
                'detail': f"Label '{label}' míchá skripty: {', '.join(sorted(scripts))}",
            })

    if domain in WELL_KNOWN_DOMAINS:
        return findings  # přesná shoda se známou doménou - nic dalšího neřešíme

    # Typosquat na syrové doméně (např. paypaI.com - jen záměna písmen ve stejném skriptu)
    for known in WELL_KNOWN_DOMAINS:
        if abs(len(domain) - len(known)) > 2:
            continue
        dist = _levenshtein(domain, known)
        if 0 < dist <= 2:
            findings.append({
                'type': 'typosquat_candidate',
                'similar_to': known,
                'distance': dist,
                'detail': f"Doména '{domain}' je na {dist} úprav od známé domény '{known}'",
            })

    # Typosquat po confusables normalizaci - odhalí i domény kompletně v jiném
    # skriptu (např. celé "paypal" napsané cyrilickými vizuálně shodnými znaky),
    # kde syrový Levenshtein výše nic nenajde, protože žádný znak se doslova neshoduje.
    normalized = _confusable_normalize(domain)
    if normalized != domain:
        for known in WELL_KNOWN_DOMAINS:
            if abs(len(normalized) - len(known)) > 2:
                continue
            dist = _levenshtein(normalized, known)
            if dist <= 2:
                findings.append({
                    'type': 'confusable_homoglyph',
                    'similar_to': known,
                    'distance': dist,
                    'detail': (f"Doména '{domain}' po přepisu vizuálně zaměnitelných znaků "
                               f"odpovídá '{normalized}' - na {dist} úprav od '{known}'"),
                })

    return findings
