"""
parser.py
Parsování .eml souborů - hlavičky, IP adresy, DKIM, SPF/DMARC.
Vlastní implementace nad standardní knihovnou `email` (žádné externí závislosti,
žádná GPL vazba na jiné projekty).
"""

import re
import hashlib
import ipaddress
from email import message_from_bytes, policy
from email.utils import parseaddr

from . import urls as urls_module
from . import attachments as attachments_module
from . import received_chain as received_chain_module
from . import mime_fp as mime_fp_module
from . import message_id_fp as message_id_fp_module
from . import html_fp as html_fp_module
from .logging_config import get_logger

_log = get_logger('mailguardian.parser')

IP_REGEX = r'\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\b'
# Permisivní regex pro kandidáty na IPv6 (přesná validace je pak na ipaddress.ip_address).
# Vyžaduje aspoň 2 dvojtečky, aby se nezachytávaly věci jako časy (12:34) nebo Message-ID.
IPV6_CANDIDATE_REGEX = r'\b([0-9a-fA-F]{0,4}(?::[0-9a-fA-F]{0,4}){2,7})\b'
AUTH_REGEX = r'\b(spf|dkim|dmarc)=(pass|fail|softfail|neutral|none|temperror|permerror)\b'

AUTH_EXPLANATIONS = {
    ('SPF', 'pass'): "Odesílající server je v seznamu povolených IP pro doménu odesílatele.",
    ('SPF', 'fail'): "Odesílající server NENÍ povolen pro tuto doménu - silný indikátor spoofingu.",
    ('SPF', 'softfail'): "Odesílající server pravděpodobně není povolen, ale doména to nevynucuje striktně.",
    ('SPF', 'neutral'): "Doména se k platnosti odesílatele nevyjadřuje.",
    ('SPF', 'none'): "Doména nemá nastavený SPF záznam vůbec.",
    ('SPF', 'temperror'): "Dočasná chyba při ověřování SPF (např. výpadek DNS).",
    ('SPF', 'permerror'): "Trvalá chyba v SPF záznamu domény (špatná syntaxe).",
    ('DKIM', 'pass'): "Digitální podpis e-mailu je platný - obsah nebyl cestou pozměněn.",
    ('DKIM', 'fail'): "Digitální podpis NENÍ platný - e-mail mohl být pozměněn, nebo je podpis podvržený.",
    ('DKIM', 'none'): "E-mail vůbec není DKIM podepsaný.",
    ('DMARC', 'pass'): "E-mail splňuje politiku domény pro SPF/DKIM - odesílatel je pravděpodobně legitimní.",
    ('DMARC', 'fail'): "E-mail NESPLŇUJE politiku domény - silný indikátor spoofingu nebo phishingu.",
    ('DMARC', 'none'): "Doména nemá nastavenou DMARC politiku.",
}


def explain_auth_results(auth_results: dict) -> dict:
    """Vrátí lidsky čitelné vysvětlení ke každému SPF/DKIM/DMARC verdiktu."""
    explained = {}
    for protocol, verdict in auth_results.items():
        key = (protocol, verdict)
        explained[protocol] = {
            'verdict': verdict,
            'explanation': AUTH_EXPLANATIONS.get(key, f"Neznámý/nerozpoznaný verdikt: {verdict}"),
            'suspicious': verdict in ('fail', 'softfail', 'permerror'),
        }
    return explained


def _is_public_ip(ip_str: str) -> bool:
    """True pokud je IP validní a globálně routovatelná (ne privátní/loopback/atd.)."""
    try:
        ip = ipaddress.ip_address(ip_str)
        return ip.is_global and not ip.is_multicast
    except ValueError:
        return False


class UnparseableEmailError(ValueError):
    """E-mail je natolik strukturálně rozbitý/zlomyslný (např. tisíce
    úrovní vnořeného multipart), že ho ani samotná stdlib knihovna
    `email` nedokáže naparsovat bez vyčerpání Python rekurzního limitu.
    Dědí z ValueError, ať se dá odchytit i obecněji, kde na typu
    nezáleží."""


# Nad tuhle velikost souboru zalogujeme WARNING (ne blokujeme - i obří
# příloha může být legitimní důkaz, který chce analytik prohlédnout).
# Důvod: Python stdlib `email.message_from_bytes()` pod `policy.default`
# spotřebuje cca 15x víc RAM, než je velikost souboru (změřeno - 20MB
# soubor -> ~300MB peak, ŽE UVNITŘ stdlib parseru, ne v našem kódu -
# vlastní strukturované parsování hlaviček/MIME nejde bez architektonické
# změny obejít). U nástroje, který analyzuje potenciálně zlomyslné
# e-maily, je tohle reálné DoS riziko proti stroji analytika - 500MB
# příloha by mohla spotřebovat >7GB RAM.
LARGE_FILE_WARNING_THRESHOLD_MB = 20


def load_eml(filepath: str):
    """Načte .eml soubor a vrátí (email.message.Message objekt, raw bytes).

    RecursionError zachyceno a přebaleno na UnparseableEmailError -
    nalezeno MIME fuzzingem (tests/test_parser_fuzz.py): extrémně hluboce
    vnořený multipart (~1000+ úrovní) vyčerpá Python rekurzní limit už
    UVNITŘ `message_from_bytes()` samotné, tedy dřív, než se vůbec
    dostaneme k jakémukoliv vlastnímu kódu - hloubkové limity v
    modules/mime_fp.py (viz MAX_MIME_DEPTH) tenhle pád nezachytí, protože
    ten kód se vůbec nespustí. Nejde to "opravit" v cpython stdlib, jen
    to zachytit a nenechat spadnout celý běh kvůli jednomu zlomyslnému
    souboru."""
    with open(filepath, 'rb') as f:
        raw = f.read()
    size_mb = len(raw) / 1024 / 1024
    if size_mb > LARGE_FILE_WARNING_THRESHOLD_MB:
        _log.warning(
            f"'{filepath}' je {size_mb:.1f}MB - parsování pravděpodobně "
            f"spotřebuje ~15x víc RAM (viz LARGE_FILE_WARNING_THRESHOLD_MB "
            f"komentář), tedy řádově {size_mb * 15 / 1024:.1f}GB. Normální "
            f"chování stdlib email parseru, ne bug v tomhle nástroji."
        )
    try:
        msg = message_from_bytes(raw, policy=policy.default)
    except RecursionError:
        raise UnparseableEmailError(
            f"'{filepath}' je strukturálně příliš komplexní na naparsování "
            f"(pravděpodobně extrémně hluboce vnořený MIME) - vynechávám."
        )
    return msg, raw


def _raw_header_values(msg, key: str) -> list:
    """Vrátí syrové (neparsované) hodnoty hlavičky přímo z interní
    reprezentace zprávy - obchází `email.policy.default`'s lazy
    strukturovaný parser adresových hlaviček (From/To/Cc/Reply-To/Bcc...),
    který na záludně sestavených/uťatých hlavičkách (např. `From: Jméno <`
    bez ukončujícího `>`) vyhazuje IndexError přímo z cpython stdlib kódu
    (email._header_value_parser.get_angle_addr, ověřeno na Python 3.12) -
    ne z našeho kódu, ale musíme to sami odchytit, protože to je fuzzing
    nálezem reprodukovatelný pád (viz tests/test_parser_fuzz.py)."""
    key_lower = key.lower()
    return [v for k, v in msg._headers if k.lower() == key_lower]


def extract_headers(msg) -> dict:
    """Vytáhne všechny hlavičky do dict (lowercase klíče)."""
    headers = {}
    for key in msg.keys():
        key_lower = key.lower()
        if key_lower in headers:
            continue  # už zpracováno (msg.keys() může vrátit duplicity)
        try:
            values = msg.get_all(key)
        except Exception as e:
            # Strukturovaný parser stdlib knihovny selhal na malformované
            # hlavičce - spadneme zpět na syrový text, ať parsování
            # nepadne na celém e-mailu kvůli jedné špatné hlavičce.
            # ZÁMĚRNĚ široký except: mutation-based fuzzing
            # (tests/test_parser_fuzz.py) našel na tomhle jednom volání
            # už DVA různé typy výjimek z cpython stdlib kódu na
            # adversariálním vstupu (IndexError na uťaté adrese,
            # AttributeError na 'Group' adrese bez local_part) - nejde
            # předem vyjmenovat všechny možné pády cizího parseru na
            # záměrně poškozeném vstupu. Bezpečné, protože: (1) máme
            # jasně definovaný fallback (syrový text), (2) loguje se to
            # (viz _log.warning), (3) nejde o skrývání bugu v NAŠEM kódu,
            # ale o obranu proti nepředvídatelné cizí knihovně.
            _log.warning(f"Hlavička '{key}' se nedala strukturovaně naparsovat "
                        f"({type(e).__name__}: {e}), používám syrový text.")
            values = _raw_header_values(msg, key)
        if values:
            # Pokud je hlavička vícenásobná (typicky Received), spojíme
            headers[key_lower] = ' | '.join(str(v) for v in values)
    return headers


def extract_ips_from_received(received_header: str) -> list:
    """Vytáhne všechny veřejné IP adresy (IPv4 i IPv6) z Received hlaviček."""
    if not received_header:
        return []
    candidates = re.findall(IP_REGEX, received_header)
    candidates += re.findall(IPV6_CANDIDATE_REGEX, received_header)
    seen = []
    for ip in candidates:
        if _is_public_ip(ip) and ip not in seen:
            seen.append(ip)
    return seen


def extract_dkim(headers: dict) -> dict:
    """Vytáhne DKIM selector a doménu z DKIM-Signature hlavičky."""
    dkim_raw = headers.get('dkim-signature', '')
    if not dkim_raw:
        return {'selector': None, 'domain': None, 'raw': None}
    selector_match = re.search(r's=\s*([^;]+)', dkim_raw)
    domain_match = re.search(r'd=\s*([^;]+)', dkim_raw)
    return {
        'selector': selector_match.group(1).strip() if selector_match else None,
        'domain': domain_match.group(1).strip() if domain_match else None,
        'raw': dkim_raw[:200]
    }


def extract_auth_results(headers: dict) -> dict:
    """Parsuje SPF/DKIM/DMARC verdikty z Authentication-Results (počítá je přijímající server)."""
    auth_raw = headers.get('authentication-results', '')
    result = {}
    for protocol, verdict in re.findall(AUTH_REGEX, auth_raw.lower()):
        result[protocol.upper()] = verdict
    if 'SPF' not in result and headers.get('received-spf'):
        m = re.search(r'\b(pass|fail|softfail|neutral|none|temperror|permerror)\b',
                       headers['received-spf'].lower())
        if m:
            result['SPF'] = m.group(1)
    return result


ARC_INSTANCE_REGEX = r'i=(\d+)'
ARC_CV_REGEX = r'cv=(\w+)'


def extract_arc_chain(msg) -> list:
    """Vytáhne ARC-Seal a ARC-Authentication-Results a poskládá je do
    chronologického přehledu instancí (i=1 je nejstarší/první přeposlání).
    ARC je důležitý hlavně u přeposílaných zpráv (mailing listy, forwardy
    přes Gmail/M365), kde běžné SPF/DKIM selže i u legitimní pošty, protože
    zpráva prošla přes další server - ARC dokládá, co zjistil KAŽDÝ hop
    v řetězci přeposílání, ne jen ten poslední."""
    seals = msg.get_all('ARC-Seal') or []
    auth_results = msg.get_all('ARC-Authentication-Results') or []

    instances = {}
    for seal in seals:
        i_match = re.search(ARC_INSTANCE_REGEX, seal)
        cv_match = re.search(ARC_CV_REGEX, seal)
        if i_match:
            i = int(i_match.group(1))
            instances.setdefault(i, {})['cv'] = cv_match.group(1) if cv_match else None
    for ar in auth_results:
        i_match = re.search(ARC_INSTANCE_REGEX, ar)
        if i_match:
            i = int(i_match.group(1))
            found = dict(re.findall(AUTH_REGEX, ar.lower()))
            instances.setdefault(i, {}).setdefault('auth_results', {k.upper(): v for k, v in found.items()})

    return [{'instance': i, **instances[i]} for i in sorted(instances.keys())]


def get_message_id_pattern(message_id: str) -> str:
    """
    Normalizuje Message-ID na 'tvar' bez konkrétních náhodných hodnot,
    aby šlo porovnat styl generování (např. formát konkrétního MTA).
    Např. '<abc123.456@mail.example.com>' -> '<HEX.NUM@mail.example.com>'
    """
    if not message_id:
        return ''
    domain_match = re.search(r'@([^>]+)>?', message_id)
    domain = domain_match.group(1) if domain_match else ''
    local = message_id.split('@')[0]
    # nahradíme sekvence hex/číslic/písmen obecným tvarem, ať vynikne struktura
    shape = re.sub(r'[0-9a-fA-F]{6,}', 'HEX', local)
    shape = re.sub(r'\d+', 'NUM', shape)
    return f"{shape}@{domain}"


def parse_eml(filepath: str, audit=None) -> dict:
    """Hlavní vstupní bod - naparsuje .eml a vrátí strukturovaná data.
    audit: volitelný modules.audit.AuditLog - pokud předán, zaloguje kroky."""
    msg, raw = load_eml(filepath)
    if audit:
        audit.log(f"Načten .eml: {filepath}")
    headers = extract_headers(msg)
    if audit:
        audit.log("Extrahovány hlavičky")

    from_addr = parseaddr(headers.get('from', ''))[1]
    reply_to_addr = parseaddr(headers.get('reply-to', ''))[1] if headers.get('reply-to') else None

    received_ips = extract_ips_from_received(headers.get('received', ''))
    dkim = extract_dkim(headers)
    auth = extract_auth_results(headers)
    if audit:
        audit.log("Zpracovány IP/DKIM/Authentication-Results")

    file_sha256 = hashlib.sha256(raw).hexdigest()

    extracted_urls = urls_module.extract_urls(msg)
    link_domains = sorted({u['domain'] for u in extracted_urls if u['domain']})
    extracted_attachments = attachments_module.extract_attachments(msg)
    if audit:
        audit.log(f"Extrahovány odkazy ({len(extracted_urls)}) a přílohy ({len(extracted_attachments)})")

    arc_chain = extract_arc_chain(msg)
    raw_received_headers = msg.get_all('Received') or []
    chain_analysis = received_chain_module.analyze_chain(raw_received_headers)
    if audit:
        audit.log(f"Rozebrán Received řetězec ({chain_analysis['hop_count']} hopů) a ARC")

    mime_fingerprint = mime_fp_module.build_mime_fingerprint(msg)
    message_id_fingerprint = message_id_fp_module.build_message_id_fingerprint(headers.get('message-id', ''))
    html_fingerprint = html_fp_module.build_html_fingerprint(msg)
    if audit:
        audit.log("Vytvořeny MIME, Message-ID a HTML otisky")

    return {
        'filepath': filepath,
        'from': from_addr,
        'reply_to': reply_to_addr,
        'subject': headers.get('subject', ''),
        'date': headers.get('date', ''),
        'message_id': headers.get('message-id', ''),
        'message_id_pattern': get_message_id_pattern(headers.get('message-id', '')),
        'message_id_fingerprint': message_id_fingerprint,
        'user_agent': headers.get('user-agent') or headers.get('x-mailer'),
        'received_ips': received_ips,
        'primary_ip': received_ips[0] if received_ips else None,
        'dkim': dkim,
        'auth_results': auth,
        'auth_explained': explain_auth_results(auth),
        'arc_chain': arc_chain,
        'received_chain': chain_analysis,
        'mime_fingerprint': mime_fingerprint,
        'html_fingerprint': html_fingerprint,
        'x_sender_ip': headers.get('x-sender-ip'),
        'x_originating_ip': headers.get('x-originating-ip'),
        'file_sha256': file_sha256,
        'raw_headers': headers,
        'urls': extracted_urls,
        'link_domains': link_domains,
        'attachments': extracted_attachments,
    }
