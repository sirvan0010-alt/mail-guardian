"""
dns_lookup.py
Volitelný modul pro DNS dotazy (A, MX, TXT, NS) bez externí závislosti -
Python stdlib nemá vestavěnou podporu pro MX/TXT/NS záznamy (jen A/AAAA
přes socket.getaddrinfo), takže je tu minimální implementace syrového
DNS protokolu (RFC 1035) přes UDP socket.

POZNÁMKA K TESTOVÁNÍ: parsovací logika je otestovaná na ručně sestavených
bytech podle RFC 1035 (viz testy), ale skutečné síťové dotazy nebyly
nikdy ověřené proti opravdovému DNS resolveru - prostředí, ve kterém
tohle vzniklo, nemá k DNS provozu přístup. Před ostrým použitím doporučuju
vyzkoušet na pár známých doménách a porovnat s `dig`/`nslookup`.

Použití: dotaz na veřejný resolver (výchozí 8.8.8.8:53), timeout 5s.
Žádný API klíč není potřeba - DNS je věřejná infrastruktura.
"""

import random
import socket
import struct

from .logging_config import get_logger

_log = get_logger('mailguardian.dns')

DEFAULT_RESOLVER = ('8.8.8.8', 53)
QTYPE = {'A': 1, 'NS': 2, 'TXT': 16, 'MX': 15, 'SOA': 6, 'CNAME': 5}
QTYPE_REV = {v: k for k, v in QTYPE.items()}


def _encode_name(name: str) -> bytes:
    """Zakóduje doménové jméno do DNS 'label' formátu (délka + bajty, ukončeno 0)."""
    parts = name.rstrip('.').split('.')
    out = b''
    for p in parts:
        encoded = p.encode('idna') if not p.isascii() else p.encode('ascii')
        out += bytes([len(encoded)]) + encoded
    return out + b'\x00'


def _build_query(name: str, qtype: int) -> bytes:
    txid = random.randint(0, 0xFFFF)
    header = struct.pack('!HHHHHH', txid, 0x0100, 1, 0, 0, 0)  # 0x0100 = standardní dotaz, RD=1
    question = _encode_name(name) + struct.pack('!HH', qtype, 1)  # qtype, qclass=IN
    return header + question, txid


def _decode_name(data: bytes, offset: int) -> tuple:
    """Dekóduje DNS jméno od daného offsetu, včetně komprese (pointer 0xC0..).
    Vrátí (jméno, offset_za_jménem_v_původním_bufferu)."""
    labels = []
    original_offset = None
    jumped = False
    guard = 0
    while True:
        guard += 1
        if guard > 128:
            raise ValueError("DNS name parsing - too many jumps (possible loop)")
        length = data[offset]
        if length == 0:
            offset += 1
            break
        if (length & 0xC0) == 0xC0:  # kompresní pointer
            if not jumped:
                original_offset = offset + 2
            pointer = ((length & 0x3F) << 8) | data[offset + 1]
            offset = pointer
            jumped = True
            continue
        offset += 1
        labels.append(data[offset:offset + length].decode('ascii', errors='replace'))
        offset += length
    end_offset = original_offset if jumped else offset
    return '.'.join(labels), end_offset


def _parse_response(data: bytes, expected_txid: int, qtype: int) -> dict:
    if len(data) < 12:
        raise ValueError("DNS odpověď je příliš krátká")
    txid, flags, qdcount, ancount, nscount, arcount = struct.unpack('!HHHHHH', data[:12])
    if txid != expected_txid:
        raise ValueError("DNS transaction ID nesedí (podvržená/zmatená odpověď?)")
    # AD bit (Authenticated Data, RFC 4035) - bit 10 v hlavičce (0x0020 v
    # 16bitovém flags poli). Nastavuje ho validující resolver sám, když
    # už DNSSEC podpisový řetězec ověřil za nás - nejde o vlastní
    # kryptografické ověřování (to by vyžadovalo stahovat DNSKEY/RRSIG
    # záznamy a verifikovat podpisy, výrazně víc kódu a riziko chyby v
    # kryptografii bez knihovny). Je to tedy signál "resolver říká, že
    # tahle odpověď je DNSSEC-ověřená", ne "sami jsme si to ověřili" -
    # důvěřuješ resolveru (např. 8.8.8.8/1.1.1.1 to dělají spolehlivě).
    dnssec_authenticated = bool(flags & 0x0020)
    rcode = flags & 0x000F
    if rcode != 0:
        rcode_names = {1: 'FORMERR', 2: 'SERVFAIL', 3: 'NXDOMAIN', 4: 'NOTIMP', 5: 'REFUSED'}
        return {'error': f"DNS rcode {rcode} ({rcode_names.get(rcode, 'unknown')})", 'records': [],
                'dnssec_authenticated': dnssec_authenticated}

    offset = 12
    for _ in range(qdcount):  # přeskočit question sekci
        _, offset = _decode_name(data, offset)
        offset += 4  # qtype + qclass

    records = []
    for _ in range(ancount):
        _, offset = _decode_name(data, offset)
        rtype, rclass, ttl, rdlength = struct.unpack('!HHIH', data[offset:offset + 10])
        offset += 10
        rdata_start = offset

        if rtype == QTYPE['A'] and rdlength == 4:
            ip = '.'.join(str(b) for b in data[rdata_start:rdata_start + 4])
            records.append({'type': 'A', 'value': ip, 'ttl': ttl})
        elif rtype == QTYPE['MX']:
            preference = struct.unpack('!H', data[rdata_start:rdata_start + 2])[0]
            exchange, _ = _decode_name(data, rdata_start + 2)
            records.append({'type': 'MX', 'value': exchange, 'preference': preference, 'ttl': ttl})
        elif rtype == QTYPE['NS']:
            ns, _ = _decode_name(data, rdata_start)
            records.append({'type': 'NS', 'value': ns, 'ttl': ttl})
        elif rtype == QTYPE['TXT']:
            txt_parts = []
            pos = rdata_start
            end = rdata_start + rdlength
            while pos < end:
                seg_len = data[pos]
                txt_parts.append(data[pos + 1:pos + 1 + seg_len].decode('utf-8', errors='replace'))
                pos += 1 + seg_len
            records.append({'type': 'TXT', 'value': ''.join(txt_parts), 'ttl': ttl})
        else:
            records.append({'type': QTYPE_REV.get(rtype, f'TYPE{rtype}'), 'value': None, 'ttl': ttl})

        offset = rdata_start + rdlength

    return {'error': None, 'records': records, 'dnssec_authenticated': dnssec_authenticated}


def query(domain: str, record_type: str, resolver: tuple = DEFAULT_RESOLVER, timeout: int = 5) -> dict:
    """Provede DNS dotaz. Nikdy nevyhazuje výjimku - při jakémkoliv problému
    (timeout, síťová chyba, malformed odpověď) vrátí {'error': ..., 'records': []}.
    'dnssec_authenticated' je None (ne False) při chybě - "nevíme", ne
    "není ověřeno", to je věcně jiné tvrzení."""
    if record_type not in QTYPE:
        return {'error': f"Neznámý typ záznamu: {record_type}", 'records': [], 'dnssec_authenticated': None}
    try:
        packet, txid = _build_query(domain, QTYPE[record_type])
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(timeout)
        try:
            sock.sendto(packet, resolver)
            response, _ = sock.recvfrom(4096)
        finally:
            sock.close()
        return _parse_response(response, txid, QTYPE[record_type])
    except socket.timeout:
        return {'error': 'Timeout - DNS resolver neodpověděl', 'records': [], 'dnssec_authenticated': None}
    except OSError as e:
        return {'error': f"Síťová chyba: {e}", 'records': [], 'dnssec_authenticated': None}
    except Exception as e:
        _log.error(f"Neočekávaná chyba: {e}", exc_info=True)
        return {'error': f"Neočekávaná chyba: {e}", 'records': [], 'dnssec_authenticated': None}


def lookup_domain(domain: str, resolver: tuple = DEFAULT_RESOLVER, timeout: int = 5) -> dict:
    """Pohodlná funkce - dotáže se na A, MX, TXT (SPF/DMARC bývá v TXT) a NS
    najednou. Každý dotaz je nezávislý - selhání jednoho neovlivní ostatní."""
    result = {}
    for rtype in ('A', 'MX', 'TXT', 'NS'):
        result[rtype] = query(domain, rtype, resolver=resolver, timeout=timeout)
    return result


def is_dnssec_authenticated(dns_data: dict) -> bool:
    """Vezme výstup lookup_domain() a vrátí, jestli ALESPOŇ jeden úspěšný
    dotaz hlásí DNSSEC ověření (AD bit v odpovědi resolveru). False
    znamená 'nemáme důkaz, že ano' - ne jistotu, že doména DNSSEC nemá
    (mohl selhat dotaz, resolver nemusí validovat, ...).

    ZÁMĚRNĚ se tohle NEPOČÍTÁ do Threat skóre (na rozdíl od young_domain
    apod.) - chybějící DNSSEC je extrémně slabý/šumový signál (drtivá
    většina i naprosto legitimních malých domén DNSSEC nemá nastavené),
    takže by přidávalo falešné poplachy víc, než by pomáhalo. Je to jen
    informační pole v reportu, ne vážený scoring signál."""
    for result in (dns_data or {}).values():
        if result.get('dnssec_authenticated'):
            return True
    return False
