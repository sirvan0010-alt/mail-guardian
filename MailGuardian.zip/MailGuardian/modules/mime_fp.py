"""
mime_fp.py
Otisk MIME struktury e-mailu - hodně phishingových kitů a legitimních
MTA/knihoven generuje charakteristické, opakující se MIME struktury
(pořadí částí, boundary formát, transfer encoding), takže shoda ve
struktuře je další signál společného původu (typicky stejný nástroj
nebo šablona, i když je zbytek infrastruktury jiný).
"""

import re

# Vzory boundary řetězců typické pro konkrétní generátory/knihovny.
# Není vyčerpávající - orientační klasifikace, ne jednoznačná identifikace.
BOUNDARY_PATTERNS = [
    (re.compile(r'^=+\d+=+$'), 'python-email (Python stdlib)'),
    (re.compile(r'^----=_Part_\d+_\d+\.\d+$'), 'JavaMail'),
    (re.compile(r'^----=_NextPart_\d+_\d+_\d+$'), 'Outlook / Exchange'),
    (re.compile(r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$'), 'GUID-style'),
    (re.compile(r'^Apple-Mail-[\w-]+$', re.IGNORECASE), 'Apple Mail'),
    (re.compile(r'^Boundary_\(ID_.+\)$'), 'Apple Mail (starší formát)'),
    (re.compile(r'^_+[0-9A-Za-z]{16,}_+$'), 'generický náhodný token'),
]


def _classify_boundary(boundary: str) -> str:
    if not boundary:
        return 'žádný (single-part zpráva)'
    for pattern, label in BOUNDARY_PATTERNS:
        if pattern.match(boundary):
            return label
    return 'neznámý/vlastní formát'


# Žádný legitimní e-mail nemá desítky úrovní vnořeného multipart -
# limit chrání proti RecursionError na záměrně/náhodně hluboce
# zanořené struktuře (nalezeno MIME fuzzingem - 500 úrovní spadlo,
# 100 ještě prošlo). Hodnota je dost vysoká, aby žádný reálný e-mail
# o ni nezavadil, a dost nízká, aby nehrozil pád na výchozím Python
# recursion limitu (~1000, ale každá úroveň stojí víc než 1 stack frame).
MAX_MIME_DEPTH = 50


def _structure_shape(msg, depth: int = 0) -> str:
    """Rekurzivně sestaví zjednodušenou strukturu MIME stromu jako string,
    např. 'multipart/mixed(multipart/alternative(text/plain,text/html),application/pdf)'."""
    if depth >= MAX_MIME_DEPTH:
        return f"{msg.get_content_type()}(...příliš hluboko zanořeno, oříznuto...)"
    if msg.is_multipart():
        children = ",".join(_structure_shape(part, depth + 1) for part in msg.iter_parts())
        return f"{msg.get_content_type()}({children})"
    return msg.get_content_type()


def build_mime_fingerprint(msg) -> dict:
    """Vrátí otisk MIME struktury pro celou zprávu."""
    structure = _structure_shape(msg)

    boundary = msg.get_boundary()
    boundary_style = _classify_boundary(boundary)

    encodings = set()
    charsets = set()
    part_count = 0
    for part in msg.walk():
        part_count += 1
        cte = part.get('Content-Transfer-Encoding')
        if cte:
            encodings.add(str(cte).strip().lower())
        charset = part.get_content_charset()
        if charset:
            charsets.add(charset.lower())

    return {
        'structure': structure,
        'boundary_style': boundary_style,
        'transfer_encodings': sorted(encodings),
        'charsets': sorted(charsets),
        'part_count': part_count,
    }
