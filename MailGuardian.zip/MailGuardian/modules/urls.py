"""
urls.py
Extrakce odkazů z těla e-mailu (HTML i plain text) + detekce "mismatch"
mezi zobrazeným textem odkazu a jeho skutečným cílem (klasický phishing
indikátor - text říká "vasebanka.cz", ale href vede jinam).

Použit vestavěný html.parser.HTMLParser místo regexu na HTML - regex na HTML
je nespolehlivý a náchylný na obcházení (vnořené tagy, atributy bez uvozovek...).
"""

import re
from html.parser import HTMLParser
from urllib.parse import urlsplit, urlunsplit

TEXT_URL_REGEX = re.compile(r'https?://[^\s<>"\')]+', re.IGNORECASE)


def normalize_url(url: str) -> str:
    """Normalizuje URL pro účely porovnávání/deduplikace:
    - schema a host na lowercase (cesta/query zůstávají case-sensitive, jak mají)
    - odstraní výchozí port (:80 pro http, :443 pro https)
    - odstraní fragment (#...)
    - odstraní koncové lomítko u prázdné cesty
    Dvě URL, které se liší jen v těchhle detailech, ukazují na stejný cíl."""
    try:
        parts = urlsplit(url.strip())
    except Exception:
        return url.strip()

    scheme = parts.scheme.lower()
    netloc = parts.netloc.lower()
    if scheme == 'http' and netloc.endswith(':80'):
        netloc = netloc[:-3]
    elif scheme == 'https' and netloc.endswith(':443'):
        netloc = netloc[:-4]

    path = parts.path or '/'
    if path != '/' and path.endswith('/'):
        path = path.rstrip('/')

    return urlunsplit((scheme, netloc, path, parts.query, ''))


class _LinkExtractor(HTMLParser):
    """Vytáhne <a href=...>text</a> páry z HTML."""

    def __init__(self):
        super().__init__()
        self.links = []
        self._current_href = None
        self._current_text = []

    def handle_starttag(self, tag, attrs):
        if tag.lower() == 'a':
            attrs_dict = dict(attrs)
            href = attrs_dict.get('href')
            if href:
                self._current_href = href
                self._current_text = []

    def handle_data(self, data):
        if self._current_href is not None:
            self._current_text.append(data)

    def handle_endtag(self, tag):
        if tag.lower() == 'a' and self._current_href is not None:
            self.links.append({
                'href': self._current_href,
                'text': ''.join(self._current_text).strip(),
            })
            self._current_href = None
            self._current_text = []


def domain_of_url(url: str) -> str:
    try:
        return urlsplit(url).netloc.lower().split('@')[-1]  # ořízne případné user:pass@
    except Exception:
        return ''


def _looks_like_url_or_domain(text: str) -> bool:
    """True pokud zobrazený text odkazu vypadá jako URL/doména (pro mismatch detekci)."""
    text = text.strip().lower()
    if not text:
        return False
    return bool(re.match(r'^(https?://)?([a-z0-9-]+\.)+[a-z]{2,}(/.*)?$', text))


def extract_from_html(html_content: str) -> list:
    parser = _LinkExtractor()
    try:
        parser.feed(html_content)
    except Exception:
        pass
    results = []
    for link in parser.links:
        href = link['href']
        if not href.lower().startswith(('http://', 'https://')):
            continue  # mailto:, tel:, #anchor, javascript: apod. nejsou webové odkazy
        entry = {
            'url': href,
            'domain': domain_of_url(href),
            'anchor_text': link['text'],
            'source': 'html',
            'mismatch': False,
        }
        if _looks_like_url_or_domain(link['text']):
            text_domain = domain_of_url(
                link['text'] if '://' in link['text'] else f"http://{link['text']}"
            )
            if text_domain and entry['domain'] and text_domain != entry['domain']:
                entry['mismatch'] = True
        results.append(entry)
    return results


def extract_from_text(text_content: str) -> list:
    urls = TEXT_URL_REGEX.findall(text_content or '')
    return [
        {'url': u, 'domain': domain_of_url(u), 'anchor_text': None, 'source': 'text', 'mismatch': False}
        for u in urls
    ]


def extract_urls(msg) -> list:
    """Projde všechny text/html a text/plain části zprávy a vrátí seznam
    unikátních odkazů (podle URL)."""
    all_links = []
    for part in msg.walk():
        content_type = part.get_content_type()
        if content_type not in ('text/html', 'text/plain'):
            continue
        if part.get_content_disposition() == 'attachment':
            continue
        try:
            content = part.get_content()
        except Exception:
            continue
        if not isinstance(content, str):
            continue

        if content_type == 'text/html':
            all_links.extend(extract_from_html(content))
        else:
            all_links.extend(extract_from_text(content))

    seen = set()
    unique = []
    for link in all_links:
        norm = normalize_url(link['url'])
        if norm not in seen:
            seen.add(norm)
            link['normalized_url'] = norm
            unique.append(link)
    return unique
