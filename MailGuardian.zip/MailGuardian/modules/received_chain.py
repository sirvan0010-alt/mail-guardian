"""
received_chain.py
Rozebere CELÝ řetězec Received hlaviček (ne jen první veřejnou IP jako
parser.extract_ips_from_received) na jednotlivé hopy a analyzuje ho:
- klasifikace IP každého hopu (veřejná/privátní/loopback/reserved)
- rozpoznání známých cloud relayů (Google, Microsoft 365, SendGrid...)
- časy mezi hopy (anomálie: záporný čas, neobvykle dlouhá prodleva)
- návaznost řetězce (by hopu N by mělo přibližně odpovídat from hopu N+1 -
  nesedí-li to, řetězec může být přerušený nebo ručně upravený)

Received hlavičky se přidávají odshora - nejnovější (nejblíž příjemci) je
NAHOŘE souboru, nejstarší (nejblíž odesílateli) je DOLE. msg.get_all('Received')
vrací je přesně v tomhle pořadí (nejnovější první).
"""

import re
from datetime import datetime
from email.utils import parsedate_to_datetime
import ipaddress

IP_REGEX = r'\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\b'
IPV6_CANDIDATE_REGEX = r'\b([0-9a-fA-F]{0,4}(?::[0-9a-fA-F]{0,4}){2,7})\b'

# Hostname vzory známých poskytovatelů/relayů - jen orientační, ne vyčerpávající
KNOWN_RELAYS = {
    'google.com': 'Google / Gmail',
    'googlemail.com': 'Google / Gmail',
    'outlook.com': 'Microsoft 365 / Outlook',
    'protection.outlook.com': 'Microsoft 365 (Exchange Online Protection)',
    'amazonses.com': 'Amazon SES',
    'sendgrid.net': 'SendGrid',
    'sendgrid.com': 'SendGrid',
    'mailgun.org': 'Mailgun',
    'mailgun.com': 'Mailgun',
    'mailchimp.com': 'Mailchimp / Mandrill',
    'seznam.cz': 'Seznam.cz',
    'centrum.cz': 'Centrum.cz',
    'zoho.com': 'Zoho Mail',
    'icloud.com': 'iCloud Mail',
    'yahoo.com': 'Yahoo Mail',
}


def _classify_ip(ip_str):
    if not ip_str:
        return None
    try:
        ip = ipaddress.ip_address(ip_str)
    except ValueError:
        return 'invalid'
    if ip.is_loopback:
        return 'loopback'
    if ip.is_link_local:
        return 'link-local'
    if ip.is_private:
        return 'private'
    if not ip.is_global:
        return 'reserved'
    return 'public'


def _extract_ip_from_hop(hop_text: str):
    for m in re.findall(IP_REGEX, hop_text):
        if _classify_ip(m) not in (None, 'invalid'):
            return m
    for m in re.findall(IPV6_CANDIDATE_REGEX, hop_text):
        try:
            ipaddress.ip_address(m)
            return m
        except ValueError:
            continue
    return None


def _known_relay(hostname):
    if not hostname:
        return None
    hostname = hostname.lower()
    for domain, label in KNOWN_RELAYS.items():
        if hostname.endswith(domain):
            return label
    return None


def parse_hop(raw_hop: str) -> dict:
    """Naparsuje jeden Received řádek na strukturovaná data."""
    from_match = re.search(r'\bfrom\s+(\S+)(?:\s*\(([^)]*)\))?', raw_hop, re.IGNORECASE)
    by_match = re.search(r'\bby\s+(\S+)', raw_hop, re.IGNORECASE)

    from_host = from_match.group(1) if from_match else None
    from_paren = from_match.group(2) if from_match else None
    by_host = by_match.group(1) if by_match else None

    ip = _extract_ip_from_hop(raw_hop)
    ip_class = _classify_ip(ip)

    timestamp_iso = None
    if ';' in raw_hop:
        date_part = raw_hop.rsplit(';', 1)[-1].strip()
        try:
            ts = parsedate_to_datetime(date_part)
            if ts is not None:
                timestamp_iso = ts.isoformat()
        except (TypeError, ValueError, OverflowError):
            pass

    relay = _known_relay(from_host) or _known_relay(by_host) or _known_relay(from_paren)

    return {
        'from_host': from_host,
        'from_detail': from_paren,
        'by_host': by_host,
        'ip': ip,
        'ip_class': ip_class,
        'known_relay': relay,
        'timestamp': timestamp_iso,
    }


def analyze_chain(received_headers: list) -> dict:
    """received_headers: list stringů v pořadí msg.get_all('Received')
    (nejnovější/nejblíž příjemci první). Vrátí strukturovaný rozbor."""
    hops = [parse_hop(h) for h in received_headers]
    anomalies = []

    # Čas mezi hopy: hops[i] je novější než hops[i+1]
    for i in range(len(hops) - 1):
        t_new, t_old = hops[i]['timestamp'], hops[i + 1]['timestamp']
        if not (t_new and t_old):
            continue
        try:
            # TypeError nastane, když je jeden timestamp timezone-aware a
            # druhý naive (datetime.fromisoformat() může vrátit oboje
            # podle toho, jestli vstupní řetězec obsahuje UTC offset) -
            # ValueError samotné parsování ISO řetězce. Nalezeno
            # mutation-based fuzzingem (tests/test_parser_fuzz.py) na
            # záměrně poškozeném Received řetězci.
            delta = (datetime.fromisoformat(t_new) - datetime.fromisoformat(t_old)).total_seconds()
        except (ValueError, TypeError):
            continue
        hops[i]['seconds_since_previous_hop'] = delta
        if delta < 0:
            anomalies.append({
                'type': 'negative_time',
                'hop_index': i,
                'detail': f"Hop {i}: časové razítko je starší než předchozí hop o "
                          f"{abs(delta):.0f}s - možný náznak vloženého/podvrženého záznamu.",
            })
        elif delta > 3600:
            anomalies.append({
                'type': 'time_gap',
                'hop_index': i,
                'detail': f"Hop {i}: mezi tímto a předchozím hopem uplynulo "
                          f"{delta / 60:.0f} minut - neobvykle dlouhá prodleva.",
            })

    # Návaznost řetězce: hop i říká "from A by B" (B přijal od A). Hop i+1 (starší)
    # by měl popisovat, jak k tomu A zprávu dostalo - takže 'from' hopu i by se
    # mělo přibližně shodovat s 'by' hopu i+1 (stejný server B).
    for i in range(len(hops) - 1):
        from_host = (hops[i].get('from_host') or '').lower()
        prev_by = (hops[i + 1].get('by_host') or '').lower()
        if from_host and prev_by and from_host != prev_by:
            if not (from_host in prev_by or prev_by in from_host):
                anomalies.append({
                    'type': 'broken_link',
                    'hop_index': i,
                    'detail': f"Hop {i}->{i + 1}: 'from {from_host}' neodpovídá "
                              f"navazujícímu 'by {prev_by}' - řetězec může být přerušený nebo upravený.",
                })

    public_hops = [h for h in hops if h['ip_class'] == 'public']
    # first_public_ip = nejblíž PŘÍJEMCI (odpovídá dosavadnímu parser.primary_ip)
    # origin_public_ip = nejblíž ODESÍLATELI - pravděpodobnější skutečný zdroj zprávy,
    # protože hopy blíž příjemci bývají vlastní infrastruktura přijímače (Google, atd.)
    # a jsou stejné napříč VŠEMI příchozími e-maily, takže samy o sobě nic neodliší.
    first_public_ip = public_hops[0]['ip'] if public_hops else None
    origin_public_ip = public_hops[-1]['ip'] if public_hops else None

    return {
        'hops': hops,
        'hop_count': len(hops),
        'first_public_ip': first_public_ip,
        'origin_public_ip': origin_public_ip,
        'known_relays_seen': sorted({h['known_relay'] for h in hops if h['known_relay']}),
        'anomalies': anomalies,
    }
