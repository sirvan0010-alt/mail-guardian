"""
database.py
Ukládání otisků e-mailů a výsledků porovnání do SQLite.
Umožňuje postupně přidávat nové .eml a porovnávat je se všemi předchozími,
ne jen párově.
"""

import sqlite3
import json
from datetime import datetime

from .logging_config import get_logger

_log = get_logger('mailguardian.database')

SCHEMA = """
CREATE TABLE IF NOT EXISTS emails (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    filepath TEXT UNIQUE,
    from_addr TEXT,
    subject TEXT,
    date_header TEXT,
    file_sha256 TEXT,
    fingerprint_json TEXT,
    added_at TEXT
);

CREATE TABLE IF NOT EXISTS comparisons (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email_a_id INTEGER,
    email_b_id INTEGER,
    score_pct REAL,
    breakdown_json TEXT,
    verdict TEXT,
    compared_at TEXT,
    FOREIGN KEY(email_a_id) REFERENCES emails(id),
    FOREIGN KEY(email_b_id) REFERENCES emails(id)
);

CREATE TABLE IF NOT EXISTS gmail_state (
    message_id TEXT PRIMARY KEY,
    internal_date INTEGER NOT NULL,
    sha256 TEXT NOT NULL,
    file_path TEXT NOT NULL,
    processed_at TEXT NOT NULL
);
"""


def connect(db_path: str = 'database/fingerprints.db'):
    conn = sqlite3.connect(db_path)
    conn.executescript(SCHEMA)
    conn.commit()
    return conn


def store_email(conn, parsed: dict, fp: dict, force_update: bool = False) -> tuple:
    """Uloží e-mail + fingerprint do DB. Vrací (id, was_changed).

    was_changed je True pro nově vložený záznam nebo když se obsah souboru
    od minula změnil (jiný SHA-256) nebo force_update=True - jinak False
    (obsah je stejný jako už uložený, nic se nepřepisovalo).

    Pokud už soubor na této cestě existuje, ale jeho obsah se změnil (jiný
    SHA-256), záznam se přepíše - jinak by se u přepsaného/opraveného .eml
    tiše používal starý neaktuální fingerprint.
    force_update: přepíše záznam i beze změny obsahu - potřebné třeba když
    se stejný soubor znovu zpracuje s --abuseipdb (obohacení dat, ne obsahu),
    jinak by se nový fingerprint s enrichmentem tiše zahodil."""
    cur = conn.execute(
        'SELECT id, file_sha256 FROM emails WHERE filepath = ?', (parsed['filepath'],)
    )
    row = cur.fetchone()
    if row:
        existing_id, existing_sha = row
        if existing_sha == parsed.get('file_sha256') and not force_update:
            return existing_id, False
        conn.execute(
            '''UPDATE emails SET from_addr = ?, subject = ?, date_header = ?,
                                  file_sha256 = ?, fingerprint_json = ?, added_at = ?
               WHERE id = ?''',
            (
                parsed.get('from'), parsed.get('subject'), parsed.get('date'),
                parsed.get('file_sha256'), json.dumps(fp, ensure_ascii=False),
                datetime.now().isoformat(), existing_id,
            )
        )
        conn.commit()
        return existing_id, (existing_sha != parsed.get('file_sha256'))

    cur = conn.execute(
        '''INSERT INTO emails (filepath, from_addr, subject, date_header,
                                file_sha256, fingerprint_json, added_at)
           VALUES (?, ?, ?, ?, ?, ?, ?)''',
        (
            parsed['filepath'],
            parsed.get('from'),
            parsed.get('subject'),
            parsed.get('date'),
            parsed.get('file_sha256'),
            json.dumps(fp, ensure_ascii=False),
            datetime.now().isoformat(),
        )
    )
    conn.commit()
    return cur.lastrowid, True


def store_comparison(conn, id_a: int, id_b: int, result: dict):
    """Uloží výsledek porovnání. Pokud pro tuhle dvojici (v libovolném pořadí)
    už záznam existuje, přepíše ho místo vytváření duplicitního řádku -
    důležité při opakovaném spuštění 'compare-all'."""
    existing = conn.execute(
        '''SELECT id FROM comparisons
           WHERE (email_a_id = ? AND email_b_id = ?)
              OR (email_a_id = ? AND email_b_id = ?)''',
        (id_a, id_b, id_b, id_a)
    ).fetchone()

    breakdown_json = json.dumps(result['breakdown'], ensure_ascii=False)
    now = datetime.now().isoformat()

    if existing:
        conn.execute(
            '''UPDATE comparisons SET score_pct = ?, breakdown_json = ?,
                                       verdict = ?, compared_at = ?
               WHERE id = ?''',
            (result['score_pct'], breakdown_json, result['verdict'], now, existing[0])
        )
    else:
        conn.execute(
            '''INSERT INTO comparisons (email_a_id, email_b_id, score_pct,
                                         breakdown_json, verdict, compared_at)
               VALUES (?, ?, ?, ?, ?, ?)''',
            (id_a, id_b, result['score_pct'], breakdown_json, result['verdict'], now)
        )
    conn.commit()


def _load_fingerprint_json(raw_json: str, context: str = '') -> dict:
    """Deserializuje fingerprint_json sloupec. Nikdy nevrátí nic jiného
    než dict - poškozená/neplatná data (ručně upravená databáze, bitová
    chyba na disku, útočník s přístupem k souboru databáze) by jinak
    jako ne-dict hodnota (list/číslo/None) tiše propadla dál do
    similarity.compare()/threat.assess()/atd., které bezpodmínečně
    předpokládají dict - spadly by s matoucí AttributeError hluboko ve
    scoringu, ne s jasnou chybou tady, kde je příčina zjevná. U
    forenzního nástroje, kde na integritě dat záleží, je tohle důležité
    ošetřit u zdroje, ne nechat spadnout kdesi hluboko v analýze."""
    try:
        data = json.loads(raw_json)
    except (json.JSONDecodeError, TypeError) as e:
        _log.error(f"Poškozený fingerprint_json{f' ({context})' if context else ''}: {e}")
        return {}
    if not isinstance(data, dict):
        _log.error(f"fingerprint_json{f' ({context})' if context else ''} není dict "
                   f"(je to {type(data).__name__}) - databáze je pravděpodobně poškozená.")
        return {}
    return data


def get_all_emails(conn):
    """Vrátí všechny uložené e-maily jako list dictů (id, filepath, fingerprint...)."""
    cur = conn.execute(
        'SELECT id, filepath, from_addr, subject, date_header, fingerprint_json FROM emails'
    )
    result = []
    for row in cur.fetchall():
        result.append({
            'id': row[0],
            'filepath': row[1],
            'from_addr': row[2],
            'subject': row[3],
            'date_header': row[4],
            'fingerprint': _load_fingerprint_json(row[5], context=row[1]),
        })
    return result


def get_email(conn, email_id: int):
    """Vrátí jeden uložený e-mail podle id (stejný tvar jako get_all_emails
    prvky), nebo None. Levnější než re-parsovat .eml, když už víme id ze
    store_email() v tomhle běhu."""
    row = conn.execute(
        'SELECT id, filepath, from_addr, subject, date_header, fingerprint_json FROM emails WHERE id = ?',
        (email_id,)
    ).fetchone()
    if not row:
        return None
    return {
        'id': row[0],
        'filepath': row[1],
        'from_addr': row[2],
        'subject': row[3],
        'date_header': row[4],
        'fingerprint': _load_fingerprint_json(row[5], context=row[1]),
    }


def get_all_comparisons(conn):
    """Vrátí všechna uložená porovnání jako list dictů (email_a_id,
    email_b_id, score_pct, verdict, breakdown)."""
    cur = conn.execute(
        'SELECT email_a_id, email_b_id, score_pct, verdict, breakdown_json FROM comparisons'
    )
    result = []
    for row in cur.fetchall():
        result.append({
            'email_a_id': row[0],
            'email_b_id': row[1],
            'score_pct': row[2],
            'verdict': row[3],
            'breakdown': json.loads(row[4]) if row[4] else {},
        })
    return result


def is_gmail_message_processed(conn, message_id: str) -> bool:
    """True pokud už byla tahle Gmail zpráva (podle message_id) dřív
    stažena - používá se pro dedup při 'gmail sync', nezávisle na
    Gmailových `is:unread`/`label:` příznacích."""
    row = conn.execute('SELECT 1 FROM gmail_state WHERE message_id = ?', (message_id,)).fetchone()
    return row is not None


def record_gmail_message(conn, message_id: str, internal_date: int, sha256: str, file_path: str):
    conn.execute(
        '''INSERT OR REPLACE INTO gmail_state (message_id, internal_date, sha256, file_path, processed_at)
           VALUES (?, ?, ?, ?, ?)''',
        (message_id, internal_date, sha256, file_path, datetime.now().isoformat())
    )
    conn.commit()
