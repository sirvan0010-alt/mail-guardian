"""
virustotal.py
Volitelný modul pro dotaz na reputaci IP adres, URL a hashů příloh přes
VirusTotal API v3. Stejný vzor jako abuseipdb.py: výchozí vypnuto,
--virustotal flag, gracefully degradace, lokální cache.

VirusTotal Public API limit: 500 dotazů/den, 4 dotazy/minutu - proto
striktní rate limiting mezi dotazy (na rozdíl od AbuseIPDB, kde je
limit uvolněnější).

Nastavení API klíče (zdarma na virustotal.com):
  1) proměnná prostředí VIRUSTOTAL_API_KEY, NEBO
  2) config.ini:
        [virustotal]
        api_key = tvuj_klic
"""

import base64
import configparser
import json
import os
import random
import sqlite3
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone

from .logging_config import get_logger

_log = get_logger('mailguardian.virustotal')

IP_API_URL = "https://www.virustotal.com/api/v3/ip_addresses/{id}"
URL_API_URL = "https://www.virustotal.com/api/v3/urls/{id}"
FILE_API_URL = "https://www.virustotal.com/api/v3/files/{id}"

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CACHE_DB = os.path.join(_PROJECT_ROOT, 'database', 'virustotal_cache.db')
CONFIG_PATH = os.path.join(_PROJECT_ROOT, 'config.ini')
CACHE_TTL_DAYS = 30  # VT reputace se mění pomaleji než AbuseIPDB hlášení

# VT Public API: max 4 req/min = 1 req/15s. Modul si mezi dvěma po sobě
# jdoucími skutečnými (necachovanými) dotazy počká, aby limit nepřekročil -
# sdílené napříč IP/URL/hash dotazy (jde o jeden společný limit účtu).
_MIN_INTERVAL_SECONDS = 15
_last_request_time = 0.0

_EMPTY = {
    'available': False,
    'malicious_votes': None,
    'suspicious_votes': None,
    'harmless_votes': None,
    'undetected_votes': None,
    'reputation_score': None,  # malicious / celkem hlasů, v %
    'country': None,
    'as_owner': None,
    'error': None,
}


def _get_api_key():
    key = os.environ.get('VIRUSTOTAL_API_KEY')
    if key:
        return key
    if os.path.exists(CONFIG_PATH):
        cfg = configparser.ConfigParser()
        try:
            cfg.read(CONFIG_PATH)
            return cfg.get('virustotal', 'api_key', fallback=None)
        except configparser.Error:
            return None
    return None


def is_available() -> bool:
    return bool(_get_api_key())


def _rate_limit():
    """Počká, pokud je potřeba, ať nepřekročíme 4 req/min. Volá se jen
    před SKUTEČNÝM síťovým dotazem, ne při cache hitu."""
    global _last_request_time
    elapsed = time.time() - _last_request_time
    if elapsed < _MIN_INTERVAL_SECONDS:
        time.sleep(_MIN_INTERVAL_SECONDS - elapsed)
    _last_request_time = time.time()


def _init_cache():
    os.makedirs(os.path.dirname(CACHE_DB), exist_ok=True)
    conn = sqlite3.connect(CACHE_DB)
    # Migrace ze staršího schématu (sloupec 'ip' před v0.14, kdy cache
    # uměla jen IP dotazy) - cache je čistě lokální/ephemeral data, takže
    # při neshodě schématu ji bezpečně zahodíme a založíme znovu.
    try:
        cols = {row[1] for row in conn.execute('PRAGMA table_info(cache)').fetchall()}
        if cols and 'key' not in cols:
            conn.execute('DROP TABLE cache')
    except sqlite3.Error:
        pass
    conn.execute('''CREATE TABLE IF NOT EXISTS cache (
        key TEXT PRIMARY KEY,
        response_json TEXT,
        fetched_at TEXT
    )''')
    conn.commit()
    _maybe_cleanup(conn)
    return conn


def _maybe_cleanup(conn, probability: float = 0.02):
    if random.random() >= probability:
        return
    cutoff = (datetime.now(timezone.utc) - timedelta(days=CACHE_TTL_DAYS)).isoformat()
    try:
        conn.execute('DELETE FROM cache WHERE fetched_at < ?', (cutoff,))
        conn.commit()
    except Exception:
        pass


def _cache_get(conn, key):
    row = conn.execute('SELECT response_json, fetched_at FROM cache WHERE key = ?', (key,)).fetchone()
    if not row:
        return None
    response_json, fetched_at = row
    try:
        fetched = datetime.fromisoformat(fetched_at)
    except ValueError:
        return None
    if datetime.now(timezone.utc) - fetched > timedelta(days=CACHE_TTL_DAYS):
        return None
    return json.loads(response_json)


def _cache_set(conn, key, data):
    conn.execute(
        'INSERT OR REPLACE INTO cache (key, response_json, fetched_at) VALUES (?, ?, ?)',
        (key, json.dumps(data), datetime.now(timezone.utc).isoformat())
    )
    conn.commit()


def _parse_response(payload: dict) -> dict:
    """Naparsuje odpověď VT API (IP/URL/soubor mají stejný tvar
    last_analysis_stats) do našeho formátu. Vyčleněno do samostatné
    funkce, aby šlo otestovat bez skutečného síťového volání."""
    data = payload.get('data', {}).get('attributes', {})
    stats = data.get('last_analysis_stats', {})

    malicious = stats.get('malicious', 0) or 0
    suspicious = stats.get('suspicious', 0) or 0
    harmless = stats.get('harmless', 0) or 0
    undetected = stats.get('undetected', 0) or 0
    total = malicious + suspicious + harmless + undetected

    reputation_score = round(malicious / total * 100, 1) if total > 0 else None

    return {
        'available': True,
        'malicious_votes': malicious,
        'suspicious_votes': suspicious,
        'harmless_votes': harmless,
        'undetected_votes': undetected,
        'reputation_score': reputation_score,
        'country': data.get('country'),
        'as_owner': data.get('as_owner'),
        'error': None,
    }


def _url_to_id(url: str) -> str:
    """VT identifikuje URL přes base64url encoding BEZ paddingu (viz VT API v3 docs)."""
    return base64.urlsafe_b64encode(url.encode('utf-8')).decode('ascii').rstrip('=')


def _do_lookup(cache_key: str, request_url: str, use_cache: bool, timeout: int) -> dict:
    """Sdílená implementace dotazu (IP/URL/hash se liší jen v endpointu a
    tvaru cache klíče, zbytek - klíč, cache, rate limit, chyby - je stejné)."""
    api_key = _get_api_key()
    if not api_key:
        result = dict(_EMPTY)
        result['error'] = 'Chybí API klíč (nastav VIRUSTOTAL_API_KEY nebo config.ini)'
        return result

    conn = None
    if use_cache:
        try:
            conn = _init_cache()
            cached = _cache_get(conn, cache_key)
            if cached is not None:
                return cached
        except Exception:
            conn = None

    _rate_limit()  # jen před skutečným síťovým dotazem - cache hit tohle přeskočí

    try:
        req = urllib.request.Request(request_url, headers={'x-apikey': api_key})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            payload = json.loads(resp.read().decode('utf-8'))
        result = _parse_response(payload)
    except urllib.error.HTTPError as e:
        result = dict(_EMPTY)
        if e.code == 429:
            result['error'] = "HTTP 429: Rate limit překročen - počkej alespoň minutu"
        elif e.code == 404:
            result['error'] = "HTTP 404: VT o tomhle nic neví (zatím nikdy nescanováno)"
        else:
            result['error'] = f"HTTP {e.code}: {e.reason}"
    except urllib.error.URLError as e:
        result = dict(_EMPTY)
        result['error'] = f"Síťová chyba: {e.reason}"
    except Exception as e:
        result = dict(_EMPTY)
        result['error'] = f"Neočekávaná chyba: {e}"
        _log.error(f"Neočekávaná chyba: {e}", exc_info=True)

    if conn is not None and result.get('available'):
        try:
            _cache_set(conn, cache_key, result)
        except Exception:
            pass

    return result


def lookup(ip: str, use_cache: bool = True, timeout: int = 15) -> dict:
    """Dotaz na VT reputaci IP adresy. Nikdy nevyhazuje výjimku."""
    if not ip:
        return dict(_EMPTY)
    return _do_lookup(f"ip:{ip}", IP_API_URL.format(id=urllib.parse.quote(ip)), use_cache, timeout)


def lookup_url(url: str, use_cache: bool = True, timeout: int = 15) -> dict:
    """Dotaz na VT reputaci konkrétní URL. Nikdy nevyhazuje výjimku."""
    if not url:
        return dict(_EMPTY)
    url_id = _url_to_id(url)
    return _do_lookup(f"url:{url_id}", URL_API_URL.format(id=url_id), use_cache, timeout)


def lookup_file_hash(sha256_hash: str, use_cache: bool = True, timeout: int = 15) -> dict:
    """Dotaz na VT reputaci souboru podle SHA-256. Nikdy nevyhazuje výjimku."""
    if not sha256_hash:
        return dict(_EMPTY)
    return _do_lookup(f"file:{sha256_hash}", FILE_API_URL.format(id=sha256_hash), use_cache, timeout)

