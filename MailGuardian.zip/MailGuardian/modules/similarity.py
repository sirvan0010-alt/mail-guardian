"""
similarity.py
Váhovaný scoring engine - porovná dva fingerprinty a vrátí rozpad skóre
po jednotlivých signálech + celkové procento shody.

Váhy jsou navržené tak, aby silné/vzácné signály (DKIM, shodná IP) měly
mnohem větší váhu než slabé/časté signály (stejná doména u velkého poskytovatele
jako gmail.com by jinak dávala falešně vysoké skóre).
"""

# Váhy jednotlivých signálů (v bodech)
WEIGHTS = {
    'primary_ip': 35,
    'any_ip_overlap': 20,      # vzájemně se vylučuje s primary_ip (if/else)
    'dkim_key': 30,            # selector+doména shoduje se přesně
    'dkim_domain_only': 10,    # vzájemně se vylučuje s dkim_key (if/elif)
    'x_sender_ip': 15,
    'user_agent': 10,
    'message_id_pattern': 10,
    'from_domain': 5,          # slabý signál, snadno false-positive u velkých poskytovatelů
    'geo_asn': 8,              # bonus jen když primary_ip NEsedí (viz compare()) - volitelné, jen s GeoIP
    'link_domain_overlap': 12,  # e-maily odkazují na stejnou (neobvyklou) doménu
    'attachment_hash_match': 20,  # identická příloha (stejný SHA-256) - velmi silný signál
    'mime_structure_match': 10,  # shodná MIME struktura + styl boundary (společný generátor/kit)
    'message_id_generator_match': 8,  # stejný rozpoznaný generátor Message-ID
}

# DŮLEŽITÉ: MAX_SCORE NENÍ prostý součet WEIGHTS.values(). primary_ip/any_ip_overlap
# jsou vzájemně vylučující (if/else) a stejně tak dkim_key/dkim_domain_only (if/elif),
# a geo_asn se počítá jen když primary_ip nesedí. Kdyby se MAX_SCORE počítal jako
# naivní součet všech vah, ani naprosto identický fingerprint by nikdy nedosáhl 100 %
# (reálně by strop byl kolem 73-78 % podle konfigurace) - proto se tu ručně sečte
# jen nejlepší reálně dosažitelná kombinace: primary_ip (dominuje any_ip_overlap+geo_asn
# dohromady, 35 > 20+8) + dkim_key (dominuje dkim_domain_only) + zbylé nezávislé signály,
# které se s ničím nevylučují a mohou nastat současně s primary_ip i dkim_key.
MAX_SCORE = (
    WEIGHTS['primary_ip']
    + WEIGHTS['dkim_key']
    + WEIGHTS['x_sender_ip']
    + WEIGHTS['user_agent']
    + WEIGHTS['message_id_pattern']
    + WEIGHTS['from_domain']
    + WEIGHTS['link_domain_overlap']
    + WEIGHTS['attachment_hash_match']
    + WEIGHTS['mime_structure_match']
    + WEIGHTS['message_id_generator_match']
)

# Odkazové domény, které jsou tak běžné, že shoda mezi dvěma nesouvisejícími
# e-maily neznamená nic (trackery, zkracovače, velké platformy).
LOW_VALUE_LINK_DOMAINS = {
    'google.com', 'youtube.com', 'facebook.com', 'twitter.com', 'x.com',
    'linkedin.com', 'instagram.com', 'bit.ly', 'tinyurl.com', 't.co',
    'goo.gl', 'apple.com', 'microsoft.com', 'unsubscribe.com',
}

# Extrémně běžné MIME struktury - shoda mezi dvěma nesouvisejícími e-maily
# tady nic neznamená (skoro každý plain-text e-mail vypadá takhle stejně).
TRIVIAL_MIME_STRUCTURES = {'text/plain', 'text/html'}

# Domény velkých poskytovatelů - shoda from_domain u nich se ignoruje
# (jinak by dva cizí lidi s gmail.com dostali falešnou shodu)
COMMON_DOMAINS = {
    'gmail.com', 'seznam.cz', 'outlook.com', 'hotmail.com', 'yahoo.com',
    'icloud.com', 'centrum.cz', 'volny.cz', 'atlas.cz', 'email.cz',
    'protonmail.com', 'proton.me',
}


# Signály, které samy o sobě představují silný forenzní nález - i když
# celkové skóre kvůli jinak odlišné infrastruktuře vyjde nízké, stojí
# tahle konkrétní shoda vždy za prověření (např. identická příloha malwaru
# poslaná ze dvou jinak nesouvisejících adres je silný nález sám o sobě).
STRONG_STANDALONE_SIGNALS = {'attachment_hash_match', 'dkim_key', 'primary_ip'}


def compare(fp_a: dict, fp_b: dict) -> dict:
    """Porovná dva fingerprinty, vrátí dict s breakdown a celkovým skóre (0-100)."""
    breakdown = {}

    # --- IP adresy ---
    if fp_a.get('primary_ip') and fp_a.get('primary_ip') == fp_b.get('primary_ip'):
        breakdown['primary_ip'] = WEIGHTS['primary_ip']
    else:
        ips_a = set(fp_a.get('all_ips') or [])
        ips_b = set(fp_b.get('all_ips') or [])
        if ips_a & ips_b:
            breakdown['any_ip_overlap'] = WEIGHTS['any_ip_overlap']

    # --- Geolokace + ASN (volitelné, jen pokud je GeoIP dostupné) ---
    # Počítá se jen když primary_ip NEsedí - jinak by to jen zdvojovalo
    # signál, který primary_ip už zachytil.
    if 'primary_ip' not in breakdown:
        geo_a, geo_b = fp_a.get('geo'), fp_b.get('geo')
        if geo_a and geo_b and geo_a.get('available') and geo_b.get('available'):
            if geo_a.get('asn') and geo_a.get('asn') == geo_b.get('asn'):
                breakdown['geo_asn'] = WEIGHTS['geo_asn']

    # --- DKIM ---
    if fp_a.get('dkim_key') and fp_a.get('dkim_key') == fp_b.get('dkim_key'):
        breakdown['dkim_key'] = WEIGHTS['dkim_key']
    elif (fp_a.get('dkim_domain') and fp_a.get('dkim_domain') == fp_b.get('dkim_domain')):
        breakdown['dkim_domain_only'] = WEIGHTS['dkim_domain_only']

    # --- X-Sender-IP / X-Originating-IP ---
    xs_a = fp_a.get('x_sender_ip') or fp_a.get('x_originating_ip')
    xs_b = fp_b.get('x_sender_ip') or fp_b.get('x_originating_ip')
    if xs_a and xs_a == xs_b:
        breakdown['x_sender_ip'] = WEIGHTS['x_sender_ip']

    # --- User-Agent / X-Mailer ---
    if fp_a.get('user_agent') and fp_a.get('user_agent') == fp_b.get('user_agent'):
        breakdown['user_agent'] = WEIGHTS['user_agent']

    # --- Message-ID pattern (tvar generování, ne konkrétní hodnota) ---
    if fp_a.get('message_id_pattern') and fp_a.get('message_id_pattern') == fp_b.get('message_id_pattern'):
        breakdown['message_id_pattern'] = WEIGHTS['message_id_pattern']

    # --- From doména (jen pokud to není běžný velký poskytovatel) ---
    dom_a = fp_a.get('from_domain')
    if dom_a and dom_a == fp_b.get('from_domain') and dom_a not in COMMON_DOMAINS:
        breakdown['from_domain'] = WEIGHTS['from_domain']

    # --- Odkazy v těle e-mailu (stejná neobvyklá cílová doména) ---
    links_a = set(fp_a.get('link_domains') or []) - LOW_VALUE_LINK_DOMAINS
    links_b = set(fp_b.get('link_domains') or []) - LOW_VALUE_LINK_DOMAINS
    if links_a & links_b:
        breakdown['link_domain_overlap'] = WEIGHTS['link_domain_overlap']

    # --- Přílohy (identický SHA-256) ---
    att_a = set(fp_a.get('attachment_hashes') or [])
    att_b = set(fp_b.get('attachment_hashes') or [])
    if att_a & att_b:
        breakdown['attachment_hash_match'] = WEIGHTS['attachment_hash_match']

    # --- MIME struktura (stejný tvar + styl boundary = pravděpodobně stejný
    # generátor/toolkit) - vynechá triviální single-part text/plain|html shody,
    # ty jsou příliš běžné na to, aby něco znamenaly ---
    mime_a = fp_a.get('mime_fingerprint') or {}
    mime_b = fp_b.get('mime_fingerprint') or {}
    struct_a = mime_a.get('structure')
    if (struct_a and struct_a not in TRIVIAL_MIME_STRUCTURES
            and struct_a == mime_b.get('structure')
            and mime_a.get('boundary_style') == mime_b.get('boundary_style')):
        breakdown['mime_structure_match'] = WEIGHTS['mime_structure_match']

    # --- Message-ID generátor (vynechá neznámý/vlastní formát - shoda
    # dvou "neznámo" nic neznamená) ---
    mid_a = (fp_a.get('message_id_fingerprint') or {}).get('generator_guess')
    mid_b = (fp_b.get('message_id_fingerprint') or {}).get('generator_guess')
    if mid_a and mid_a != 'neznámý/vlastní formát' and mid_a == mid_b:
        breakdown['message_id_generator_match'] = WEIGHTS['message_id_generator_match']

    total_points = sum(breakdown.values())
    score_pct = round((total_points / MAX_SCORE) * 100, 1)
    strong_signal_hit = bool(STRONG_STANDALONE_SIGNALS & breakdown.keys())

    return {
        'score_pct': score_pct,
        'breakdown': breakdown,
        'verdict': _verdict(score_pct, strong_signal_hit),
    }


def _verdict(score_pct: float, strong_signal_hit: bool = False) -> str:
    if score_pct >= 60:
        return "MOŽNÉ STEJNÝ ODESÍLATEL"
    elif score_pct >= 30:
        return "ČÁSTEČNÁ SHODA - stojí za prověření"
    elif strong_signal_hit:
        return "NÍZKÉ CELKOVÉ SKÓRE, ALE SILNÝ JEDNOTLIVÝ NÁLEZ - stojí za prověření"
    else:
        return "NÍZKÁ SHODA"
