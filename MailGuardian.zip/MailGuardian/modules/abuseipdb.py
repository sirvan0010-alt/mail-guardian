"""
abuseipdb.py
Volitelný modul pro dotaz na reputaci IP adresy přes AbuseIPDB API
(https://www.abuseipdb.com/). Na rozdíl od geoip.py jde o ŽIVÉ síťové
volání s denním limitem (free tier ~1000 dotazů/den), takže se NEspouští
automaticky při každém 'add' - jen když si o to řekneš přes --abuseipdb.

Nastavení API klíče (zdarma na https://www.abuseipdb.com/register):
  1) proměnná prostředí ABUSEIPDB_API_KEY, NEBO
  2) config.ini v kořeni projektu:
        [abuseipdb]
        api_key = tvuj_klic

Bez klíče nebo bez síťového přístupu modul potichu vrátí prázdný
výsledek s vysvětlením v poli 'error' - zbytek nástroje funguje beze
změny (stejný vzor gracefully degradace jako geoip.py).

DŮLEŽITÉ UPOZORNĚNÍ K VÁZE VE SCORINGU: reputace IP samotná není silný
důkaz proti konkrétnímu odesílateli - velcí poskytovatelé (Gmail,
Microsoft 365) mají IP rozsahy, které se v databázi mohou objevit kvůli
zneužití jednotlivých účtů, ne proto, že by celá služba byla nebezpečná.
Proto se v threat.py používá jen jako DOPLŇKOVÝ signál s nízkou váhou.
"""

import configparser
import json
import os
import sqlite3
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone

from .logging_config import get_logger

_log = get_logger('mailguardian.abuseipdb')

API_URL = "https://api.abuseipdb.com/api/v2/check"
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CACHE_DB = os.path.join(_PROJECT_ROOT, 'database', 'abuseipdb_cache.db')
CONFIG_PATH = os.path.join(_PROJECT_ROOT, 'config.ini')
CACHE_TTL_DAYS = 7  # AbuseIPDB skóre se nemění každou hodinu, cache šetří denní limit

_EMPTY = {
    'available': False, 'abuse_confidence_score': None, 'total_reports': None,
    'country_code': None, 'isp': None, 'usage_type': None, 'is_whitelisted': None,
    'error': None,
}


def _get_api_key():
    key = os.environ.get('ABUSEIPDB_API_KEY')
    if key:
        return key
    if os.path.exists(CONFIG_PATH):
        cfg = configparser.ConfigParser()
        try:
            cfg.read(CONFIG_PATH)
            return cfg.get('abuseipdb', 'api_key', fallback=None)
        except configparser.Error:
            return None
    return None


def is_available() -> bool:
    """True pokud je nastavený API klíč. Nekontroluje síťovou dostupnost -
    to zjistíme až při skutečném dotazu."""
    return bool(_get_api_key())


def _init_cache():
    os.makedirs(os.path.dirname(CACHE_DB), exist_ok=True)
    conn = sqlite3.connect(CACHE_DB)
    conn.execute('''CREATE TABLE IF NOT EXISTS cache (
        ip TEXT PRIMARY KEY,
        response_json TEXT,
        fetched_at TEXT
    )''')
    conn.commit()
    _maybe_cleanup(conn)
    return conn


def _maybe_cleanup(conn, probability: float = 0.02):
    """Náhodně (s nízkou pravděpodobností) smaže vypršelé cache záznamy,
    ať cache neroste donekonečna. Nekontroluje se při každém dotazu, aby to
    nezatěžovalo běžný provoz - stačí občasný úklid."""
    import random
    if random.random() >= probability:
        return
    cutoff = (datetime.now(timezone.utc) - timedelta(days=CACHE_TTL_DAYS)).isoformat()
    try:
        conn.execute('DELETE FROM cache WHERE fetched_at < ?', (cutoff,))
        conn.commit()
    except Exception:
        pass


def _cache_get(conn, ip):
    row = conn.execute('SELECT response_json, fetched_at FROM cache WHERE ip = ?', (ip,)).fetchone()
    if not row:
        return None
    response_json, fetched_at = row
    try:
        fetched = datetime.fromisoformat(fetched_at)
    except ValueError:
        return None
    if datetime.now(timezone.utc) - fetched > timedelta(days=CACHE_TTL_DAYS):
        return None
    return json.loads(response_json)


def _cache_set(conn, ip, data):
    conn.execute(
        'INSERT OR REPLACE INTO cache (ip, response_json, fetched_at) VALUES (?, ?, ?)',
        (ip, json.dumps(data), datetime.now(timezone.utc).isoformat())
    )
    conn.commit()


def _parse_response(payload: dict) -> dict:
    """Naparsuje odpověď AbuseIPDB API do našeho formátu. Vyčleněno do
    samostatné funkce, aby šlo otestovat bez skutečného síťového volání."""
    data = payload.get('data', {})
    return {
        'available': True,
        'abuse_confidence_score': data.get('abuseConfidenceScore'),
        'total_reports': data.get('totalReports'),
        'country_code': data.get('countryCode'),
        'isp': data.get('isp'),
        'usage_type': data.get('usageType'),
        'is_whitelisted': data.get('isWhitelisted'),
        'error': None,
    }


def lookup(ip: str, use_cache: bool = True, max_age_days: int = 90, timeout: int = 10) -> dict:
    """Dotaz na reputaci IP. Nikdy nevyhazuje výjimku - při jakémkoliv
    problému (chybí klíč, síť nedostupná, HTTP chyba) vrátí prázdný
    výsledek s popisem v 'error'."""
    if not ip:
        return dict(_EMPTY)

    api_key = _get_api_key()
    if not api_key:
        result = dict(_EMPTY)
        result['error'] = 'Chybí API klíč (nastav ABUSEIPDB_API_KEY nebo config.ini)'
        return result

    conn = None
    if use_cache:
        try:
            conn = _init_cache()
            cached = _cache_get(conn, ip)
            if cached is not None:
                return cached
        except Exception:
            conn = None  # cache selhala, pokračujeme bez ní

    try:
        params = urllib.parse.urlencode({'ipAddress': ip, 'maxAgeInDays': max_age_days})
        req = urllib.request.Request(
            f"{API_URL}?{params}",
            headers={'Key': api_key, 'Accept': 'application/json'}
        )
        _log.debug(f"AbuseIPDB dotaz na {ip}")
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            payload = json.loads(resp.read().decode('utf-8'))
        result = _parse_response(payload)
    except urllib.error.HTTPError as e:
        result = dict(_EMPTY)
        result['error'] = f"HTTP {e.code}: {e.reason}"
        _log.warning(f"AbuseIPDB HTTP chyba pro {ip}: {e.code} {e.reason}")
    except urllib.error.URLError as e:
        result = dict(_EMPTY)
        result['error'] = f"Síťová chyba: {e.reason}"
        _log.warning(f"AbuseIPDB síťová chyba pro {ip}: {e.reason}")
    except Exception as e:
        result = dict(_EMPTY)
        result['error'] = f"Neočekávaná chyba: {e}"
        # Tohle by nemělo běžně nastat - graceful degradace to nezhroutí
        # pipeline, ale zaloguje se to jako ERROR, ať to nezůstane tiché
        # (viz code review připomínka: broad except může maskovat bug).
        _log.error(f"AbuseIPDB neočekávaná chyba pro {ip}: {e}", exc_info=True)

    if conn is not None and result.get('available'):
        try:
            _cache_set(conn, ip, result)
        except Exception:
            pass

    return result
