"""
audit.py
Lehký audit trail - zaznamenává kroky analýzy s časovým razítkem.
Účel: při forenzním použití je užitečné vědět přesně, co se s e-mailem
dělo a kdy, ne jen finální výsledek. Volitelný parametr napříč pipeline -
pokud se nepředá, nic se neloguje a zbytek kódu funguje beze změny.
"""

from datetime import datetime


class AuditLog:
    def __init__(self):
        self.entries = []

    def log(self, step: str):
        self.entries.append({'time': datetime.now().isoformat(), 'step': step})

    def as_list(self) -> list:
        return list(self.entries)

    def write(self, path: str):
        with open(path, 'w', encoding='utf-8') as f:
            for e in self.entries:
                f.write(f"{e['time']}  {e['step']}\n")
