"""
report.py
Vygeneruje jednoduchý samostatný HTML report z výsledku porovnání.
Žádné externí závislosti (CSS inline), aby šel report otevřít kdekoliv.
"""

from datetime import datetime
from html import escape

from . import dns_lookup as dns_module

LABELS = {
    'primary_ip': 'Shodná primární IP adresa',
    'any_ip_overlap': 'Shoda v jiné IP z Received řetězce',
    'geo_asn': 'Shodné ASN (jiná IP, stejný poskytovatel/síť)',
    'dkim_key': 'Shodný DKIM (selector + doména)',
    'dkim_domain_only': 'Shodná DKIM doména (jiný selector)',
    'x_sender_ip': 'Shodná X-Sender-IP / X-Originating-IP',
    'user_agent': 'Shodný User-Agent / X-Mailer',
    'message_id_pattern': 'Shodný styl generování Message-ID',
    'from_domain': 'Shodná doména odesílatele',
    'link_domain_overlap': 'Shodná cílová doména v odkazech',
    'attachment_hash_match': 'Identická příloha (shodný SHA-256)',
    'mime_structure_match': 'Shodná MIME struktura (pravděpodobně stejný generátor)',
    'message_id_generator_match': 'Shodný rozpoznaný generátor Message-ID',
}


def _bar(pct: float) -> str:
    filled = round(pct / 10)
    return '█' * filled + '░' * (10 - filled)


def _table_row(label: str, points: int, weight: int) -> str:
    pct_of_weight = round((points / weight) * 100) if weight else 0
    return (
        "<tr>"
        f"<td>{label}</td>"
        f'<td class="mono">{_bar(pct_of_weight)}</td>'
        f"<td>{points}/{weight} b.</td>"
        "</tr>"
    )


def _geo_row(email_a: dict, email_b: dict) -> str:
    """Vrátí volitelný informační řádek s geolokací obou stran (mimo scoring)."""
    geo_a = (email_a.get('fingerprint') or {}).get('geo')
    geo_b = (email_b.get('fingerprint') or {}).get('geo')
    if not geo_a or not geo_b or not geo_a.get('available') or not geo_b.get('available'):
        return ""

    def _fmt(geo):
        parts = [p for p in [geo.get('city'), geo.get('country')] if p]
        loc = ", ".join(parts) or "neznámo"
        org = geo.get('org') or geo.get('asn') or "neznámý poskytovatel"
        return f"{loc} — {org}"

    return (
        "<tr>"
        "<td>Geolokace (informativní, mimo skóre)</td>"
        f'<td class="mono" colspan="2">A: {_fmt(geo_a)}<br>B: {_fmt(geo_b)}</td>'
        "</tr>"
    )


def _auth_section(email: dict) -> str:
    auth = (email.get('fingerprint') or {}).get('auth_explained') or {}
    if not auth:
        return "<p class=\"meta\"><span>Žádné Authentication-Results nenalezeny.</span></p>"
    items = ""
    for protocol, info in auth.items():
        cls = "high" if info.get('suspicious') else "low"
        items += (
            f'<div><span class="{cls}" style="font-weight:600">{escape(protocol)}: '
            f'{escape(str(info.get("verdict")))}</span>'
            f'<br><span class="meta-inline">{escape(str(info.get("explanation")))}</span></div>'
        )
    return items


def _urls_section(email: dict) -> str:
    urls = (email.get('fingerprint') or {}).get('urls_detail') or []
    if not urls:
        return "<p class=\"meta\"><span>Žádné odkazy nenalezeny.</span></p>"
    rows = ""
    for u in urls[:30]:  # pojistka proti extrémně dlouhým reportům
        flag = ' ⚠ TEXT ≠ CÍL' if u.get('mismatch') else ''
        anchor = f' ("{escape(u["anchor_text"])}")' if u.get('anchor_text') else ''
        rows += f'<div class="mono" style="word-break:break-all;">{escape(u["url"])}{escape(anchor)}<span class="high">{flag}</span></div>'
    if len(urls) > 30:
        rows += f'<div class="meta"><span>... a dalších {len(urls) - 30}</span></div>'
    return rows


def _attachments_section(email: dict) -> str:
    atts = (email.get('fingerprint') or {}).get('attachments_detail') or []
    if not atts:
        return "<p class=\"meta\"><span>Žádné přílohy.</span></p>"
    rows = ""
    for a in atts:
        size_kb = round(a.get('size_bytes', 0) / 1024, 1)
        rows += (
            f'<div>{escape(str(a.get("filename")))} '
            f'<span class="meta-inline">({escape(str(a.get("content_type")))}, {size_kb} KB)</span>'
            f'<br><span class="mono" style="font-size:0.75rem;">{escape(str(a.get("sha256")))}</span></div>'
        )
    return rows


def _threat_card(email: dict, label: str) -> str:
    threat = (email.get('fingerprint') or {}).get('threat') or {}
    score = threat.get('score_pct', 0)
    cls = "high" if score >= 60 else "mid" if score >= 30 else "low"
    findings_html = ""
    for f in threat.get('findings', []):
        findings_html += f'<div class="meta-inline">• {escape(f)}</div>'
    if not findings_html:
        findings_html = '<div class="meta-inline">Žádné známé indikátory rizika.</div>'
    return f"""<div class="card">
            <strong>Threat skóre — {escape(label)}</strong>
            <div class="score {cls}" style="font-size:1.6rem;">{score}%</div>
            <div class="verdict {cls}" style="font-size:0.95rem;">{escape(threat.get('verdict', ''))}</div>
            {findings_html}
        </div>"""


def _reputation_card(email: dict, label: str) -> str:
    """Síťová reputace primární IP (AbuseIPDB, VirusTotal) - samostatná
    sekce, protože technicky nejde o součást Received řetězce."""
    fp = email.get('fingerprint') or {}
    abuse = fp.get('abuseipdb')
    vt = fp.get('virustotal')

    lines = []
    if not abuse:
        lines.append('<div class="meta-inline">AbuseIPDB nedotazováno (spusť s --abuseipdb).</div>')
    elif not abuse.get('available'):
        lines.append(f'<div class="meta-inline">AbuseIPDB dotaz selhal: {escape(str(abuse.get("error")))}</div>')
    else:
        score, reports = abuse.get('abuse_confidence_score'), abuse.get('total_reports')
        isp = abuse.get('isp') or '—'
        cls = "high" if (score or 0) >= 50 else "meta-inline"
        lines.append(f'<div class="{cls}">AbuseIPDB: {score}% confidence, {reports} hlášení, '
                     f'ISP: {escape(str(isp))}</div>')

    if not vt:
        lines.append('<div class="meta-inline">VirusTotal nedotazováno (spusť s --virustotal).</div>')
    elif not vt.get('available'):
        lines.append(f'<div class="meta-inline">VirusTotal dotaz selhal: {escape(str(vt.get("error")))}</div>')
    else:
        malicious = vt.get('malicious_votes') or 0
        harmless = vt.get('harmless_votes') or 0
        owner = vt.get('as_owner') or '—'
        cls = "high" if malicious >= 5 else "meta-inline"
        lines.append(f'<div class="{cls}">VirusTotal (IP): {malicious} malicious / {harmless} harmless '
                     f'hlasů, AS: {escape(str(owner))}</div>')

    vt_urls = fp.get('virustotal_urls') or []
    for u in vt_urls:
        r = u.get('result') or {}
        if not r.get('available'):
            continue
        m = r.get('malicious_votes') or 0
        cls = "high" if m >= 3 else "meta-inline"
        lines.append(f'<div class="{cls}">VirusTotal (URL): {escape(u["url"][:60])} - {m} malicious hlasů</div>')

    vt_attachments = fp.get('virustotal_attachments') or []
    for a in vt_attachments:
        r = a.get('result') or {}
        if not r.get('available'):
            continue
        m = r.get('malicious_votes') or 0
        cls = "high" if m >= 3 else "meta-inline"
        lines.append(f'<div class="{cls}">VirusTotal (příloha): {escape(str(a.get("filename")))} - '
                     f'{m} malicious hlasů</div>')

    whois = fp.get('whois')
    if not whois:
        lines.append('<div class="meta-inline">WHOIS nedotazováno (spusť s --whois).</div>')
    elif not whois.get('available'):
        lines.append(f'<div class="meta-inline">WHOIS dotaz selhal: {escape(str(whois.get("error")))}</div>')
    else:
        age = whois.get('domain_age_days')
        registrar = whois.get('registrar') or '—'
        cls = "high" if (age is not None and age < 30) else "meta-inline"
        age_text = f"{age} dní" if age is not None else "neznámé stáří"
        lines.append(f'<div class="{cls}">WHOIS: doména stará {age_text}, registrar: '
                     f'{escape(str(registrar))}</div>')

    dns_data = fp.get('dns')
    if not dns_data:
        lines.append('<div class="meta-inline">DNS nedotazováno (spusť s --dns).</div>')
    else:
        mx_records = dns_data.get('MX', {}).get('records', [])
        txt_records = dns_data.get('TXT', {}).get('records', [])
        mx_text = ', '.join(r['value'] for r in mx_records[:3]) or '—'
        spf_txt = next((r['value'] for r in txt_records if 'spf1' in (r.get('value') or '')), None)
        lines.append(f'<div class="meta-inline">DNS: MX: {escape(mx_text)}'
                     + (f' | SPF (DNS): {escape(spf_txt[:60])}' if spf_txt else '') + '</div>')
        dnssec_ok = dns_module.is_dnssec_authenticated(dns_data)
        dnssec_text = "ověřeno (AD bit)" if dnssec_ok else "neověřeno/chybí"
        lines.append(f'<div class="meta-inline">DNSSEC: {dnssec_text} - jen orientační signál od '
                     f'resolveru, ne vlastní kryptografické ověření</div>')

    return f"""<div class="card">
            <strong>Síťová reputace IP — {escape(label)}</strong>
            {''.join(lines)}
        </div>"""


def _chain_section(email: dict) -> str:
    chain = (email.get('fingerprint') or {}).get('received_chain') or {}
    hops = chain.get('hops') or []
    if not hops:
        return "<p class=\"meta\"><span>Žádné Received hlavičky nenalezeny.</span></p>"

    rows = ""
    for i, hop in enumerate(hops):
        cls = {"public": "low", "private": "meta-inline", "loopback": "meta-inline"}.get(hop.get('ip_class'), "meta-inline")
        relay = f" ({escape(hop['known_relay'])})" if hop.get('known_relay') else ""
        ip_display = f"{escape(str(hop.get('ip') or '—'))}{relay}"
        rows += (
            f'<div class="mono" style="font-size:0.8rem; margin-bottom:0.3rem;">'
            f'#{i} <span class="{cls}">{ip_display}</span> '
            f'<span class="meta-inline">[{escape(str(hop.get("ip_class") or "?"))}] '
            f'from {escape(str(hop.get("from_host") or "?"))} by {escape(str(hop.get("by_host") or "?"))}</span>'
            f'</div>'
        )

    anomalies = chain.get('anomalies') or []
    anomalies_html = ""
    if anomalies:
        for a in anomalies:
            anomalies_html += f'<div class="high" style="font-size:0.8rem;">⚠ {escape(a.get("detail", ""))}</div>'
    else:
        anomalies_html = '<div class="meta-inline">Žádné anomálie v řetězci.</div>'

    origin = chain.get('origin_public_ip')
    origin_html = (f'<div class="meta-inline">Pravděpodobný původ (nejstarší veřejná IP): '
                   f'<span class="mono">{escape(str(origin))}</span></div>') if origin else ""

    return rows + origin_html + '<div style="margin-top:0.5rem;">' + anomalies_html + '</div>'


def _confidence_card(email: dict, label: str) -> str:
    conf = (email.get('fingerprint') or {}).get('confidence') or {}
    score = conf.get('score_pct', 0)
    cls = "low" if score >= 75 else "mid" if score >= 45 else "high"  # obrácené - nízká confidence = červená
    explain_html = ""
    for line in conf.get('explain', []):
        line_cls = "meta-inline" if line.startswith('+0') else "low"
        explain_html += f'<div class="{line_cls}" style="font-size:0.8rem;">{escape(line)}</div>'
    return f"""<div class="card">
            <strong>Confidence — {escape(label)}</strong>
            <div class="score {cls}" style="font-size:1.6rem;">{score}%</div>
            <div class="verdict {cls}" style="font-size:0.9rem;">{escape(conf.get('verdict', ''))}</div>
            {explain_html}
        </div>"""


def _mime_section(email: dict) -> str:
    mime = (email.get('fingerprint') or {}).get('mime_fingerprint') or {}
    mid = (email.get('fingerprint') or {}).get('message_id_fingerprint') or {}
    html_fp = (email.get('fingerprint') or {}).get('html_fingerprint') or {}
    if not mime:
        return "<p class=\"meta\"><span>Žádná MIME data.</span></p>"

    out = (
        f'<div class="mono" style="font-size:0.78rem; word-break:break-all;">{escape(str(mime.get("structure")))}</div>'
        f'<div class="meta-inline">Boundary styl: {escape(str(mime.get("boundary_style")))}</div>'
        f'<div class="meta-inline">Transfer encoding: {escape(", ".join(mime.get("transfer_encodings", [])) or "—")}</div>'
        f'<div class="meta-inline">Charset: {escape(", ".join(mime.get("charsets", [])) or "—")}</div>'
        f'<div class="meta-inline">Počet částí: {mime.get("part_count", "—")}</div>'
    )
    if mid.get('present'):
        out += (f'<div class="meta-inline" style="margin-top:0.4rem;">Message-ID: entropie '
                f'{mid.get("entropy")}, délka {mid.get("length")}, generátor: '
                f'{escape(str(mid.get("generator_guess")))}</div>')
    if html_fp.get('has_html_body'):
        flags = []
        if html_fp.get('tracking_pixels'):
            flags.append(f"{html_fp['tracking_pixels']}× tracking pixel")
        if html_fp.get('hidden_elements'):
            flags.append(f"{html_fp['hidden_elements']}× skrytý prvek")
        if html_fp.get('form_count'):
            flags.append(f"{html_fp['form_count']}× formulář")
        if html_fp.get('base64_images'):
            flags.append(f"{html_fp['base64_images']}× base64 obrázek")
        if flags:
            out += f'<div class="high" style="margin-top:0.3rem; font-size:0.8rem;">⚠ {escape(", ".join(flags))}</div>'
    return out


def generate_html(email_a: dict, email_b: dict, result: dict, out_path: str):
    breakdown = result['breakdown']
    from .similarity import WEIGHTS

    # Řazení pro explainability: signály, které skutečně sedí, první
    # (podle dosažených bodů sestupně), zbytek za nimi podle max. váhy -
    # ať je hned vidět, CO nejvíc přispělo k výslednému skóre.
    ordered_keys = sorted(
        WEIGHTS.keys(),
        key=lambda k: (breakdown.get(k, 0) > 0, breakdown.get(k, 0), WEIGHTS[k]),
        reverse=True,
    )
    rows = "\n        ".join(
        _table_row(LABELS.get(key, key), breakdown.get(key, 0), WEIGHTS[key])
        for key in ordered_keys
    )
    rows += "\n        " + _geo_row(email_a, email_b)

    verdict_class = (
        "high" if result['score_pct'] >= 60 else
        "mid" if result['score_pct'] >= 30 else "low"
    )

    html = f"""<!DOCTYPE html>
<html lang="cs">
<head>
<meta charset="UTF-8">
<title>MailGuardian - Report podobnosti</title>
<style>
    body {{ font-family: -apple-system, Segoe UI, Arial, sans-serif; background:#0f1115; color:#e6e6e6; padding:2rem; max-width:900px; margin:auto; }}
    h1 {{ font-size:1.4rem; }}
    .card {{ background:#1a1d24; border-radius:10px; padding:1.2rem 1.5rem; margin-bottom:1.2rem; border:1px solid #2a2e38; }}
    table {{ width:100%; border-collapse:collapse; }}
    td, th {{ padding:0.5rem 0.6rem; border-bottom:1px solid #2a2e38; text-align:left; }}
    .mono {{ font-family: monospace; letter-spacing:1px; }}
    .score {{ font-size:2.4rem; font-weight:bold; }}
    .high {{ color:#ff5c5c; }}
    .mid {{ color:#ffb84d; }}
    .low {{ color:#5cd97a; }}
    .verdict {{ font-size:1.1rem; font-weight:600; margin-top:0.4rem; }}
    .meta span {{ display:block; color:#9aa0ac; font-size:0.85rem; }}
    .meta-inline {{ color:#9aa0ac; font-size:0.8rem; }}
    .grid {{ display:grid; grid-template-columns:1fr 1fr; gap:1rem; }}
</style>
</head>
<body>
    <h1>MailGuardian — Analýza podobnosti e-mailů</h1>
    <p class="meta"><span>Vygenerováno: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</span></p>

    <div class="grid">
        <div class="card">
            <strong>E-mail A</strong>
            <p class="meta">
                <span>Soubor: {escape(str(email_a['filepath']))}</span>
                <span>Od: {escape(str(email_a.get('from_addr') or 'neznámé'))}</span>
                <span>Předmět: {escape(str(email_a.get('subject') or '—'))}</span>
                <span>Datum: {escape(str(email_a.get('date_header') or '—'))}</span>
            </p>
        </div>
        <div class="card">
            <strong>E-mail B</strong>
            <p class="meta">
                <span>Soubor: {escape(str(email_b['filepath']))}</span>
                <span>Od: {escape(str(email_b.get('from_addr') or 'neznámé'))}</span>
                <span>Předmět: {escape(str(email_b.get('subject') or '—'))}</span>
                <span>Datum: {escape(str(email_b.get('date_header') or '—'))}</span>
            </p>
        </div>
    </div>

    <div class="card">
        <strong style="color:#9aa0ac; font-size:0.85rem;">IDENTITY SIMILARITY SCORE (podobnost původu, ne rizikovost)</strong>
        <div class="score {verdict_class}">{result['score_pct']} %</div>
        <div class="verdict {verdict_class}">{result['verdict']}</div>
    </div>

    <div class="grid">
        {_threat_card(email_a, 'A')}
        {_threat_card(email_b, 'B')}
    </div>

    <div class="grid">
        {_confidence_card(email_a, 'A')}
        {_confidence_card(email_b, 'B')}
    </div>

    <div class="card">
        <table>
            <tr><th>Signál identity (podobnosti původu)</th><th>Shoda</th><th>Body</th></tr>
            {rows}
        </table>
    </div>

    <div class="grid">
        <div class="card">
            <strong>Ověření odesílatele (SPF/DKIM/DMARC) — A</strong>
            {_auth_section(email_a)}
        </div>
        <div class="card">
            <strong>Ověření odesílatele (SPF/DKIM/DMARC) — B</strong>
            {_auth_section(email_b)}
        </div>
    </div>

    <div class="grid">
        <div class="card">
            <strong>Odkazy v e-mailu A</strong>
            {_urls_section(email_a)}
        </div>
        <div class="card">
            <strong>Odkazy v e-mailu B</strong>
            {_urls_section(email_b)}
        </div>
    </div>

    <div class="grid">
        <div class="card">
            <strong>Přílohy — A</strong>
            {_attachments_section(email_a)}
        </div>
        <div class="card">
            <strong>Přílohy — B</strong>
            {_attachments_section(email_b)}
        </div>
    </div>

    <div class="grid">
        <div class="card">
            <strong>MIME struktura — A</strong>
            {_mime_section(email_a)}
        </div>
        <div class="card">
            <strong>MIME struktura — B</strong>
            {_mime_section(email_b)}
        </div>
    </div>

    <div class="grid">
        <div class="card">
            <strong>Received řetězec — A (nejnovější hop nahoře)</strong>
            {_chain_section(email_a)}
        </div>
        <div class="card">
            <strong>Received řetězec — B (nejnovější hop nahoře)</strong>
            {_chain_section(email_b)}
        </div>
    </div>

    <div class="grid">
        {_reputation_card(email_a, 'A')}
        {_reputation_card(email_b, 'B')}
    </div>

    <p class="meta">
        <span>Identity Similarity Score odpovídá na "jak podobné jsou si tyhle dva e-maily
        z hlediska původu/infrastruktury" - vysoké číslo nenamená, že je e-mail nebezpečný,
        jen že oba pravděpodobně přišly ze stejného zdroje.</span>
        <span>Threat skóre odpovídá na "jak rizikový je tenhle konkrétní e-mail" - počítá se
        pro každý e-mail samostatně a nezávisí na tom druhém.</span>
        <span>Obě čísla jsou heuristiky založené na technických signálech - ne jednoznačný
        důkaz totožnosti odesílatele ani definitivní posouzení nebezpečnosti, ale indikátory
        pro další prověření.</span>
    </p>
</body>
</html>"""

    with open(out_path, 'w', encoding='utf-8') as f:
        f.write(html)
