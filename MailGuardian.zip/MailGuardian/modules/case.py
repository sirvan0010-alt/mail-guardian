"""
case.py
Case mode - skupina souvisejících e-mailů (kampaň, incident) v jedné
samostatné, přenositelné složce.

Na rozdíl od hlavní emails/ + database/fingerprints.db (jedna sdílená
databáze pro cokoliv, co kdy analyzuješ) je case složka soběstačná:

    cases/<jmeno>/
        original/       <- kopie přidaných .eml (case vlastní svoji kopii,
                           nezávisí na tom, že originál zůstane na místě)
        reports/         <- HTML+JSON reporty z 'case compare'
        case.db           <- SQLite - stejné schéma jako hlavní databáze,
                             ale jen pro tenhle case
        iocs.json          <- sloučené IOC ze VŠECH e-mailů v case
        timeline.json        <- chronologický přehled (podle Date hlavičky)
        manifest.json          <- integrity manifest celého case

Dá se to celé zabalit/přesunout/archivovat jako jeden kus.
"""

import os
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime

# Ukotveno k umístění tohohle souboru (modules/case.py -> o úroveň výš je
# kořen projektu), stejně jako main.py dělá s DB_PATH/REPORTS_DIR - NE
# čistě 'cases' (relativní k aktuálnímu pracovnímu adresáři). Bez tohohle
# by 'case create' vytvořilo cases/ složku kamkoliv, odkud zrovna běžíš
# main.py, zatímco 'add'/'compare' by pořád mířily do stejné centrální
# databáze - nekonzistentní a matoucí chování mezi příkazy.
CASES_ROOT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'cases')

# Dva prahy, ne jeden - "stojí za ukázání jako kandidát" (nízký) a
# "dost jistý na to, aby se to smělo přiřadit BEZ potvrzení člověkem"
# (vyšší, odpovídá tomu, co jinde ve scoringu znamená "MOŽNÉ STEJNÝ
# ODESÍLATEL" - viz similarity.py). U forenzního nástroje je rozumné
# mít nižší laťku pro "ukázat" než pro "tiše založit/přiřadit samo".
DEFAULT_SUGGEST_THRESHOLD = 30.0
AUTO_ASSIGN_CONFIRM_THRESHOLD = 60.0

# Dva prahy, ne jeden - "stojí za ukázání jako kandidát" (nízký) a
# "dost jistý na to, aby se to smělo přiřadit BEZ potvrzení člověkem"
# (vyšší, odpovídá tomu, co jinde ve scoringu znamená "MOŽNÉ STEJNÝ
# ODESÍLATEL" - viz similarity.py). U forenzního nástroje je rozumné
# mít nižší laťku pro "ukázat" než pro "tiše založit/přiřadit samo".
DEFAULT_SUGGEST_THRESHOLD = 30.0
AUTO_ASSIGN_CONFIRM_THRESHOLD = 60.0


class InvalidCaseName(ValueError):
    """Jméno case obsahuje znaky, které by umožnily zápis mimo cases/
    složku (path traversal) - viz case_dir()."""


def _validate_case_name(name: str) -> str:
    """Odmítne jména, která by přes os.path.join umožnila uniknout z
    CASES_ROOT ven (path traversal: '..', absolutní cesta, oddělovače
    adresářů, nulový bajt). Nalezeno vlastní bezpečnostní kontrolou -
    'case create ../../tmp/x' by jinak vytvořilo složku KDEKOLIV, kam
    má proces právo zapisovat, ne jen uvnitř cases/."""
    if not name or not name.strip():
        raise InvalidCaseName("Jméno case nesmí být prázdné.")
    if '\x00' in name:
        raise InvalidCaseName("Jméno case nesmí obsahovat nulový bajt.")
    if os.path.isabs(name):
        raise InvalidCaseName(f"Jméno case nesmí být absolutní cesta: {name!r}")
    # Explicitní kontrola obou oddělovačů bez ohledu na platformu, na
    # které tohle zrovna běží - '/' a '\' se odmítají vždycky, ne jen
    # tam, kde je to zrovna os.sep/os.altsep (na Linuxu '\' není
    # oddělovač, takže by prošel, ale stejná data/case pak můžou skončit
    # na Windows, kde oddělovač JE - jméno musí být platné všude).
    if '/' in name or '\\' in name:
        raise InvalidCaseName(f"Jméno case nesmí obsahovat oddělovač cesty: {name!r}")
    normalized = os.path.normpath(name)
    if normalized in ('.', '..'):
        raise InvalidCaseName(f"Neplatné jméno case: {name!r}")
    return name


def case_dir(name: str) -> str:
    _validate_case_name(name)
    return os.path.join(CASES_ROOT, name)


def case_db_path(name: str) -> str:
    return os.path.join(case_dir(name), 'case.db')


def case_originals_dir(name: str) -> str:
    return os.path.join(case_dir(name), 'original')


def case_reports_dir(name: str) -> str:
    return os.path.join(case_dir(name), 'reports')


def case_exists(name: str) -> bool:
    return os.path.isdir(case_dir(name))


def create_case(name: str) -> str:
    """Vytvoří adresářovou strukturu case (idempotentní). Vrátí cestu."""
    d = case_dir(name)
    os.makedirs(case_originals_dir(name), exist_ok=True)
    os.makedirs(case_reports_dir(name), exist_ok=True)
    return d


def list_cases() -> list:
    if not os.path.isdir(CASES_ROOT):
        return []
    return sorted(
        n for n in os.listdir(CASES_ROOT)
        if os.path.isdir(os.path.join(CASES_ROOT, n))
    )


def _parse_date_safe(date_header):
    if not date_header:
        return None
    try:
        return parsedate_to_datetime(date_header)
    except (TypeError, ValueError, OverflowError):
        return None


def _escape_dot_label(text: str) -> str:
    """Escapuje uvozovky a zpětná lomítka pro bezpečné vložení do DOT labelu."""
    if text is None:
        return ''
    return str(text).replace('\\', '\\\\').replace('"', '\\"')


def build_relationship_graph(emails: list, comparisons: list, threshold: float = 30.0) -> str:
    """Sestaví graf vztahů mezi e-maily v case ve formátu Graphviz DOT.
    Uzly = e-maily (barva podle threat skóre), hrany = identity similarity
    nad prahem (tloušťka podle skóre). Vykreslit: `dot -Tpng graph.dot -o graph.png`
    (potřebuje nainstalovaný Graphviz - `apt install graphviz` / `brew install graphviz`),
    nebo textový .dot soubor otevřít online na https://dreampuf.github.io/GraphvizOnline/."""
    by_id = {e['id']: e for e in emails}

    lines = ['graph MailGuardianCase {', '  rankdir=LR;', '  node [shape=box, style=filled, fontname="Helvetica"];']

    for e in emails:
        fp = e.get('fingerprint') or {}
        threat = fp.get('threat') or {}
        score = threat.get('score_pct', 0)
        color = '#ffcccc' if score >= 60 else '#fff3cd' if score >= 30 else '#e8f5e9'
        name = _escape_dot_label(os.path.basename(e['filepath']))
        label = f"{name}\\nthreat: {score}%"
        lines.append(f'  n{e["id"]} [label="{label}", fillcolor="{color}"];')

    for c in comparisons:
        if c['score_pct'] < threshold:
            continue
        a_id, b_id = c['email_a_id'], c['email_b_id']
        if a_id not in by_id or b_id not in by_id:
            continue
        penwidth = max(1, round(c['score_pct'] / 20))
        top_signals = sorted(c.get('breakdown', {}).items(), key=lambda kv: kv[1], reverse=True)[:2]
        signal_text = _escape_dot_label(', '.join(k for k, _ in top_signals))
        label = f"{c['score_pct']}%\\n{signal_text}"
        lines.append(f'  n{a_id} -- n{b_id} [label="{label}", penwidth={penwidth}];')

    lines.append('}')
    return '\n'.join(lines)


def graph_summary(emails: list, comparisons: list, threshold: float = 30.0) -> dict:
    """Textové shrnutí grafu (uzly/hrany/komponenty) pro rychlý přehled bez
    nutnosti graf vykreslovat - kolik shluků souvisejících e-mailů case obsahuje."""
    by_id = {e['id']: e for e in emails}
    edges = [(c['email_a_id'], c['email_b_id']) for c in comparisons if c['score_pct'] >= threshold]

    # Union-find pro nalezení souvislých komponent (shluků)
    parent = {e['id']: e['id'] for e in emails}

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(x, y):
        rx, ry = find(x), find(y)
        if rx != ry:
            parent[rx] = ry

    for a, b in edges:
        if a in parent and b in parent:
            union(a, b)

    clusters = {}
    for eid in parent:
        root = find(eid)
        clusters.setdefault(root, []).append(by_id[eid]['filepath'])

    cluster_list = sorted(clusters.values(), key=len, reverse=True)
    return {
        'node_count': len(emails),
        'edge_count': len(edges),
        'cluster_count': len(cluster_list),
        'largest_cluster_size': len(cluster_list[0]) if cluster_list else 0,
        'clusters': cluster_list,
    }


def generate_auto_case_name(date_header: str, file_sha256: str) -> str:
    """Vygeneruje jméno pro automaticky založený case, když nový e-mail
    nesedí do žádného existujícího - `auto_<datum>_<hash8>`. Datum z
    Date hlavičky (pokud se dá naparsovat), jinak 'unknown'. Hash zajistí
    unikátnost i při stejném datu. Deterministické a čitelné - dá se podle
    jména poznat, kdy a z čeho case vznikl, aniž by ses musel dívat dovnitř.

    Bere explicitní parametry (ne fingerprint dict) - fingerprint sám o
    sobě datum hlavičky neobsahuje (to je jen v `parsed` výstupu parseru),
    takže by bylo matoucí předstírat, že jde vytáhnout z `fp`."""
    dt = _parse_date_safe(date_header) if date_header else None
    date_str = dt.strftime('%Y%m%d') if dt else 'unknown'
    sha = (file_sha256 or '00000000')[:8]
    return f"auto_{date_str}_{sha}"


def _domains_of(fp: dict) -> set:
    domains = set(fp.get('link_domains') or [])
    if fp.get('from_domain'):
        domains.add(fp['from_domain'])
    return domains


def _ips_of(fp: dict) -> set:
    ips = set(fp.get('all_ips') or [])
    if fp.get('primary_ip'):
        ips.add(fp['primary_ip'])
    return ips


def suggest_cases_for_fingerprint(new_fp: dict, suggest_threshold: float = DEFAULT_SUGGEST_THRESHOLD) -> list:
    """Porovná nový fingerprint proti VŠEM existujícím case složkám -
    pro každý case najde nejlepší shodu mezi novým e-mailem a kterýmkoliv
    e-mailem už v tom case. Vrátí seřazený seznam kandidátů (sestupně
    podle skóre), jen ty nad `suggest_threshold` (nebo se silným
    jednotlivým nálezem - stejná konvence jako `watch`/`case compare`).

    Neřeší se tu shoda IOC samostatným průchodem - similarity.compare()
    už sdílenou IP/doménu/hash přílohy zahrnuje jako součást Identity
    Similarity signálů. `shared_domains`/`shared_ips`/
    `shared_attachment_sha256` v návratové hodnotě jsou jen PŘEHLEDOVÉ
    (co konkrétně sedí mezi novým mailem a nejbližší shodou), ne druhé
    nezávislé skóre."""
    from . import database, similarity

    candidates = []
    for case_name in list_cases():
        db_path = case_db_path(case_name)
        if not os.path.exists(db_path):
            continue
        try:
            conn = database.connect(db_path)
            existing_emails = database.get_all_emails(conn)
        except Exception:
            continue
        if not existing_emails:
            continue

        best = None
        best_fp = None
        for e in existing_emails:
            result = similarity.compare(new_fp, e['fingerprint'])
            if best is None or result['score_pct'] > best['score_pct']:
                best = {
                    'score_pct': result['score_pct'],
                    'verdict': result['verdict'],
                    'breakdown': result['breakdown'],
                    'matched_filepath': e['filepath'],
                }
                best_fp = e['fingerprint']

        if best is None:
            continue
        strong_signal_hit = 'SILNÝ JEDNOTLIVÝ NÁLEZ' in best['verdict']
        noteworthy = best['score_pct'] >= suggest_threshold or strong_signal_hit
        if not noteworthy:
            continue

        top_signals = sorted(best['breakdown'].items(), key=lambda kv: kv[1], reverse=True)[:3]
        candidates.append({
            'case_name': case_name,
            'best_score': best['score_pct'],
            'verdict': best['verdict'],
            'matched_filepath': best['matched_filepath'],
            'best_match_file': best['matched_filepath'],
            'top_signals': top_signals,
            'strong_signal_hit': strong_signal_hit,
            'email_count': len(existing_emails),
            'shared_domains': sorted(_domains_of(new_fp) & _domains_of(best_fp)),
            'shared_ips': sorted(_ips_of(new_fp) & _ips_of(best_fp)),
            'shared_attachment_sha256': sorted(
                set(new_fp.get('attachment_hashes') or []) & set(best_fp.get('attachment_hashes') or [])
            ),
        })

    candidates.sort(key=lambda c: c['best_score'], reverse=True)
    return candidates


def should_auto_assign(candidate: dict, confirm_threshold: float = AUTO_ASSIGN_CONFIRM_THRESHOLD) -> bool:
    """True pokud je kandidát dost jistý na to, aby se e-mail směl
    přiřadit BEZ ručního potvrzení - buď má silný jednotlivý nález
    (identická příloha/DKIM/IP), nebo je celkové skóre vysoké."""
    return bool(candidate.get('strong_signal_hit')) or candidate.get('best_score', 0) >= confirm_threshold


def find_matching_cases(new_fp: dict, threshold: float = DEFAULT_SUGGEST_THRESHOLD) -> list:
    """Zpětně kompatibilní jednodušší tvar `suggest_cases_for_fingerprint()`
    (bez shared_domains/shared_ips/atd.) - používaný tam, kde stačí jen
    case_name/best_score/verdict/matched_filepath/top_signals."""
    full = suggest_cases_for_fingerprint(new_fp, suggest_threshold=threshold)
    keys = ('case_name', 'best_score', 'verdict', 'matched_filepath', 'top_signals')
    return [{k: c[k] for k in keys} for c in full]


def build_timeline(emails: list) -> list:
    """emails: list z database.get_all_emails() (obsahují 'fingerprint').
    Vrátí chronologicky seřazený přehled - e-maily bez parsovatelného
    Date headeru jdou na konec (v takovém případě řazené podle cesty)."""
    def sort_key(e):
        dt = _parse_date_safe(e.get('date_header'))
        # (je_neznámé, čas) - neznámé (True) se řadí za známé (False);
        # datetime.max jako fallback pro None, aby sort() nepadal na
        # porovnání None s datetime.
        return (dt is None, dt or datetime.max.replace(tzinfo=timezone.utc), e.get('filepath', ''))

    ordered = sorted(emails, key=sort_key)
    timeline = []
    for e in ordered:
        fp = e.get('fingerprint') or {}
        threat = fp.get('threat') or {}
        timeline.append({
            'filepath': e.get('filepath'),
            'from': e.get('from_addr'),
            'subject': e.get('subject'),
            'date_header': e.get('date_header'),
            'primary_ip': fp.get('primary_ip'),
            'origin_public_ip': fp.get('origin_public_ip'),
            'threat_score': threat.get('score_pct'),
            'threat_verdict': threat.get('verdict'),
        })
    return timeline
