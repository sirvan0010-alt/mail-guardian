"""
whois_lookup.py
Volitelný modul pro WHOIS dotazy (stáří domény, registrar, nameservery)
bez externí závislosti - přímo přes TCP port 43 (RFC 3912), žádný API
klíč, žádný rate limit ze strany nástroje (ale WHOIS servery samy můžou
limitovat příliš časté dotazy).

WHOIS odpovědi NEMAJÍ jednotný strojově čitelný formát - každý registrar/
registry má trochu jiný text. Parsování je proto heuristické (regex na
běžné vzory), ne garantovaně přesné pro každou TLD. Stejný přístup jako
homoglyph.py/mime_fp.py - "orientační", ne jednoznačné.

Pro obecné TLD (.com, .net, .org...) se nejdřív zeptáme IANA, který WHOIS
server je pro danou TLD zodpovědný, a pak se zeptáme JEHO (referral).
Pro .cz specificky používáme přímo whois.nic.cz.

POZNÁMKA K TESTOVÁNÍ: parsovací logika je otestovaná na syntetických
WHOIS odpovědích modelovaných podle reálného formátu, ale skutečné
dotazy nebyly nikdy ověřené proti opravdovým WHOIS serverům - prostředí,
ve kterém tohle vzniklo, nemá k portu 43 přístup.
"""

import re
import socket
from datetime import datetime, timezone

from .logging_config import get_logger

_log = get_logger('mailguardian.whois')

IANA_WHOIS = ('whois.iana.org', 43)
TLD_SERVERS = {
    'cz': 'whois.nic.cz',
    'com': 'whois.verisign-grs.com',
    'net': 'whois.verisign-grs.com',
    'org': 'whois.pir.org',
}

DATE_PATTERNS = [
    r'Creation Date:\s*([\d\-T:Z\.\+]+)',
    r'Registered on:\s*([\d\w\-]+)',
    r'created:\s*([\d\-T:Z\.\+ ]+)',
    r'Registration Date:\s*([\d\-T:Z\.\+]+)',
]
REGISTRAR_PATTERNS = [
    r'Registrar:\s*(.+)',
    r'registrar:\s*(.+)',
    r'Sponsoring Registrar:\s*(.+)',
]
NAMESERVER_PATTERNS = [
    r'Name Server:\s*(\S+)',
    r'nserver:\s*(\S+)',
    r'Nserver:\s*(\S+)',
]

_EMPTY = {
    'available': False, 'creation_date': None, 'registrar': None,
    'name_servers': [], 'domain_age_days': None, 'raw_excerpt': None, 'error': None,
}


def _query_raw(server: str, domain: str, timeout: int = 10) -> str:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(timeout)
    try:
        sock.connect((server, 43))
        sock.sendall((domain + '\r\n').encode('ascii'))
        chunks = []
        while True:
            chunk = sock.recv(4096)
            if not chunk:
                break
            chunks.append(chunk)
        return b''.join(chunks).decode('utf-8', errors='replace')
    finally:
        sock.close()


def _find_referral(iana_response: str) -> str:
    m = re.search(r'refer:\s*(\S+)', iana_response, re.IGNORECASE)
    return m.group(1) if m else None


def _parse_date(text: str):
    for pattern in DATE_PATTERNS:
        m = re.search(pattern, text)
        if m:
            raw = m.group(1).strip()
            # Zkusíme pár běžných formátů, ať to není jen syrový string
            for fmt in ('%Y-%m-%dT%H:%M:%SZ', '%Y-%m-%d', '%d-%b-%Y', '%Y-%m-%d %H:%M:%S'):
                try:
                    dt = datetime.strptime(raw, fmt)
                    return dt.replace(tzinfo=timezone.utc), raw
                except ValueError:
                    continue
            return None, raw  # nepodařilo se naparsovat na datetime, ale text máme
    return None, None


def parse_whois_text(text: str) -> dict:
    """Vytáhne strukturovaná data ze syrového WHOIS textu. Vyčleněno do
    samostatné funkce, aby šlo otestovat bez skutečného síťového dotazu."""
    result = dict(_EMPTY)
    result['available'] = True
    result['raw_excerpt'] = text[:2000]

    dt, raw_date = _parse_date(text)
    if raw_date:
        result['creation_date'] = raw_date
        if dt:
            age = (datetime.now(timezone.utc) - dt).days
            result['domain_age_days'] = age

    for pattern in REGISTRAR_PATTERNS:
        m = re.search(pattern, text)
        if m:
            result['registrar'] = m.group(1).strip()
            break

    servers = set()
    for pattern in NAMESERVER_PATTERNS:
        for m in re.finditer(pattern, text):
            servers.add(m.group(1).strip().lower().rstrip('.'))
    result['name_servers'] = sorted(servers)

    return result


def lookup(domain: str, timeout: int = 10) -> dict:
    """Dotaz na WHOIS pro doménu. Nikdy nevyhazuje výjimku - při jakémkoliv
    problému (timeout, síťová chyba, neznámá TLD) vrátí prázdný výsledek."""
    if not domain:
        return dict(_EMPTY)

    tld = domain.rsplit('.', 1)[-1].lower()
    server = TLD_SERVERS.get(tld)

    try:
        if not server:
            # Neznáme server pro tuhle TLD napřímo - zeptáme se IANA na referral
            iana_response = _query_raw(IANA_WHOIS[0], domain, timeout=timeout)
            server = _find_referral(iana_response)
            if not server:
                result = dict(_EMPTY)
                result['error'] = f"Nepodařilo se najít WHOIS server pro .{tld} (IANA referral selhal)"
                return result

        raw_text = _query_raw(server, domain, timeout=timeout)
        return parse_whois_text(raw_text)
    except socket.timeout:
        result = dict(_EMPTY)
        result['error'] = 'Timeout - WHOIS server neodpověděl'
        return result
    except OSError as e:
        result = dict(_EMPTY)
        result['error'] = f"Síťová chyba: {e}"
        return result
    except Exception as e:
        result = dict(_EMPTY)
        result['error'] = f"Neočekávaná chyba: {e}"
        _log.error(f"Neočekávaná chyba: {e}", exc_info=True)
        return result
