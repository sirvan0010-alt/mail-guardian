"""
gmail_connector.py
Čistá implementace Gmail API konektoru bez externích závislostí - jen
stdlib (urllib, http.server, json, base64, hashlib). Vědomé architektonické
rozhodnutí: zbytek projektu drží "0 externích knihoven pro jádro" (viz
docs/architecture.md), takže i OAuth2 flow je napsaný ručně, ne přes
google-auth-oauthlib/google-api-python-client.

Scope je natvrdo 'gmail.readonly' - MailGuardian nikdy nic v Gmailu
nemaže ani neoznačuje, jen čte a stahuje kopie.

Síťová vrstva (OAuth token exchange, Gmail API volání) je záměrně
oddělená od čisté logiky (generování názvu souboru, výpočet hashe,
kontrola duplicit) - viz `generate_eml_filename()` a `sync_gmail_emails()`
parametr `list_fn`/`fetch_fn` pro dependency injection v testech.

POZNÁMKA K TESTOVÁNÍ: OAuth token exchange a Gmail API volání jsou
otestované s mockovaným `urlopen` (stejný vzor jako abuseipdb.py/
virustotal.py). Lokální HTTP server pro zachycení OAuth redirectu JE
plně testovatelný (běží jen na localhost, žádná externí síť) - test
mu pošle simulovaný redirect request. Co NEJDE otestovat tady: skutečné
přihlášení do Google účtu v prohlížeči - to je nutné vyzkoušet u tebe.
"""

import base64
import hashlib
import http.server
import json
import os
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from datetime import datetime, timezone

from .logging_config import get_logger

_log = get_logger('mailguardian.gmail')

SCOPES = 'https://www.googleapis.com/auth/gmail.readonly'
OAUTH_AUTH_URL = 'https://accounts.google.com/o/oauth2/v2/auth'
OAUTH_TOKEN_URL = 'https://oauth2.googleapis.com/token'
GMAIL_API_BASE = 'https://gmail.googleapis.com/gmail/v1/users/me'

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TOKEN_PATH = os.path.join(_PROJECT_ROOT, 'token.json')
DEFAULT_CALLBACK_PORT = 8765


# ==================== ČISTÁ LOGIKA (bez síťového volání) ====================

def _b64url_decode(data: str) -> bytes:
    """Base64url dekódování se správně dopočítaným paddingem (Gmail API
    posílá padding často oříznutý)."""
    padding = '=' * (-len(data) % 4)
    return base64.urlsafe_b64decode(data + padding)


def generate_eml_filename(internal_date_ms: int, raw_bytes: bytes) -> str:
    """Vygeneruje název souboru ve tvaru YYYYMMDD_HHMMSS_<sha256[:10]>.eml -
    čistá funkce, žádné I/O, snadno testovatelná."""
    sha_short = hashlib.sha256(raw_bytes).hexdigest()[:10]
    if internal_date_ms and internal_date_ms > 0:
        dt = datetime.fromtimestamp(internal_date_ms / 1000.0, tz=timezone.utc)
        date_str = dt.strftime('%Y%m%d_%H%M%S')
    else:
        date_str = 'unknown_date'
    return f"{date_str}_{sha_short}.eml"


def validate_sync_limit(requested_max: int, max_allowed: int):
    """Bezpečnostní pojistka proti překlepu/omylu (--max 100000).
    Vyhazuje ValueError, nevrací nic - volající si to odchytí sám."""
    if requested_max > max_allowed:
        raise ValueError(
            f"Požadovaný počet e-mailů ({requested_max}) přesahuje bezpečný "
            f"limit ({max_allowed}). Uprav --max, nebo zvyš max_allowed v config.ini."
        )


# ==================== OAUTH2 - PRVOTNÍ AUTORIZACE ====================

class _OAuthCallbackHandler(http.server.BaseHTTPRequestHandler):
    """Zachytí jednorázový redirect z Google OAuth consent obrazovky na
    http://localhost:<port>/ a vytáhne z něj `code` parametr."""
    received_code = None
    received_error = None

    def do_GET(self):
        parsed = urllib.parse.urlsplit(self.path)
        params = urllib.parse.parse_qs(parsed.query)
        if 'code' in params:
            _OAuthCallbackHandler.received_code = params['code'][0]
            body = "Autorizace proběhla, můžeš zavřít tuhle záložku a vrátit se do terminálu."
        else:
            _OAuthCallbackHandler.received_error = params.get('error', ['neznámá chyba'])[0]
            body = f"Autorizace selhala: {_OAuthCallbackHandler.received_error}"
        self.send_response(200)
        self.send_header('Content-Type', 'text/plain; charset=utf-8')
        self.end_headers()
        self.wfile.write(body.encode('utf-8'))

    def log_message(self, format, *args):
        pass  # ať to nespamuje stdout http server logy


def _wait_for_oauth_redirect(port: int, timeout: int = 180) -> str:
    """Spustí lokální HTTP server, počká na jeden redirect s `code`
    parametrem, vrátí authorization code. Vyhazuje TimeoutError, pokud
    uživatel autorizaci nedokončí včas."""
    _OAuthCallbackHandler.received_code = None
    _OAuthCallbackHandler.received_error = None
    server = http.server.HTTPServer(('localhost', port), _OAuthCallbackHandler)
    server.timeout = 1  # handle_request() timeout, ne celkový

    thread_stop = threading.Event()
    deadline = time.time() + timeout
    try:
        while not thread_stop.is_set():
            server.handle_request()
            if _OAuthCallbackHandler.received_code:
                return _OAuthCallbackHandler.received_code
            if _OAuthCallbackHandler.received_error:
                raise PermissionError(f"OAuth autorizace odmítnuta: {_OAuthCallbackHandler.received_error}")
            if time.time() > deadline:
                raise TimeoutError("Vypršel časový limit pro dokončení OAuth autorizace v prohlížeči.")
    finally:
        server.server_close()


def run_oauth_flow(client_id: str, client_secret: str, port: int = DEFAULT_CALLBACK_PORT) -> dict:
    """Provede kompletní jednorázovou OAuth2 autorizaci (authorization code
    flow s lokálním redirect serverem) a vrátí token dict s access_token +
    refresh_token. Uloží ho i do TOKEN_PATH."""
    redirect_uri = f"http://localhost:{port}/"
    auth_params = urllib.parse.urlencode({
        'client_id': client_id,
        'redirect_uri': redirect_uri,
        'response_type': 'code',
        'scope': SCOPES,
        'access_type': 'offline',   # nutné, ať dostaneme refresh_token
        'prompt': 'consent',        # vynutí nový refresh_token i při opakované autorizaci
    })
    auth_url = f"{OAUTH_AUTH_URL}?{auth_params}"

    print("Otevírám prohlížeč pro autorizaci Gmail přístupu (jen čtení).")
    print(f"Pokud se prohlížeč neotevře sám, otevři ručně: {auth_url}")
    webbrowser.open(auth_url)

    code = _wait_for_oauth_redirect(port)

    token_data = urllib.parse.urlencode({
        'client_id': client_id,
        'client_secret': client_secret,
        'code': code,
        'grant_type': 'authorization_code',
        'redirect_uri': redirect_uri,
    }).encode('utf-8')
    req = urllib.request.Request(OAUTH_TOKEN_URL, data=token_data, method='POST')
    with urllib.request.urlopen(req, timeout=15) as resp:
        tokens = json.loads(resp.read().decode('utf-8'))

    tokens['client_id'] = client_id
    tokens['client_secret'] = client_secret
    tokens['obtained_at'] = time.time()
    _save_token(tokens)
    return tokens


def _save_token(tokens: dict):
    with open(TOKEN_PATH, 'w', encoding='utf-8') as f:
        json.dump(tokens, f, indent=2)


def _load_token() -> dict:
    with open(TOKEN_PATH, 'r', encoding='utf-8') as f:
        return json.load(f)


def refresh_access_token(client_id: str, client_secret: str, refresh_token: str) -> dict:
    """Obnoví access_token pomocí refresh_token. Nikdy nevyhazuje neočekávanou
    výjimku ven - HTTP chyby zabalí do PermissionError se srozumitelnou zprávou."""
    data = urllib.parse.urlencode({
        'client_id': client_id,
        'client_secret': client_secret,
        'refresh_token': refresh_token,
        'grant_type': 'refresh_token',
    }).encode('utf-8')
    req = urllib.request.Request(OAUTH_TOKEN_URL, data=data, method='POST')
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        body = e.read().decode('utf-8', errors='replace')
        _log.error(f"Obnova OAuth tokenu selhala: {e.code} {body}")
        raise PermissionError(f"Nelze obnovit přístupový token Gmail API (HTTP {e.code}). "
                               f"Možná je potřeba znovu autorizovat: main.py gmail-auth")


def get_access_token(client_id: str, client_secret: str) -> str:
    """Vrátí platný access_token - z uloženého tokenu (obnoví ho, pokud je
    starý), nebo vyhodí FileNotFoundError, pokud ještě neproběhla prvotní
    autorizace (viz `main.py gmail-auth`)."""
    if not os.path.exists(TOKEN_PATH):
        raise FileNotFoundError(
            f"Chybí {TOKEN_PATH} - nejdřív spusť prvotní autorizaci: python3 main.py gmail-auth"
        )
    tokens = _load_token()
    # access_token má obvykle platnost 1 hodinu - obnovíme ho vždy předem,
    # ať se nemusíme trefovat přesně do expirace (o obnovu navíc nejde,
    # je to jedno HTTP volání navíc, ne drahá operace).
    refreshed = refresh_access_token(client_id, client_secret, tokens['refresh_token'])
    tokens['access_token'] = refreshed['access_token']
    tokens['obtained_at'] = time.time()
    _save_token(tokens)
    return tokens['access_token']


# ==================== GMAIL REST API ====================

def _gmail_get(endpoint: str, access_token: str, params: dict = None, timeout: int = 15) -> dict:
    url = f"{GMAIL_API_BASE}/{endpoint}"
    if params:
        url += '?' + urllib.parse.urlencode(params)
    req = urllib.request.Request(url)
    req.add_header('Authorization', f'Bearer {access_token}')
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode('utf-8'))


def list_messages(access_token: str, query: str, max_results: int) -> list:
    """Vrátí list {'id': ..., 'threadId': ...} - jen ID, ne obsah zpráv."""
    try:
        res = _gmail_get('messages', access_token, {'q': query, 'maxResults': max_results})
        return res.get('messages', [])
    except urllib.error.HTTPError as e:
        _log.error(f"Gmail list_messages selhalo: HTTP {e.code}")
        return []


def fetch_raw_message(access_token: str, message_id: str) -> tuple:
    """Stáhne RFC822 raw obsah zprávy. Vrátí (raw_bytes, internal_date_ms)."""
    res = _gmail_get(f'messages/{message_id}', access_token, {'format': 'raw'})
    raw_bytes = _b64url_decode(res['raw'])
    internal_date_ms = int(res.get('internalDate', 0))
    return raw_bytes, internal_date_ms


# ==================== ORCHESTRACE (dependency injection pro testy) ====================

def sync_gmail_emails(conn, client_id: str, client_secret: str, query: str, max_results: int,
                       max_allowed: int, out_dir: str, list_fn=None, fetch_fn=None) -> list:
    """Hlavní synchronizační smyčka. `list_fn`/`fetch_fn` jsou injectované
    (výchozí = None, doplní se na skutečné Gmail API volání níž), aby šlo
    v testech podstrčit mockované funkce a otestovat dedup/ukládací logiku
    bez sítě. Vyhledávají se jako jména modulu AŽ při volání (ne jako
    defaultní hodnoty parametru, které by se navázaly na funkci už při
    definici a nešly by přepatchovat přes unittest.mock.patch.object)."""
    from . import database
    if list_fn is None:
        list_fn = list_messages
    if fetch_fn is None:
        fetch_fn = fetch_raw_message

    validate_sync_limit(max_results, max_allowed)
    os.makedirs(out_dir, exist_ok=True)

    access_token = get_access_token(client_id, client_secret)
    candidates = list_fn(access_token, query, max_results)

    downloaded = []
    for meta in candidates:
        msg_id = meta['id']
        if database.is_gmail_message_processed(conn, msg_id):
            _log.debug(f"Zpráva {msg_id} už zpracovaná, přeskakuji.")
            continue
        try:
            raw_bytes, internal_date_ms = fetch_fn(access_token, msg_id)
        except Exception as e:
            _log.error(f"Stažení zprávy {msg_id} selhalo: {e}")
            continue

        filename = generate_eml_filename(internal_date_ms, raw_bytes)
        filepath = os.path.join(out_dir, filename)
        with open(filepath, 'wb') as f:
            f.write(raw_bytes)

        sha256 = hashlib.sha256(raw_bytes).hexdigest()
        database.record_gmail_message(conn, msg_id, internal_date_ms, sha256, filepath)
        downloaded.append(filepath)
        _log.info(f"Stažena nová zpráva: {filepath}")

    return downloaded
