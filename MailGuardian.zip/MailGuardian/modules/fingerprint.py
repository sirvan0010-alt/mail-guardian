"""
fingerprint.py
Vytvoří normalizovaný "otisk" e-mailu z dat naparsovaných v parser.py.
Otisk je JSON-serializovatelný dict, který se ukládá do DB a používá
pro porovnávání v similarity.py.
"""

from . import geoip as geoip_module
from . import threat as threat_module
from . import confidence as confidence_module
from . import abuseipdb as abuseipdb_module
from . import virustotal as virustotal_module
from . import whois_lookup as whois_module
from . import dns_lookup as dns_module


def domain_of(addr: str) -> str:
    if not addr or '@' not in addr:
        return ''
    return addr.split('@')[-1].lower()


def build_fingerprint(parsed: dict, enable_geoip: bool = True, enable_abuseipdb: bool = False,
                       enable_virustotal: bool = False, enable_whois: bool = False,
                       enable_dns: bool = False, audit=None) -> dict:
    """Vezme výstup parser.parse_eml() a sestaví fingerprint.

    enable_geoip: pokud True a je dostupná knihovna geoip2 + mmdb databáze,
    doplní geolokaci/ASN primární IP. Jinak se pole 'geo' nastaví na None -
    zbytek fingerprintu a scoringu funguje beze změny.
    enable_abuseipdb: pokud True a je nastavený API klíč, dotáže se na
    reputaci primární IP přes AbuseIPDB (živé síťové volání s denním
    limitem) - proto výchozí False, na rozdíl od GeoIP to není zadarmo.
    enable_virustotal: stejně jako abuseipdb, ale přes VirusTotal (přísnější
    rate limit - 4 dotazy/minutu, viz modules/virustotal.py).
    enable_whois / enable_dns: dotáže se na WHOIS/DNS domény odesílatele
    (stáří domény, nameservery, MX, TXT/SPF...) - syrové TCP/UDP protokoly,
    žádný API klíč, ale žádné testování live provozu (viz moduly), takže
    výchozí vypnuto, dokud si to sám neověříš.
    audit: volitelný modules.audit.AuditLog - pokud předán, zaloguje kroky."""
    dkim = parsed.get('dkim', {})
    dkim_key = None
    if dkim.get('selector') and dkim.get('domain'):
        dkim_key = f"{dkim['selector']}@{dkim['domain']}"

    geo = None
    primary_ip = parsed.get('primary_ip')
    if enable_geoip and primary_ip and geoip_module.is_available():
        geo = geoip_module.lookup(primary_ip)

    abuse = None
    if enable_abuseipdb and primary_ip and abuseipdb_module.is_available():
        abuse = abuseipdb_module.lookup(primary_ip)
        if audit:
            if abuse.get('available'):
                audit.log(f"AbuseIPDB dotaz na {primary_ip}: skóre {abuse.get('abuse_confidence_score')}")
            else:
                audit.log(f"AbuseIPDB dotaz na {primary_ip} selhal: {abuse.get('error')}")

    vt = None
    vt_urls = []
    vt_attachments = []
    if enable_virustotal and virustotal_module.is_available():
        if primary_ip:
            vt = virustotal_module.lookup(primary_ip)
            if audit:
                if vt.get('available'):
                    audit.log(f"VirusTotal IP dotaz na {primary_ip}: {vt.get('malicious_votes')} malicious hlasů")
                else:
                    audit.log(f"VirusTotal IP dotaz na {primary_ip} selhal: {vt.get('error')}")

        # URL a hash příloh - capped na pár unikátních položek, ať jeden
        # e-mail s desítkami odkazů nezablokuje rate limit (4 dotazy/min)
        # na dlouhou dobu. Priorita: přílohy (méně jich bývá, silnější
        # signál), pak prvních pár unikátních URL.
        url_candidates = []
        for u in (parsed.get('urls') or []):
            norm = u.get('normalized_url') or u.get('url')
            if norm and norm not in url_candidates:
                url_candidates.append(norm)
        for u in url_candidates[:3]:
            r = virustotal_module.lookup_url(u)
            vt_urls.append({'url': u, 'result': r})
            if audit:
                if r.get('available'):
                    audit.log(f"VirusTotal URL dotaz na {u}: {r.get('malicious_votes')} malicious hlasů")
                else:
                    audit.log(f"VirusTotal URL dotaz na {u} selhal: {r.get('error')}")

        for a in (parsed.get('attachments') or [])[:5]:
            h = a.get('sha256')
            if not h:
                continue
            r = virustotal_module.lookup_file_hash(h)
            vt_attachments.append({'sha256': h, 'filename': a.get('filename'), 'result': r})
            if audit:
                if r.get('available'):
                    audit.log(f"VirusTotal hash dotaz na {a.get('filename')}: {r.get('malicious_votes')} malicious hlasů")
                else:
                    audit.log(f"VirusTotal hash dotaz na {a.get('filename')} selhal: {r.get('error')}")

    from_domain = domain_of(parsed.get('from'))

    whois_data = None
    if enable_whois and from_domain:
        whois_data = whois_module.lookup(from_domain)
        if audit:
            if whois_data.get('available'):
                audit.log(f"WHOIS dotaz na {from_domain}: stáří {whois_data.get('domain_age_days')} dní")
            else:
                audit.log(f"WHOIS dotaz na {from_domain} selhal: {whois_data.get('error')}")

    dns_data = None
    if enable_dns and from_domain:
        dns_data = dns_module.lookup_domain(from_domain)
        if audit:
            errors = [r['error'] for r in dns_data.values() if r.get('error')]
            audit.log(f"DNS dotazy na {from_domain} (A/MX/TXT/NS)"
                      + (f" - chyby: {'; '.join(errors)}" if errors else " - OK"))

    fp = {
        'from_addr': parsed.get('from'),
        'from_domain': from_domain,
        'reply_to_addr': parsed.get('reply_to'),
        'reply_to_domain': domain_of(parsed.get('reply_to')) if parsed.get('reply_to') else None,
        'primary_ip': parsed.get('primary_ip'),
        'all_ips': parsed.get('received_ips', []),
        'dkim_key': dkim_key,
        'dkim_domain': dkim.get('domain'),
        'user_agent': parsed.get('user_agent'),
        'message_id_pattern': parsed.get('message_id_pattern'),
        'x_sender_ip': parsed.get('x_sender_ip'),
        'x_originating_ip': parsed.get('x_originating_ip'),
        'auth_results': parsed.get('auth_results', {}),
        'file_sha256': parsed.get('file_sha256'),
        'geo': geo,
        'abuseipdb': abuse,
        'virustotal': vt,
        'virustotal_urls': vt_urls,
        'virustotal_attachments': vt_attachments,
        'whois': whois_data,
        'dns': dns_data,
        'link_domains': parsed.get('link_domains', []),
        'attachment_hashes': [a['sha256'] for a in parsed.get('attachments', [])],
        # Detailní data pro HTML report (na rozdíl od polí výše se nepoužívají
        # ve scoringu identity similarity, jen k zobrazení a threat skóre):
        'urls_detail': parsed.get('urls', []),
        'attachments_detail': parsed.get('attachments', []),
        'auth_explained': parsed.get('auth_explained', {}),
        'received_chain': parsed.get('received_chain', {}),
        'origin_public_ip': (parsed.get('received_chain') or {}).get('origin_public_ip'),
        'arc_chain': parsed.get('arc_chain', []),
        'mime_fingerprint': parsed.get('mime_fingerprint', {}),
        'message_id_fingerprint': parsed.get('message_id_fingerprint', {}),
        'html_fingerprint': parsed.get('html_fingerprint', {}),
    }

    # Threat a Confidence skóre potřebují pole, co jsme právě sestavili výše -
    # proto se počítají až teď, ne jako součást parseru.
    fp['threat'] = threat_module.assess(fp)
    if audit:
        audit.log(f"Spočítáno Threat skóre: {fp['threat']['score_pct']}%")
    fp['confidence'] = confidence_module.assess(fp)
    if audit:
        audit.log(f"Spočítáno Confidence skóre: {fp['confidence']['score_pct']}%")

    return fp
