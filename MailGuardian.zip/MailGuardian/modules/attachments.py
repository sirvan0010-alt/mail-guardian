"""
attachments.py
Vytáhne přílohy z e-mailu a spočítá jejich SHA-256 - pro porovnání mezi
e-maily (stejná příloha = silný indikátor) a případné dohledání hashe
ve VirusTotal/MalwareBazaar (ručně, nástroj sám nikam hash neposílá).
"""

import hashlib


def extract_attachments(msg) -> list:
    """Vrátí seznam příloh: filename, content_type, velikost, SHA-256."""
    results = []
    for part in msg.walk():
        disposition = part.get_content_disposition()
        filename = part.get_filename()
        # Příloha = má content-disposition: attachment NEBO má filename
        # (některé maily posílají přílohy bez explicitního "attachment" dispozice)
        if disposition != 'attachment' and not filename:
            continue
        try:
            payload = part.get_payload(decode=True)
        except Exception:
            payload = None
        if payload is None:
            continue

        results.append({
            'filename': filename or '(bez názvu)',
            'content_type': part.get_content_type(),
            'size_bytes': len(payload),
            'sha256': hashlib.sha256(payload).hexdigest(),
        })
    return results
