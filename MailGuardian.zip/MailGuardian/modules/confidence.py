"""
confidence.py
Confidence skóre - odpovídá na "kolik kvalitních dat máme k dispozici pro
analýzu tohohle e-mailu", ne "jak podobný" nebo "jak nebezpečný" je.

Nízké Identity/Threat skóre s vysokou Confidence znamená "data jsou
kvalitní, výsledek je spolehlivý". Stejné nízké skóre s nízkou Confidence
znamená "nemáme dost dat, výsledek nemusí nic znamenat" - třeba e-mail
prošel přes anonymizační službu, chybí většina hlaviček, nebo je to jen
holý text bez příloh/odkazů k porovnání.
"""

CONFIDENCE_WEIGHTS = {
    'has_received_chain': 25,   # aspoň jeden Received hop
    'has_multiple_hops': 10,    # 2+ hopy - dá se sledovat skutečná cesta
    'has_auth_results': 20,     # víme SPF/DKIM/DMARC verdikt (i kdyby fail)
    'has_dkim_signature': 15,   # DKIM podpis vůbec přítomný (bez ohledu na platnost)
    'has_arc': 10,              # ARC řetězec přítomný (přeposílané zprávy)
    'has_message_id': 10,       # netriviální Message-ID
    'has_body_content': 10,     # HTML nebo text tělo k analýze (odkazy/MIME mají smysl)
}
CONFIDENCE_MAX = sum(CONFIDENCE_WEIGHTS.values())


def assess(fp: dict) -> dict:
    """Vezme fingerprint a spočítá, kolik využitelných dat je k dispozici."""
    breakdown = {}
    missing = []
    explain = []  # (weight, satisfied: bool, label) - pro plnou vysvětlitelnost, i nesplněné položky

    def _check(key: str, label: str, satisfied: bool, missing_text: str = None):
        w = CONFIDENCE_WEIGHTS[key]
        if satisfied:
            breakdown[key] = w
        elif missing_text:
            missing.append(missing_text)
        explain.append((w, satisfied, label))

    chain = fp.get('received_chain') or {}
    hop_count = chain.get('hop_count', 0)
    _check('has_received_chain', 'Alespoň jeden Received hop', hop_count >= 1,
           "Chybí Received hlavičky - nelze sledovat cestu e-mailu vůbec.")
    _check('has_multiple_hops', '2+ Received hopů (sledovatelná cesta)', hop_count >= 2)

    _check('has_auth_results', 'Authentication-Results přítomné (SPF/DKIM/DMARC verdikt)',
           bool(fp.get('auth_results')), "Chybí Authentication-Results - neznáme SPF/DKIM/DMARC verdikt.")

    _check('has_dkim_signature', 'DKIM podpis přítomný (bez ohledu na platnost)', bool(fp.get('dkim_domain')))

    _check('has_arc', 'ARC řetězec přítomný (přeposílané zprávy)', bool(fp.get('arc_chain')))

    mid_fp = fp.get('message_id_fingerprint') or {}
    _check('has_message_id', 'Netriviální Message-ID',
           bool(mid_fp.get('present') and mid_fp.get('length', 0) >= 8),
           "Chybí nebo je triviální Message-ID.")

    html_fp = fp.get('html_fingerprint') or {}
    mime_fp = fp.get('mime_fingerprint') or {}
    _check('has_body_content', 'HTML/MIME tělo k analýze (odkazy/struktura mají smysl)',
           bool(html_fp.get('has_html_body') or (mime_fp.get('part_count', 0) > 1)),
           "Jen holý text bez HTML/příloh - méně signálů k porovnání.")

    total = sum(breakdown.values())
    score_pct = round((total / CONFIDENCE_MAX) * 100, 1)

    # Seřadit podle váhy sestupně (nejvýznamnější faktor první), splněné i
    # nesplněné dohromady - u nesplněných se zobrazí "+0" a jejich potenciál,
    # aby bylo jasné, co konkrétně nejvíc chybí ke spolehlivějšímu výsledku.
    explain.sort(key=lambda e: e[0], reverse=True)
    explain_formatted = [
        (f"+{w} {label}" if satisfied else f"+0 {label} (chybí, možných +{w})")
        for w, satisfied, label in explain
    ]

    return {
        'score_pct': score_pct,
        'breakdown': breakdown,
        'missing': missing,
        'explain': explain_formatted,
        'verdict': _verdict(score_pct),
    }


def _verdict(score_pct: float) -> str:
    if score_pct >= 75:
        return "VYSOKÁ - dostatek dat pro spolehlivý výsledek"
    elif score_pct >= 45:
        return "STŘEDNÍ - výsledek berte s rezervou"
    else:
        return "NÍZKÁ - chybí většina dat, výsledek nemusí nic znamenat"
