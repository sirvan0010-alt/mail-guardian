"""
html_fp.py
Otisk HTML těla e-mailu nad rámec pouhých odkazů (to dělá urls.py):
tracking pixely, formuláře, externí/base64 obrázky, skryté prvky,
inline CSS. Používá stejný přístup jako urls.py - vestavěný html.parser,
ne regex na HTML (nespolehlivé, obejitelné).
"""

import re
from html.parser import HTMLParser
from urllib.parse import urlsplit

HIDDEN_STYLE_REGEX = re.compile(r'display\s*:\s*none|visibility\s*:\s*hidden|opacity\s*:\s*0\b', re.IGNORECASE)
DATA_URI_REGEX = re.compile(r'^data:image/', re.IGNORECASE)


class _HtmlFingerprintParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.tracking_pixels = 0
        self.external_images = 0
        self.base64_images = 0
        self.form_count = 0
        self.form_actions = []
        self.hidden_elements = 0
        self.inline_style_count = 0
        self.style_block_count = 0

    def handle_starttag(self, tag, attrs):
        attrs_dict = dict(attrs)
        tag = tag.lower()

        if tag == 'img':
            src = attrs_dict.get('src', '')
            width = attrs_dict.get('width', '')
            height = attrs_dict.get('height', '')
            style = attrs_dict.get('style', '') or ''
            is_tiny = (str(width) in ('0', '1') and str(height) in ('0', '1')) or \
                      bool(re.search(r'width\s*:\s*[01]px', style)) and bool(re.search(r'height\s*:\s*[01]px', style))
            if is_tiny:
                self.tracking_pixels += 1
            if DATA_URI_REGEX.match(src):
                self.base64_images += 1
            elif src.lower().startswith(('http://', 'https://')):
                self.external_images += 1

        elif tag == 'form':
            self.form_count += 1
            self.form_actions.append(attrs_dict.get('action', ''))

        elif tag == 'style':
            self.style_block_count += 1

        style_attr = attrs_dict.get('style', '') or ''
        if style_attr:
            self.inline_style_count += 1
            if HIDDEN_STYLE_REGEX.search(style_attr):
                self.hidden_elements += 1
        if 'hidden' in attrs_dict:
            self.hidden_elements += 1


def _domain_of(url: str) -> str:
    try:
        return urlsplit(url).netloc.lower()
    except Exception:
        return ''


def analyze_html(html_content: str) -> dict:
    parser = _HtmlFingerprintParser()
    try:
        parser.feed(html_content)
    except Exception:
        pass

    return {
        'tracking_pixels': parser.tracking_pixels,
        'external_images': parser.external_images,
        'base64_images': parser.base64_images,
        'form_count': parser.form_count,
        'form_action_domains': sorted({_domain_of(a) for a in parser.form_actions if a}),
        'hidden_elements': parser.hidden_elements,
        'inline_style_count': parser.inline_style_count,
        'style_block_count': parser.style_block_count,
    }


def build_html_fingerprint(msg) -> dict:
    """Projde všechny text/html části zprávy a sečte nálezy dohromady."""
    aggregate = {
        'tracking_pixels': 0, 'external_images': 0, 'base64_images': 0,
        'form_count': 0, 'form_action_domains': set(), 'hidden_elements': 0,
        'inline_style_count': 0, 'style_block_count': 0, 'has_html_body': False,
    }
    for part in msg.walk():
        if part.get_content_type() != 'text/html':
            continue
        if part.get_content_disposition() == 'attachment':
            continue
        try:
            content = part.get_content()
        except Exception:
            continue
        if not isinstance(content, str):
            continue
        aggregate['has_html_body'] = True
        result = analyze_html(content)
        for key in ('tracking_pixels', 'external_images', 'base64_images', 'form_count',
                    'hidden_elements', 'inline_style_count', 'style_block_count'):
            aggregate[key] += result[key]
        aggregate['form_action_domains'].update(result['form_action_domains'])

    aggregate['form_action_domains'] = sorted(aggregate['form_action_domains'])
    return aggregate
