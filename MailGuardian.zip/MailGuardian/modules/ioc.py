"""
ioc.py
Vytáhne strukturované IOC (Indicators of Compromise) z jednoho fingerprintu -
IP adresy, domény, URL, e-mailové adresy, hashe příloh. Určeno pro export do
JSON a další zpracování (SIEM, blocklist, sdílení s týmem...).
"""


def extract_iocs(fp: dict) -> dict:
    """Vezme fingerprint (výstup fingerprint.build_fingerprint) a vrátí
    plochý přehled IOC, každý typ jako seřazený seznam bez duplicit."""
    ips = set()
    if fp.get('primary_ip'):
        ips.add(fp['primary_ip'])
    if fp.get('origin_public_ip'):
        ips.add(fp['origin_public_ip'])
    ips.update(fp.get('all_ips') or [])
    for hop in (fp.get('received_chain') or {}).get('hops', []):
        if hop.get('ip') and hop.get('ip_class') == 'public':
            ips.add(hop['ip'])

    domains = set()
    if fp.get('from_domain'):
        domains.add(fp['from_domain'])
    if fp.get('reply_to_domain'):
        domains.add(fp['reply_to_domain'])
    if fp.get('dkim_domain'):
        domains.add(fp['dkim_domain'])
    domains.update(fp.get('link_domains') or [])

    urls = set()
    for u in fp.get('urls_detail') or []:
        norm = u.get('normalized_url') or u.get('url')
        if norm:
            urls.add(norm)

    emails = set()
    if fp.get('from_addr'):
        emails.add(fp['from_addr'])
    if fp.get('reply_to_addr'):
        emails.add(fp['reply_to_addr'])

    attachment_hashes = set(fp.get('attachment_hashes') or [])

    return {
        'ips': sorted(ips),
        'domains': sorted(domains),
        'urls': sorted(urls),
        'emails': sorted(emails),
        'attachment_sha256': sorted(attachment_hashes),
    }
