"""
threat.py
Skóre RIZIKOVOSTI jednoho e-mailu ("jak nebezpečný je tenhle e-mail").

Na rozdíl od similarity.py (který odpovídá na "jak podobné jsou si DVA
e-maily z hlediska původu/infrastruktury"), tenhle modul pracuje jen s
JEDNÍM e-mailem a nepotřebuje nic porovnávat - takže se dá spočítat hned
při 'add', ne až při 'compare'.

Důležité rozlišení (proč jsou to dvě oddělená skóre, ne jedno):
dva e-maily mohou mít nízkou identity similarity (jiná infrastruktura,
jiný odesílatel) a přitom být OBA vysoce rizikové - a naopak dva e-maily
od stejného odesílatele (vysoká identity similarity) mohou být neškodné.
Michání těchhle dvou otázek do jednoho čísla by výsledek dělalo matoucím.
"""

from . import homoglyph as homoglyph_module

THREAT_WEIGHTS = {
    'spf_fail': 20,
    'dkim_fail': 20,
    'dmarc_fail': 20,
    'url_mismatch': 25,
    'homoglyph_domain': 30,
    'suspicious_attachment': 25,
    'broken_chain': 15,
    'tracking_pixel': 8,
    'hidden_content': 15,
    'embedded_form': 15,
    'abuseipdb_reputation': 12,
    'virustotal_reputation': 10,
    'young_domain': 18,
    'virustotal_url_malicious': 22,
    'virustotal_attachment_malicious': 28,
}
# DŮLEŽITÉ: abuseipdb_reputation, virustotal_reputation, young_domain a
# virustotal_url_malicious/virustotal_attachment_malicious se počítají jen
# když byl příslušný dotaz skutečně proveden (--abuseipdb / --virustotal /
# --whois, všechno výchozí vypnuto) - jinak by tenhle signál nikdy nemohl
# nastat, a kdyby byl napevno v jmenovateli, žádný e-mail bez enrichmentu
# by nikdy nedosáhl 100 % (stejná chyba, jakou jsem musel opravovat v
# similarity.py). VT na URL/hash má VYŠŠÍ váhu než VT na IP - detekce na
# konkrétní URL/hash je mnohem přesnější signál než reputace celé IP
# (sdílené hostingy, NAT...).
_ENRICHMENT_KEYS = {
    'abuseipdb_reputation', 'virustotal_reputation', 'young_domain',
    'virustotal_url_malicious', 'virustotal_attachment_malicious',
}
BASE_THREAT_MAX = sum(w for k, w in THREAT_WEIGHTS.items() if k not in _ENRICHMENT_KEYS)
ABUSEIPDB_WEIGHT = THREAT_WEIGHTS['abuseipdb_reputation']
VIRUSTOTAL_WEIGHT = THREAT_WEIGHTS['virustotal_reputation']
YOUNG_DOMAIN_WEIGHT = THREAT_WEIGHTS['young_domain']
VT_URL_WEIGHT = THREAT_WEIGHTS['virustotal_url_malicious']
VT_ATTACHMENT_WEIGHT = THREAT_WEIGHTS['virustotal_attachment_malicious']

# Přípony spustitelného/skriptovacího obsahu - samy o sobě podezřelé v příloze e-mailu
EXECUTABLE_EXTENSIONS = {
    '.exe', '.scr', '.bat', '.cmd', '.com', '.js', '.vbs', '.jar',
    '.ps1', '.msi', '.pif', '.hta', '.wsf',
}
# Běžné dokumentové přípony - kombinace dokument+spustitelný (dvojitá přípona)
# je klasický trik pro zamaskování .exe za .pdf ve Windows Exploreru
DOCUMENT_EXTENSIONS = {'.pdf', '.doc', '.docx', '.xls', '.xlsx', '.jpg', '.png', '.zip', '.txt'}


def _attachment_findings(attachments: list) -> list:
    findings = []
    for a in attachments:
        name = (a.get('filename') or '').lower()
        if not name:
            continue
        # dvojitá přípona: "faktura.pdf.exe"
        for doc_ext in DOCUMENT_EXTENSIONS:
            for exe_ext in EXECUTABLE_EXTENSIONS:
                if name.endswith(doc_ext + exe_ext):
                    findings.append(f"Příloha '{a.get('filename')}' má zamaskovanou "
                                     f"dvojitou příponu ({doc_ext}{exe_ext}) - klasický trik pro obejití "
                                     f"vizuální kontroly v souborovém průzkumníku.")
        for exe_ext in EXECUTABLE_EXTENSIONS:
            if name.endswith(exe_ext) and not any(name.endswith(d + exe_ext) for d in DOCUMENT_EXTENSIONS):
                findings.append(f"Příloha '{a.get('filename')}' je přímo spustitelný/skriptovací soubor.")
    return findings


def assess(fp: dict) -> dict:
    """Vezme fingerprint (výstup fingerprint.build_fingerprint) a spočítá
    threat skóre. Nepotřebuje druhý e-mail - pracuje jen s tímhle jedním."""
    breakdown = {}
    weighted_findings = []  # (weight, text) - na konci seřadíme podle váhy sestupně

    auth = fp.get('auth_explained') or {}
    spf = auth.get('SPF', {}).get('verdict')
    if spf in ('fail', 'softfail'):
        w = THREAT_WEIGHTS['spf_fail']
        breakdown['spf_fail'] = w
        weighted_findings.append((w, f"SPF={spf} - odesílající server pravděpodobně není autorizovaný pro tuto doménu."))

    dkim = auth.get('DKIM', {}).get('verdict')
    if dkim == 'fail':
        w = THREAT_WEIGHTS['dkim_fail']
        breakdown['dkim_fail'] = w
        weighted_findings.append((w, "DKIM=fail - digitální podpis e-mailu je neplatný."))

    dmarc = auth.get('DMARC', {}).get('verdict')
    if dmarc == 'fail':
        w = THREAT_WEIGHTS['dmarc_fail']
        breakdown['dmarc_fail'] = w
        weighted_findings.append((w, "DMARC=fail - e-mail nesplňuje ověřovací politiku domény odesílatele."))

    urls = fp.get('urls_detail') or []
    mismatched = [u for u in urls if u.get('mismatch')]
    if mismatched:
        w = THREAT_WEIGHTS['url_mismatch']
        breakdown['url_mismatch'] = w
        weighted_findings.append((w, f"{len(mismatched)}× odkaz, kde zobrazený text neodpovídá skutečnému "
                                      f"cíli (klasický phishing trik)."))

    domains_to_check = set(fp.get('link_domains') or [])
    from_domain = fp.get('from_domain')
    if from_domain:
        domains_to_check.add(from_domain)
    homoglyph_hits = {}
    for d in domains_to_check:
        hits = homoglyph_module.analyze_domain(d)
        if hits:
            homoglyph_hits[d] = hits
    if homoglyph_hits:
        w = THREAT_WEIGHTS['homoglyph_domain']
        breakdown['homoglyph_domain'] = w
        for d, hits in homoglyph_hits.items():
            for hit in hits:
                weighted_findings.append((w, f"Doména '{d}': {hit['detail']}"))

    attachments = fp.get('attachments_detail') or []
    attachment_findings = _attachment_findings(attachments)
    if attachment_findings:
        w = THREAT_WEIGHTS['suspicious_attachment']
        breakdown['suspicious_attachment'] = w
        for text in attachment_findings:
            weighted_findings.append((w, text))

    chain = fp.get('received_chain') or {}
    # Jen "přerušení návaznosti" (silný signál), ne časové prodlevy - ty jsou
    # často neškodné (mail fronta přes víkend, retry po výpadku serveru...).
    continuity_anomalies = [a for a in chain.get('anomalies', []) if a.get('type') == 'broken_link']
    if continuity_anomalies:
        w = THREAT_WEIGHTS['broken_chain']
        breakdown['broken_chain'] = w
        weighted_findings.append((w, "Received řetězec má přerušenou návaznost mezi hopy - "
                                      "možný náznak ručně upravených/vložených hlaviček (spoofing)."))

    html = fp.get('html_fingerprint') or {}
    if html.get('tracking_pixels', 0) > 0:
        w = THREAT_WEIGHTS['tracking_pixel']
        breakdown['tracking_pixel'] = w
        weighted_findings.append((w, f"{html['tracking_pixels']}× tracking pixel (neviditelný 1×1 obrázek) - "
                                      f"sleduje, kdy a odkud e-mail otevřeš."))
    if html.get('hidden_elements', 0) > 0:
        w = THREAT_WEIGHTS['hidden_content']
        breakdown['hidden_content'] = w
        weighted_findings.append((w, f"{html['hidden_elements']}× skrytý HTML prvek (display:none / "
                                      f"visibility:hidden) - často se používá k obelstění spamových filtrů."))
    if html.get('form_count', 0) > 0:
        w = THREAT_WEIGHTS['embedded_form']
        breakdown['embedded_form'] = w
        targets = ', '.join(html.get('form_action_domains') or []) or 'neznámý cíl'
        weighted_findings.append((w, f"{html['form_count']}× formulář přímo v e-mailu (cíl: {targets}) - "
                                      f"legitimní služby o hesla/údaje přes formulář v e-mailu nežádají."))

    # AbuseIPDB (volitelné, jen pokud byl dotaz skutečně proveden - viz --abuseipdb).
    # Prahy jsou záměrně konzervativní (vysoké skóre I dost hlášení současně),
    # protože samotná reputace IP není silný důkaz proti konkrétnímu odesílateli -
    # velcí poskytovatelé (Gmail, M365) mohou mít IP v databázi kvůli zneužití
    # jednotlivých účtů, ne proto, že by celá služba byla nebezpečná.
    abuse = fp.get('abuseipdb')
    abuse_data_available = bool(abuse and abuse.get('available'))
    threat_max = BASE_THREAT_MAX + (ABUSEIPDB_WEIGHT if abuse_data_available else 0)
    if abuse_data_available:
        confidence_score = abuse.get('abuse_confidence_score') or 0
        reports = abuse.get('total_reports') or 0
        if confidence_score >= 50 and reports >= 3:
            w = ABUSEIPDB_WEIGHT
            breakdown['abuseipdb_reputation'] = w
            weighted_findings.append((w,
                f"AbuseIPDB: {confidence_score}% confidence skóre ({reports} hlášení) pro IP "
                f"{fp.get('primary_ip')} - ale pozor, u velkých poskytovatelů samotná reputace IP "
                f"nemusí nic vypovídat o konkrétním odesílateli."
            ))

    # VirusTotal (volitelné, jen pokud byl dotaz skutečně proveden - viz --virustotal).
    # Práh je mírnější než u AbuseIPDB (VT kombinuje víc enginů/zdrojů, takže
    # jednotlivý "malicious" hlas má víc kontextu), ale váha je nižší -
    # žádný jeden externí zdroj nemá dominantní vliv na výsledné skóre.
    vt = fp.get('virustotal')
    vt_data_available = bool(vt and vt.get('available'))
    threat_max += VIRUSTOTAL_WEIGHT if vt_data_available else 0
    if vt_data_available:
        malicious = vt.get('malicious_votes') or 0
        rep_score = vt.get('reputation_score') or 0
        if malicious >= 5 and rep_score >= 10:
            w = VIRUSTOTAL_WEIGHT
            breakdown['virustotal_reputation'] = w
            harmless = vt.get('harmless_votes') or 0
            weighted_findings.append((w,
                f"VirusTotal: {malicious} malicious detekcí z {malicious + harmless} enginů "
                f"({rep_score}%) pro IP {fp.get('primary_ip')} - stojí za ruční ověření na "
                f"virustotal.com pro detail."
            ))

    # Stáří domény (volitelné, jen pokud byl WHOIS dotaz skutečně proveden -
    # viz --whois). Čerstvě zaregistrovaná doména je klasický phishing
    # indikátor (útočník zaregistruje doménu těsně před kampaní), ale NENÍ
    # to jednoznačný důkaz - i legitimní firmy si někdy zakládají nové
    # domény pro kampaně/produkty. Práh 30 dní je záměrně konzervativní.
    whois = fp.get('whois')
    whois_data_available = bool(whois and whois.get('available') and whois.get('domain_age_days') is not None)
    threat_max += YOUNG_DOMAIN_WEIGHT if whois_data_available else 0
    if whois_data_available:
        age_days = whois['domain_age_days']
        if age_days < 30:
            w = YOUNG_DOMAIN_WEIGHT
            breakdown['young_domain'] = w
            weighted_findings.append((w,
                f"Doména odesílatele '{fp.get('from_domain')}' je zaregistrovaná jen "
                f"{age_days} dní - čerstvě založené domény jsou častý phishing indikátor "
                f"(ne jednoznačný důkaz)."
            ))

    # VirusTotal na URL (volitelné, jen pokud byly dotazy provedeny - viz
    # --virustotal). Nižší práh než u IP reputace - detekce na konkrétní
    # URL je mnohem přesnější (nesdílí ji tisíce jiných domén na stejném
    # hostingu jako IP adresa).
    vt_urls = fp.get('virustotal_urls') or []
    malicious_urls = [
        u for u in vt_urls
        if (u.get('result') or {}).get('available') and (u['result'].get('malicious_votes') or 0) >= 3
    ]
    urls_checked = [u for u in vt_urls if (u.get('result') or {}).get('available')]
    if urls_checked:
        threat_max += VT_URL_WEIGHT
    if malicious_urls:
        w = VT_URL_WEIGHT
        breakdown['virustotal_url_malicious'] = w
        for u in malicious_urls:
            weighted_findings.append((w,
                f"VirusTotal: URL '{u['url']}' označena jako malicious "
                f"{u['result']['malicious_votes']} enginy."
            ))

    # VirusTotal na hash příloh (volitelné). Nejsilnější a nejpřesnější
    # dostupný signál - shoda hashe je téměř jistá shoda konkrétního
    # souboru, ne jen podobnosti.
    vt_attachments = fp.get('virustotal_attachments') or []
    malicious_attachments = [
        a for a in vt_attachments
        if (a.get('result') or {}).get('available') and (a['result'].get('malicious_votes') or 0) >= 3
    ]
    attachments_checked = [a for a in vt_attachments if (a.get('result') or {}).get('available')]
    if attachments_checked:
        threat_max += VT_ATTACHMENT_WEIGHT
    if malicious_attachments:
        w = VT_ATTACHMENT_WEIGHT
        breakdown['virustotal_attachment_malicious'] = w
        for a in malicious_attachments:
            weighted_findings.append((w,
                f"VirusTotal: příloha '{a.get('filename')}' označena jako malicious "
                f"{a['result']['malicious_votes']} enginy."
            ))

    total = sum(breakdown.values())
    score_pct = round((total / threat_max) * 100, 1) if threat_max else 0.0

    # Seřadit podle váhy sestupně - nejvýznamnější nález první (explainability).
    weighted_findings.sort(key=lambda wf: wf[0], reverse=True)
    findings = [f"+{w} {text}" for w, text in weighted_findings]

    return {
        'score_pct': score_pct,
        'breakdown': breakdown,
        'findings': findings,
        'verdict': _verdict(score_pct),
    }


def _verdict(score_pct: float) -> str:
    if score_pct >= 60:
        return "VYSOCE RIZIKOVÝ"
    elif score_pct >= 30:
        return "PODEZŘELÝ"
    elif score_pct > 0:
        return "MÍRNÉ INDIKÁTORY"
    else:
        return "ŽÁDNÉ ZNÁMÉ INDIKÁTORY"
