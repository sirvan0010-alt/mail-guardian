"""
exporter.py
JSON export vedle HTML reportu - pro automatizaci, SIEM integraci, nebo
další zpracování mimo MailGuardian. Na rozdíl od HTML reportu (pro člověka)
je tohle strojově čitelný výstup.
"""

import json
from datetime import datetime

from . import ioc as ioc_module


def _email_summary(email: dict) -> dict:
    """Shrnutí jednoho e-mailu pro JSON export - jen JSON-serializovatelná
    pole, žádné vnitřní detaily nepotřebné mimo nástroj."""
    fp = email.get('fingerprint') or {}
    threat = fp.get('threat') or {}
    confidence = fp.get('confidence') or {}
    return {
        'filepath': email.get('filepath'),
        'from': email.get('from_addr'),
        'subject': email.get('subject'),
        'date': email.get('date_header'),
        'file_sha256': fp.get('file_sha256'),
        'threat_score': threat.get('score_pct'),
        'threat_verdict': threat.get('verdict'),
        'threat_findings': threat.get('findings', []),
        'confidence_score': confidence.get('score_pct'),
        'confidence_verdict': confidence.get('verdict'),
        'confidence_missing_data': confidence.get('missing', []),
        'primary_ip': fp.get('primary_ip'),
        'origin_public_ip': fp.get('origin_public_ip'),
        'abuseipdb': fp.get('abuseipdb'),
        'virustotal': fp.get('virustotal'),
        'virustotal_urls': fp.get('virustotal_urls'),
        'virustotal_attachments': fp.get('virustotal_attachments'),
        'whois': fp.get('whois'),
        'dns': fp.get('dns'),
        'dkim_domain': fp.get('dkim_domain'),
        'auth_results': fp.get('auth_results', {}),
        'received_chain_anomalies': (fp.get('received_chain') or {}).get('anomalies', []),
        'iocs': ioc_module.extract_iocs(fp),
    }


def comparison_export(email_a: dict, email_b: dict, result: dict) -> dict:
    """Sestaví JSON-serializovatelný dict pro výsledek 'compare' - identity
    similarity mezi dvěma e-maily + threat skóre a IOC pro každý zvlášť."""
    return {
        'generated_at': datetime.now().isoformat(),
        'tool': 'MailGuardian OSINT',
        'identity_similarity': {
            'score_pct': result['score_pct'],
            'verdict': result['verdict'],
            'breakdown': result['breakdown'],
        },
        'email_a': _email_summary(email_a),
        'email_b': _email_summary(email_b),
    }


def write_json(data: dict, path: str):
    """Deterministický zápis - stejná data vždy vyprodukují bitově stejný
    soubor (seřazené klíče), takže jde JSON hashovat pro integrity manifest."""
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2, sort_keys=True, default=str)
