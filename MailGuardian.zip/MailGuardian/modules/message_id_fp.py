"""
message_id_fp.py
Otisk Message-ID - ne prosté porovnání celého řetězce (to už dělá
parser.get_message_id_pattern), ale rozbor VLASTNOSTÍ: délka, entropie,
orientační rozpoznání generátoru (Postfix, Exim, Exchange, Gmail...).

Různé MTA a knihovny generují Message-ID velmi charakteristickým způsobem,
takže shoda ve "stylu" (ne v konkrétní hodnotě) je užitečný signál -
podobně jako u MIME boundary stylů.
"""

import math
import re

GENERATOR_PATTERNS = [
    (re.compile(r'^CA[\w+/\-]{15,}$'), 'Gmail (Google)'),
    (re.compile(r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$'), 'UUID-based'),
    (re.compile(r'^[\w.]{6}-[\w.]{6}-\w{2}$'), 'Exim'),
    (re.compile(r'[A-Z]{2}\d{1,2}PR\d{2,4}MB\d+', re.IGNORECASE), 'Microsoft Exchange/Outlook'),
    (re.compile(r'^\d{14}\.[0-9A-Fa-f]{6,}$'), 'Postfix (timestamp.hash)'),
    (re.compile(r'^\d{10,13}\.\d+\.\d+$'), 'Python email.utils.make_msgid'),
    (re.compile(r'^[0-9A-Fa-f]{32}$'), 'MD5-style hash'),
    (re.compile(r'^[0-9A-Fa-f]{40}$'), 'SHA1-style hash'),
]


def _shannon_entropy(s: str) -> float:
    """Shannonova entropie v bitech/znak - vyšší = náhodnější řetězec."""
    if not s:
        return 0.0
    freq = {}
    for ch in s:
        freq[ch] = freq.get(ch, 0) + 1
    length = len(s)
    entropy = 0.0
    for count in freq.values():
        p = count / length
        entropy -= p * math.log2(p)
    return round(entropy, 3)


def _classify_generator(local_part: str) -> str:
    for pattern, label in GENERATOR_PATTERNS:
        if pattern.search(local_part):
            return label
    return 'neznámý/vlastní formát'


def _has_timestamp_like_number(local_part: str) -> bool:
    """Hledá dlouhé číselné sekvence, které by mohly být unix timestamp
    (10-13 číslic = rozsah přibližně 2001-2286 resp. milisekundy)."""
    return bool(re.search(r'\b\d{10,13}\b', local_part))


def build_message_id_fingerprint(message_id: str) -> dict:
    """Vrátí rozbor vlastností Message-ID (ne jeho konkrétní hodnotu)."""
    if not message_id:
        return {
            'present': False, 'length': 0, 'entropy': 0.0,
            'domain': None, 'generator_guess': None, 'has_timestamp_like_number': False,
        }

    # Message-ID bývá ve formátu <local@domain> - odstraníme lomené závorky
    cleaned = message_id.strip().lstrip('<').rstrip('>')
    if '@' in cleaned:
        local_part, domain = cleaned.split('@', 1)
    else:
        local_part, domain = cleaned, None

    return {
        'present': True,
        'length': len(cleaned),
        'entropy': _shannon_entropy(local_part),
        'domain': domain,
        'generator_guess': _classify_generator(local_part),
        'has_timestamp_like_number': _has_timestamp_like_number(local_part),
    }
