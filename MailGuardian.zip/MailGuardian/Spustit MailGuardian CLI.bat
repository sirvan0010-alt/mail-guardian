@echo off
cd /d "%~dp0"

if not exist venv\Scripts\activate.bat (
    echo [!] Virtualni prostredi nenalezeno.
    echo     Spust nejdriv "install.bat" v teto slozce.
    pause
    exit /b 1
)

call venv\Scripts\activate.bat
echo Venv aktivovano. Priklady prikazu:
echo   python main.py add emails\muj_email.eml
echo   python main.py list
echo   python main.py case create moje_vysetrovani
echo.
cmd /k
