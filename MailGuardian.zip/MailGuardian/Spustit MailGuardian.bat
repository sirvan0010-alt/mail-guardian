@echo off
cd /d "%~dp0"

if not exist venv\Scripts\streamlit.exe (
    echo [!] Virtualni prostredi nenalezeno nebo neni kompletni.
    echo     Spust nejdriv "install.bat" v teto slozce.
    pause
    exit /b 1
)

echo Spoustim MailGuardian GUI...
echo (Prohlizec se otevre automaticky - toto okno nezavirej, dokud GUI pouzivas.)
echo.

call venv\Scripts\activate.bat
streamlit run app.py
