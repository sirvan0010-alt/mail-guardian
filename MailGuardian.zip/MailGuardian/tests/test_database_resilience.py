"""
test_database_resilience.py
Odolnost proti poškozené databázi - `fingerprint_json` sloupec může
teoreticky obsahovat cokoliv (ruční zásah, bitová chyba na disku,
útočník s přístupem k souboru databáze). similarity.compare()/
threat.assess()/atd. bezpodmínečně předpokládají dict - bez validace
u zdroje (database.py) by se sem dostal ne-dict JSON (list/číslo) nebo
by rovnou spadlo dekódování, a pád by nastal matoucím způsobem hluboko
ve scoringu, ne s jasnou příčinou tady.
"""

import tempfile

from modules import database, similarity


def _make_conn():
    return database.connect(tempfile.mktemp(suffix='.db'))


def _insert_raw(conn, filepath: str, fingerprint_json: str):
    conn.execute(
        '''INSERT INTO emails (filepath, from_addr, subject, date_header, file_sha256, fingerprint_json, added_at)
           VALUES (?, ?, ?, ?, ?, ?, ?)''',
        (filepath, 'a@b.com', 'test', 'Mon, 06 Jul 2026 10:00:00 +0200', 'sha_' + filepath, fingerprint_json,
         '2026-01-01T00:00:00')
    )
    conn.commit()


def test_get_all_emails_survives_non_dict_fingerprint_json():
    conn = _make_conn()
    _insert_raw(conn, 'list_fp.eml', '[1, 2, 3]')
    _insert_raw(conn, 'number_fp.eml', '42')
    _insert_raw(conn, 'null_fp.eml', 'null')
    _insert_raw(conn, 'string_fp.eml', '"just a string"')

    emails = database.get_all_emails(conn)
    assert len(emails) == 4
    for e in emails:
        assert e['fingerprint'] == {}  # poškozené -> prázdný dict, ne pád, ne ne-dict typ


def test_get_all_emails_survives_truncated_json():
    conn = _make_conn()
    _insert_raw(conn, 'truncated.eml', '{"threat": {"score_pct": 5')  # useknuté uprostřed
    _insert_raw(conn, 'garbage.eml', 'not json at all {{{')

    emails = database.get_all_emails(conn)
    assert len(emails) == 2
    for e in emails:
        assert e['fingerprint'] == {}


def test_get_email_single_lookup_survives_corruption():
    conn = _make_conn()
    _insert_raw(conn, 'corrupted.eml', '[]')
    row = conn.execute('SELECT id FROM emails WHERE filepath = ?', ('corrupted.eml',)).fetchone()

    result = database.get_email(conn, row[0])
    assert result['fingerprint'] == {}


def test_corrupted_fingerprint_still_usable_in_similarity_compare():
    """End-to-end - poškozený záznam se musí dát dál použít v porovnávání
    (např. case suggest/case compare projde celou databázi), ne shodit
    celý běh na jednom špatném řádku."""
    conn = _make_conn()
    _insert_raw(conn, 'corrupted.eml', '[1,2,3]')
    _insert_raw(conn, 'truncated.eml', '{not valid')

    emails = database.get_all_emails(conn)
    result = similarity.compare(emails[0]['fingerprint'], emails[1]['fingerprint'])
    assert result['score_pct'] == 0.0


def test_valid_fingerprint_json_unaffected_by_validation():
    """Regresní pojistka - validace nesmí rozbít normální, validní data."""
    conn = _make_conn()
    _insert_raw(conn, 'valid.eml', '{"primary_ip": "1.2.3.4", "threat": {"score_pct": 42.0}}')

    emails = database.get_all_emails(conn)
    assert emails[0]['fingerprint']['primary_ip'] == '1.2.3.4'
    assert emails[0]['fingerprint']['threat']['score_pct'] == 42.0
