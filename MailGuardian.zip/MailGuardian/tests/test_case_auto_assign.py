"""
test_case_auto_assign.py
Automatické přiřazení nového e-mailu do Case podle Identity Similarity -
tři scénáře podle rozhodnutí v README v0.17: žádná shoda -> nový case,
jedna shoda -> přiřadit tam, víc shod -> jen navrhnout, nerozhodovat sám.
"""

import os
import shutil

import pytest
from conftest import eml_path

from modules import case as case_module
from modules import database
from modules import parser, fingerprint as fp_module


@pytest.fixture
def case_env(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(case_module, 'CASES_ROOT', str(tmp_path / 'cases'))
    return tmp_path


def _seed_case(case_name: str, fixture_filename: str):
    """Založí case a vloží do něj jeden fixture e-mail (přímo, bez CLI)."""
    case_module.create_case(case_name)
    conn = database.connect(case_module.case_db_path(case_name))
    originals = case_module.case_originals_dir(case_name)
    dest = os.path.join(originals, fixture_filename)
    shutil.copy2(eml_path(fixture_filename), dest)
    parsed = parser.parse_eml(dest)
    fp = fp_module.build_fingerprint(parsed, enable_geoip=False)
    database.store_email(conn, parsed, fp)
    return fp


def _make_variant(base_filename: str, tmp_path, replacements: dict) -> str:
    """Vytvoří variantu fixture e-mailu s pozměněným obsahem (simulace
    'druhé vlny' kampaně - stejná infrastruktura, jiný obsah)."""
    with open(eml_path(base_filename)) as f:
        content = f.read()
    for old, new in replacements.items():
        content = content.replace(old, new)
    out_path = tmp_path / 'variant.eml'
    out_path.write_text(content)
    return str(out_path)


def test_generate_auto_case_name_uses_date_and_hash():
    name = case_module.generate_auto_case_name('Mon, 06 Jul 2026 10:00:00 +0200', 'a1b2c3d4' * 8)
    assert name == 'auto_20260706_a1b2c3d4'


def test_generate_auto_case_name_handles_missing_date():
    name = case_module.generate_auto_case_name(None, 'deadbeef' * 8)
    assert name.startswith('auto_unknown_')


def test_no_match_when_no_cases_exist(case_env):
    fp = fp_module.build_fingerprint(parser.parse_eml(eml_path('gmail_clean.eml')), enable_geoip=False)
    assert case_module.find_matching_cases(fp) == []


def test_no_match_for_unrelated_email(case_env):
    _seed_case('phishing_wave', 'spoofed_phishing.eml')
    fp = fp_module.build_fingerprint(parser.parse_eml(eml_path('gmail_clean.eml')), enable_geoip=False)
    assert case_module.find_matching_cases(fp, threshold=30.0) == []


def test_single_match_identifies_correct_case(case_env, tmp_path):
    _seed_case('phishing_wave', 'spoofed_phishing.eml')
    _seed_case('newsletters', 'postfix_newsletter.eml')

    variant_path = _make_variant(
        'spoofed_phishing.eml', tmp_path,
        {'phish1.1720000000@mail.evil-infra.ru': 'phish2.1720100000@mail.evil-infra.ru'}
    )
    fp = fp_module.build_fingerprint(parser.parse_eml(variant_path), enable_geoip=False)
    matches = case_module.find_matching_cases(fp, threshold=30.0)

    assert len(matches) == 1
    assert matches[0]['case_name'] == 'phishing_wave'
    assert matches[0]['best_score'] > 0


def test_multiple_matches_returns_all_ranked_candidates(case_env, tmp_path):
    """Dva case se stejnou/podobnou infrastrukturou - nový mail by měl
    najít OBA, seřazené podle skóre, ne si sám vybrat jeden."""
    _seed_case('case_a', 'spoofed_phishing.eml')

    variant1 = _make_variant(
        'spoofed_phishing.eml', tmp_path,
        {'phish1.1720000000@mail.evil-infra.ru': 'phish3.1720200000@mail.evil-infra.ru'}
    )
    case_module.create_case('case_b')
    conn_b = database.connect(case_module.case_db_path('case_b'))
    dest_b = os.path.join(case_module.case_originals_dir('case_b'), 'variant1.eml')
    shutil.copy2(variant1, dest_b)
    parsed_b = parser.parse_eml(dest_b)
    fp_b = fp_module.build_fingerprint(parsed_b, enable_geoip=False)
    database.store_email(conn_b, parsed_b, fp_b)

    variant2 = _make_variant(
        'spoofed_phishing.eml', tmp_path,
        {'phish1.1720000000@mail.evil-infra.ru': 'phish4.1720300000@mail.evil-infra.ru'}
    )
    fp_new = fp_module.build_fingerprint(parser.parse_eml(variant2), enable_geoip=False)
    matches = case_module.find_matching_cases(fp_new, threshold=30.0)

    assert len(matches) == 2
    case_names = {m['case_name'] for m in matches}
    assert case_names == {'case_a', 'case_b'}
    # seřazené sestupně podle skóre
    assert matches[0]['best_score'] >= matches[1]['best_score']


def test_candidates_include_top_signals_for_explainability(case_env, tmp_path):
    _seed_case('phishing_wave', 'spoofed_phishing.eml')
    variant_path = _make_variant(
        'spoofed_phishing.eml', tmp_path,
        {'phish1.1720000000@mail.evil-infra.ru': 'phish2.1720100000@mail.evil-infra.ru'}
    )
    fp = fp_module.build_fingerprint(parser.parse_eml(variant_path), enable_geoip=False)
    matches = case_module.find_matching_cases(fp, threshold=30.0)

    assert len(matches[0]['top_signals']) > 0
    for signal_name, weight in matches[0]['top_signals']:
        assert isinstance(signal_name, str)
        assert weight > 0


def test_find_matching_cases_skips_empty_case(case_env):
    """Case bez e-mailů (např. právě založený) by neměl spadnout ani se
    objevit jako kandidát."""
    case_module.create_case('empty_case')
    fp = fp_module.build_fingerprint(parser.parse_eml(eml_path('gmail_clean.eml')), enable_geoip=False)
    matches = case_module.find_matching_cases(fp, threshold=0.0)  # i práh 0 by ho nemel najit
    assert 'empty_case' not in {m['case_name'] for m in matches}


# --- Dvouúrovňový práh (suggest vs. auto-assign-confirm) a bohatší API ---

def test_suggest_cases_includes_shared_iocs_and_email_count(case_env, tmp_path):
    _seed_case('phishing_wave', 'spoofed_phishing.eml')
    variant_path = _make_variant(
        'spoofed_phishing.eml', tmp_path,
        {'phish1.1720000000@mail.evil-infra.ru': 'phish2.1720100000@mail.evil-infra.ru'}
    )
    fp = fp_module.build_fingerprint(parser.parse_eml(variant_path), enable_geoip=False)
    candidates = case_module.suggest_cases_for_fingerprint(fp, suggest_threshold=30.0)

    assert len(candidates) == 1
    c = candidates[0]
    assert c['email_count'] == 1
    assert c['best_match_file'] == c['matched_filepath']
    assert '45.33.12.10' in c['shared_ips']
    assert isinstance(c['strong_signal_hit'], bool)


def test_should_auto_assign_true_above_confirm_threshold():
    candidate = {'best_score': 65.0, 'strong_signal_hit': False}
    assert case_module.should_auto_assign(candidate) is True


def test_should_auto_assign_false_below_confirm_threshold_without_strong_signal():
    candidate = {'best_score': 46.5, 'strong_signal_hit': False}
    assert case_module.should_auto_assign(candidate) is False


def test_should_auto_assign_true_with_strong_signal_even_at_low_score():
    """Identická příloha (strong_signal_hit) přebije nízké celkové skóre -
    stejná logika jako 'SILNÝ JEDNOTLIVÝ NÁLEZ' verdikt v similarity.py."""
    candidate = {'best_score': 15.0, 'strong_signal_hit': True}
    assert case_module.should_auto_assign(candidate) is True


def test_find_matching_cases_backward_compatible_shape(case_env, tmp_path):
    """Starší/jednodušší tvar dat (bez shared_domains apod.) musí zůstat
    funkční pro kód, co ho ještě používá."""
    _seed_case('phishing_wave', 'spoofed_phishing.eml')
    variant_path = _make_variant(
        'spoofed_phishing.eml', tmp_path,
        {'phish1.1720000000@mail.evil-infra.ru': 'phish2.1720100000@mail.evil-infra.ru'}
    )
    fp = fp_module.build_fingerprint(parser.parse_eml(variant_path), enable_geoip=False)
    matches = case_module.find_matching_cases(fp, threshold=30.0)

    assert len(matches) == 1
    expected_keys = {'case_name', 'best_score', 'verdict', 'matched_filepath', 'top_signals'}
    assert set(matches[0].keys()) == expected_keys
