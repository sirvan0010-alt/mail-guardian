"""
test_case.py
Case mode end-to-end - create/add/compare/report/graph v izolovaném
dočasném adresáři (pytest tmp_path), ať testy nezasahují do skutečné
cases/ složky projektu.
"""

import os

import pytest
from conftest import eml_path

from modules import case as case_module
from modules import database
from modules import similarity
from modules import ioc as ioc_module


@pytest.fixture
def case_env(tmp_path, monkeypatch):
    """Přesměruje CASES_ROOT do dočasného adresáře pro izolaci testů."""
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(case_module, 'CASES_ROOT', str(tmp_path / 'cases'))
    return tmp_path


def _add_fixture(conn, filename, originals_dir):
    import shutil
    from main import _process_file
    src = eml_path(filename)
    dest = os.path.join(originals_dir, filename)
    shutil.copy2(src, dest)
    return _process_file(conn, dest)


def test_create_case_makes_expected_structure(case_env):
    d = case_module.create_case('test1')
    assert os.path.isdir(os.path.join(d, 'original'))
    assert os.path.isdir(os.path.join(d, 'reports'))
    assert case_module.case_exists('test1')


def test_create_case_idempotent(case_env):
    case_module.create_case('test1')
    case_module.create_case('test1')  # nemělo by spadnout ani nic přepsat
    assert case_module.case_exists('test1')


def test_list_cases_empty_and_populated(case_env):
    assert case_module.list_cases() == []
    case_module.create_case('alpha')
    case_module.create_case('beta')
    assert case_module.list_cases() == ['alpha', 'beta']


def test_add_and_compare_within_case(case_env):
    case_module.create_case('campaign')
    conn = database.connect(case_module.case_db_path('campaign'))
    originals = case_module.case_originals_dir('campaign')

    id_a, fp_a, _ = _add_fixture(conn, 'gmail_clean.eml', originals)
    id_b, fp_b, _ = _add_fixture(conn, 'exchange_clean.eml', originals)

    emails = database.get_all_emails(conn)
    assert len(emails) == 2

    result = similarity.compare(fp_a, fp_b)
    database.store_comparison(conn, id_a, id_b, result)
    comparisons = database.get_all_comparisons(conn)
    assert len(comparisons) == 1


def test_re_add_same_file_does_not_duplicate(case_env):
    case_module.create_case('dedup_test')
    conn = database.connect(case_module.case_db_path('dedup_test'))
    originals = case_module.case_originals_dir('dedup_test')

    _add_fixture(conn, 'gmail_clean.eml', originals)
    _add_fixture(conn, 'gmail_clean.eml', originals)  # znovu, stejný obsah

    emails = database.get_all_emails(conn)
    assert len(emails) == 1


def test_timeline_chronological_order_with_missing_date():
    emails = [
        {'filepath': 'c.eml', 'date_header': None, 'fingerprint': {}},
        {'filepath': 'a.eml', 'date_header': 'Mon, 06 Jul 2026 10:00:00 +0200', 'fingerprint': {}},
        {'filepath': 'b.eml', 'date_header': 'invalid garbage', 'fingerprint': {}},
        {'filepath': 'd.eml', 'date_header': 'Wed, 08 Jul 2026 09:00:00 +0200', 'fingerprint': {}},
    ]
    timeline = case_module.build_timeline(emails)
    filepaths = [t['filepath'] for t in timeline]
    assert filepaths[0] == 'a.eml'
    assert filepaths[1] == 'd.eml'
    # b.eml a c.eml (nevalidní/chybějící datum) jdou na konec, v libovolném pořadí mezi sebou
    assert set(filepaths[2:]) == {'b.eml', 'c.eml'}


def test_graph_summary_clusters_transitively_connected():
    emails = [{'id': i, 'filepath': f'{i}.eml', 'fingerprint': {}} for i in (1, 2, 3, 4)]
    comparisons = [
        {'email_a_id': 1, 'email_b_id': 2, 'score_pct': 48.4, 'breakdown': {}},
        {'email_a_id': 1, 'email_b_id': 3, 'score_pct': 0.0, 'breakdown': {}},
        {'email_a_id': 2, 'email_b_id': 4, 'score_pct': 55.0, 'breakdown': {}},
        {'email_a_id': 3, 'email_b_id': 4, 'score_pct': 5.0, 'breakdown': {}},
    ]
    summary = case_module.graph_summary(emails, comparisons, threshold=30.0)
    assert summary['cluster_count'] == 2
    assert summary['largest_cluster_size'] == 3


def test_build_relationship_graph_produces_valid_dot_syntax(tmp_path):
    """Ověří, že vygenerovaný DOT text je syntakticky validní - pokud je
    graphviz `dot` binárka dostupná, spustí ji přímo; jinak testuje jen
    strukturu (přítomnost graph/uzlů/hran)."""
    import shutil
    import subprocess

    emails = [
        {'id': 1, 'filepath': 'a.eml', 'fingerprint': {'threat': {'score_pct': 65}}},
        {'id': 2, 'filepath': 'weird"name.eml', 'fingerprint': {'threat': {'score_pct': 10}}},
    ]
    comparisons = [{'email_a_id': 1, 'email_b_id': 2, 'score_pct': 48.4,
                     'breakdown': {'primary_ip': 35}}]
    dot_text = case_module.build_relationship_graph(emails, comparisons, threshold=30.0)

    assert dot_text.startswith('graph MailGuardianCase {')
    assert 'n1 -- n2' in dot_text

    if shutil.which('dot'):
        dot_file = tmp_path / 'g.dot'
        dot_file.write_text(dot_text)
        result = subprocess.run(['dot', '-Tsvg', str(dot_file)], capture_output=True, timeout=10)
        assert result.returncode == 0, result.stderr.decode()


def test_case_iocs_combine_across_emails(case_env):
    case_module.create_case('ioc_test')
    conn = database.connect(case_module.case_db_path('ioc_test'))
    originals = case_module.case_originals_dir('ioc_test')
    _, fp_a, _ = _add_fixture(conn, 'gmail_clean.eml', originals)
    _, fp_b, _ = _add_fixture(conn, 'spoofed_phishing.eml', originals)

    combined_ips = set(ioc_module.extract_iocs(fp_a)['ips']) | set(ioc_module.extract_iocs(fp_b)['ips'])
    assert '45.33.12.10' in combined_ips or '209.85.161.41' in combined_ips
