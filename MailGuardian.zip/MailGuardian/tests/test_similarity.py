"""
test_similarity.py
Identity Similarity scoring. Klíčový regresní test je brute-force strop
100% - tahle třída chyby (naivní součet vah u vzájemně se vylučujících
signálů) se v projektu už jednou stala (viz README changelog v0.1.2) a
znovu u AbuseIPDB (v0.10) - tenhle test má zaručit, že se nevrátí potřetí.
"""

from itertools import product

from conftest import build_fp
from modules import similarity


def test_ceiling_never_exceeds_100_percent_bruteforce():
    """Vyzkouší stovky kombinací nezávislých/vylučujících se signálů a
    ověří, že skóre nikdy nepřekročí 100 % a v nejlepším případě ho
    přesně dosáhne."""
    max_seen = 0
    combos = 0
    for (primary_match, dkim_match, xs_match, ua_match, mid_match,
         dom_match, geo_match, link_match, att_match, mime_match, midgen_match) in product(
            [True, False], ['key', 'domain', None], [True, False], [True, False],
            [True, False], [True, False], [True, False], [True, False],
            [True, False], [True, False], [True, False]):
        fp_a = {
            'primary_ip': '1.1.1.1', 'all_ips': ['1.1.1.1'],
            'dkim_key': 'sel@dom.com' if dkim_match == 'key' else ('sel1@dom.com' if dkim_match == 'domain' else None),
            'dkim_domain': 'dom.com' if dkim_match in ('key', 'domain') else None,
            'x_sender_ip': '2.2.2.2' if xs_match else None,
            'user_agent': 'UA1' if ua_match else None,
            'message_id_pattern': 'PAT1' if mid_match else None,
            'from_domain': 'weirddomain.com' if dom_match else None,
            'geo': {'available': True, 'asn': 'AS123'} if geo_match else None,
            'link_domains': ['weird-phish-domain.ru'] if link_match else [],
            'attachment_hashes': ['deadbeef' * 8] if att_match else [],
            'mime_fingerprint': {'structure': 'multipart/mixed(text/plain,application/pdf)',
                                  'boundary_style': 'python-email'} if mime_match else
                                 {'structure': 'text/plain', 'boundary_style': 'x'},
            'message_id_fingerprint': {'generator_guess': 'Gmail (Google)'} if midgen_match else
                                       {'generator_guess': 'neznámý/vlastní formát'},
        }
        fp_b = dict(fp_a)
        fp_b['primary_ip'] = '1.1.1.1' if primary_match else '9.9.9.9'
        fp_b['all_ips'] = ['1.1.1.1'] if primary_match else ['9.9.9.9']
        if dkim_match == 'key':
            fp_b['dkim_key'] = 'sel@dom.com'
            fp_b['dkim_domain'] = 'dom.com'
        elif dkim_match == 'domain':
            fp_b['dkim_key'] = 'sel2@dom.com'
            fp_b['dkim_domain'] = 'dom.com'

        result = similarity.compare(fp_a, fp_b)
        combos += 1
        max_seen = max(max_seen, result['score_pct'])
        assert result['score_pct'] <= 100.0, f"Skóre přesáhlo 100%: {result['score_pct']}"

    assert combos > 1000
    assert max_seen == 100.0


def test_unrelated_emails_score_zero():
    fp_a = build_fp('gmail_clean.eml')
    fp_b = build_fp('postfix_newsletter.eml')
    result = similarity.compare(fp_a, fp_b)
    assert result['score_pct'] == 0.0


def test_identical_infrastructure_scores_high():
    """Dva fingerprinty se shodnou IP a DKIM by měly dostat vysoké skóre,
    i když se liší v jiných polích."""
    fp_a = {
        'primary_ip': '45.33.10.1', 'all_ips': ['45.33.10.1'],
        'dkim_key': 'sel@evil.com', 'dkim_domain': 'evil.com',
        'user_agent': 'CustomMailer/1.0', 'message_id_pattern': 'SHAPE1',
        'from_domain': 'wave1.com',
    }
    fp_b = dict(fp_a)
    fp_b['from_domain'] = 'wave2.com'  # jiná doména odesílatele, zbytek infra stejný
    result = similarity.compare(fp_a, fp_b)
    assert result['score_pct'] >= 50.0
    assert result['verdict'] in ('MOŽNÉ STEJNÝ ODESÍLATEL', 'ČÁSTEČNÁ SHODA - stojí za prověření')


def test_attachment_hash_match_flags_even_with_low_total_score():
    """Identická příloha malwaru mezi jinak nesouvisejícími e-maily musí
    vždy vyvolat verdikt 'silný jednotlivý nález', i když je celkové
    skóre nízké."""
    fp_a = {'primary_ip': '1.1.1.1', 'all_ips': ['1.1.1.1'], 'attachment_hashes': ['samehash' * 8]}
    fp_b = {'primary_ip': '9.9.9.9', 'all_ips': ['9.9.9.9'], 'attachment_hashes': ['samehash' * 8]}
    result = similarity.compare(fp_a, fp_b)
    assert result['score_pct'] < 30.0
    assert 'SILNÝ JEDNOTLIVÝ NÁLEZ' in result['verdict']
