"""
test_evidence_and_ioc.py
Evidence mode (deterministický JSON, integrity manifest) a IOC extrakce.
"""

import hashlib
import json

from conftest import build_fp
from modules import evidence, ioc as ioc_module


def test_json_export_is_deterministic():
    """Stejný fingerprint musí dát bitově identický JSON export napříč
    voláními (sort_keys=True) - jinak nejde hashovat jako důkaz integrity."""
    fp1 = build_fp('gmail_clean.eml')
    fp2 = build_fp('gmail_clean.eml')
    j1 = json.dumps(fp1, sort_keys=True, default=str)
    j2 = json.dumps(fp2, sort_keys=True, default=str)
    assert j1 == j2


def test_manifest_hash_matches_actual_file_content(tmp_path):
    test_file = tmp_path / 'sample.txt'
    test_file.write_text('hello world')
    manifest = evidence.build_manifest({'sample': str(test_file)})

    actual_hash = hashlib.sha256(b'hello world').hexdigest()
    assert manifest['sample_sha256'] == actual_hash


def test_manifest_includes_tool_version_and_metadata(tmp_path):
    test_file = tmp_path / 'x.txt'
    test_file.write_text('x')
    manifest = evidence.build_manifest({'x': str(test_file)})
    assert manifest['tool'] == evidence.TOOL_NAME
    assert manifest['tool_version'] == evidence.TOOL_VERSION
    assert manifest['fingerprint_version'] == evidence.FINGERPRINT_VERSION
    assert 'analysis_time_utc' in manifest


def test_manifest_handles_missing_file_gracefully(tmp_path):
    manifest = evidence.build_manifest({'missing': str(tmp_path / 'does-not-exist.txt')})
    assert manifest['missing_sha256'] is None


def test_canonical_json_write_is_sorted_and_reloadable(tmp_path):
    data = {'z': 1, 'a': 2, 'nested': {'y': 1, 'x': 2}}
    out_path = tmp_path / 'out.json'
    evidence.write_canonical_json(data, str(out_path))
    with open(out_path) as f:
        content = f.read()
    # klíče serializované v abecedním pořadí
    assert content.index('"a"') < content.index('"z"')
    reloaded = json.loads(content)
    assert reloaded == data


# --- IOC extraction ---

def test_ioc_extraction_pulls_ip_domain_email():
    fp = build_fp('spoofed_phishing.eml')
    iocs = ioc_module.extract_iocs(fp)
    assert '45.33.12.10' in iocs['ips']
    assert 'paypai-verify.com' in iocs['domains']  # domain_of() záměrně lowercase
    assert 'security@paypaI-verify.com' in iocs['emails']  # e-mail adresa se nemění


def test_ioc_extraction_pulls_attachment_hash():
    fp = build_fp('malware_attachment.eml')
    iocs = ioc_module.extract_iocs(fp)
    assert len(iocs['attachment_sha256']) == 1
    assert len(iocs['attachment_sha256'][0]) == 64


def test_ioc_extraction_no_crash_on_minimal_email():
    fp = build_fp('minimal_bare.eml')
    iocs = ioc_module.extract_iocs(fp)
    assert isinstance(iocs['ips'], list)
    assert isinstance(iocs['domains'], list)


def test_ioc_categories_are_sorted_and_deduplicated():
    fp = build_fp('spoofed_phishing.eml')
    iocs = ioc_module.extract_iocs(fp)
    for category in iocs.values():
        assert category == sorted(set(category))
