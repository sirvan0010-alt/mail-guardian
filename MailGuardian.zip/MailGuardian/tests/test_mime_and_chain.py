"""
test_mime_and_chain.py
MIME struktura (generátor rozpoznání) a Received chain analyzer (hop
rozbor, klasifikace IP, kontrola návaznosti řetězce).
"""

from email import message_from_bytes, policy
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication

from modules import mime_fp, received_chain


def _make_msg():
    msg = MIMEMultipart('mixed')
    msg['From'] = 'a@b.com'
    alt = MIMEMultipart('alternative')
    alt.attach(MIMEText('plain', 'plain'))
    alt.attach(MIMEText('<html>html</html>', 'html'))
    msg.attach(alt)
    att = MIMEApplication(b'x' * 20, Name='file.pdf')
    att['Content-Disposition'] = 'attachment; filename="file.pdf"'
    msg.attach(att)
    return message_from_bytes(msg.as_bytes(), policy=policy.default)


def test_mime_structure_shape_nested_correctly():
    result = mime_fp.build_mime_fingerprint(_make_msg())
    assert result['structure'] == 'multipart/mixed(multipart/alternative(text/plain,text/html),application/octet-stream)'


def test_mime_boundary_style_recognizes_python_stdlib():
    result = mime_fp.build_mime_fingerprint(_make_msg())
    assert result['boundary_style'] == 'python-email (Python stdlib)'


def test_mime_single_part_has_no_boundary():
    from email.mime.text import MIMEText as MT
    msg = message_from_bytes(MT('hello', 'plain').as_bytes(), policy=policy.default)
    result = mime_fp.build_mime_fingerprint(msg)
    assert result['boundary_style'] == 'žádný (single-part zpráva)'


def test_structure_shape_depth_guard_truncates_instead_of_recursion_error():
    """Regresní test na MAX_MIME_DEPTH v mime_fp.py (viz README v0.21
    changelog) - bez hloubkového limitu by extrémně hluboce vnořený
    multipart vedl k RecursionError. Tohle testuje _structure_shape()
    přímo (ne přes celý parser.parse_eml() - to testuje
    tests/test_parser_fuzz.py na skutečné hranici, kde selže samotné
    stdlib parsování, ne naše funkce)."""
    # umělý hluboce vnořený strom BEZ nutnosti stavět skutečný .eml -
    # postačí objekt s .is_multipart()/.iter_parts()/.get_content_type()
    class FakeDeepPart:
        def __init__(self, depth):
            self.depth = depth

        def is_multipart(self):
            return self.depth > 0

        def get_content_type(self):
            return 'multipart/mixed' if self.depth > 0 else 'text/plain'

        def iter_parts(self):
            return [FakeDeepPart(self.depth - 1)]

    deep = FakeDeepPart(mime_fp.MAX_MIME_DEPTH + 20)
    result = mime_fp._structure_shape(deep)  # nesmí spadnout na RecursionError
    assert 'oříznuto' in result


# --- Received chain ---

CLEAN_CHAIN = [
    'from mx.google.com (mx.google.com [64.233.160.1]) by mail.example.cz with ESMTPS id abc; Mon, 06 Jul 2026 10:15:30 +0200',
    'from relay1.example.net (relay1.example.net [91.100.20.5]) by mx.google.com with ESMTPS id def; Mon, 06 Jul 2026 10:15:00 +0200',
    'from originhost.attacker.ru (originhost.attacker.ru [45.33.12.10]) by relay1.example.net with ESMTP id ghi; Mon, 06 Jul 2026 10:14:00 +0200',
]

BROKEN_CHAIN = [
    'from legit-server.trusted.com (legit-server.trusted.com [8.8.8.8]) by mail.example.cz with ESMTPS id abc; Mon, 06 Jul 2026 10:15:30 +0200',
    'from totally-unrelated-host.evil.ru (totally-unrelated-host.evil.ru [45.33.12.10]) by some-other-server-not-mentioned.com with ESMTP id ghi; Mon, 06 Jul 2026 09:00:00 +0200',
]


def test_clean_chain_has_no_anomalies():
    result = received_chain.analyze_chain(CLEAN_CHAIN)
    assert result['anomalies'] == []
    assert result['hop_count'] == 3


def test_clean_chain_origin_ip_is_deepest_hop():
    result = received_chain.analyze_chain(CLEAN_CHAIN)
    assert result['origin_public_ip'] == '45.33.12.10'
    assert result['first_public_ip'] == '64.233.160.1'


def test_broken_chain_detects_link_anomaly():
    result = received_chain.analyze_chain(BROKEN_CHAIN)
    types = {a['type'] for a in result['anomalies']}
    assert 'broken_link' in types


def test_broken_chain_detects_time_gap():
    result = received_chain.analyze_chain(BROKEN_CHAIN)
    types = {a['type'] for a in result['anomalies']}
    assert 'time_gap' in types


def test_known_relay_recognized():
    result = received_chain.analyze_chain(CLEAN_CHAIN)
    assert 'Google / Gmail' in result['known_relays_seen']


def test_empty_chain_does_not_crash():
    result = received_chain.analyze_chain([])
    assert result['hop_count'] == 0
    assert result['anomalies'] == []
    assert result['origin_public_ip'] is None


def test_mixed_naive_and_aware_timestamps_does_not_crash():
    """Regresní test na bug nalezený mutation-based fuzzingem
    (tests/test_parser_fuzz.py) - '-0000' v Received hlavičce (RFC 2822
    'neznámý offset', používá se v divočině u poškozených/spamových
    generátorů) dá naive datetime, zatímco běžný '+0200' dá aware.
    Odečet dvou takových časů dřív vyhazoval TypeError, který `except
    ValueError:` nezachytávalo - oprava přidala TypeError do except."""
    chain = [
        'from a.example.com (a.example.com [1.1.1.1]) by mx.example.com with ESMTP id x1; '
        'Mon, 06 Jul 2026 10:00:00 -0000',
        'from b.example.com (b.example.com [2.2.2.2]) by a.example.com with ESMTP id x2; '
        'Mon, 06 Jul 2026 09:00:00 +0200',
    ]
    result = received_chain.analyze_chain(chain)  # nesmí spadnout
    assert result['hop_count'] == 2
