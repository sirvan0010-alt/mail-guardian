"""
test_dns_whois.py
DNS wire-format parsování (RFC 1035) a WHOIS textové parsování -
testováno na ručně sestavených datech, ne živým síťovým provozem (viz
README v0.13 - tenhle sandbox nemá přístup na porty 43/53).
"""

import struct

import pytest

from modules import dns_lookup as dns
from modules import whois_lookup as wl


def _encode_name(name):
    out = b''
    for p in name.split('.'):
        out += bytes([len(p)]) + p.encode('ascii')
    return out + b'\x00'


def test_dns_parses_a_record():
    txid = 0x1234
    header = struct.pack('!HHHHHH', txid, 0x8180, 1, 1, 0, 0)
    question = _encode_name('example.com') + struct.pack('!HH', 1, 1)
    answer = struct.pack('!H', 0xC00C) + struct.pack('!HHIH', 1, 1, 300, 4) + bytes([93, 184, 216, 34])
    result = dns._parse_response(header + question + answer, txid, dns.QTYPE['A'])
    assert result['records'][0]['value'] == '93.184.216.34'
    assert result['records'][0]['ttl'] == 300


def test_dns_parses_mx_with_name_compression():
    """MX exchange pole s komprimovaným jménem (pointer) - klasický zdroj
    chyb DNS parserů."""
    txid = 0x5678
    header = struct.pack('!HHHHHH', txid, 0x8180, 1, 1, 0, 0)
    question = _encode_name('example.com') + struct.pack('!HH', 15, 1)
    mx_rdata = struct.pack('!H', 10) + bytes([4]) + b'mail' + struct.pack('!H', 0xC00C)
    answer = struct.pack('!H', 0xC00C) + struct.pack('!HHIH', 15, 1, 3600, len(mx_rdata)) + mx_rdata
    result = dns._parse_response(header + question + answer, txid, dns.QTYPE['MX'])
    assert result['records'][0]['value'] == 'mail.example.com'
    assert result['records'][0]['preference'] == 10


def test_dns_nxdomain_reported_as_error():
    txid = 0x9999
    header = struct.pack('!HHHHHH', txid, 0x8183, 1, 0, 0, 0)  # rcode=3
    question = _encode_name('nonexistent.example') + struct.pack('!HH', 1, 1)
    result = dns._parse_response(header + question, txid, dns.QTYPE['A'])
    assert 'NXDOMAIN' in result['error']


def test_dns_rejects_mismatched_transaction_id():
    txid = 0x1234
    header = struct.pack('!HHHHHH', txid, 0x8180, 1, 1, 0, 0)
    question = _encode_name('example.com') + struct.pack('!HH', 1, 1)
    answer = struct.pack('!H', 0xC00C) + struct.pack('!HHIH', 1, 1, 300, 4) + bytes([1, 2, 3, 4])
    with pytest.raises(ValueError):
        dns._parse_response(header + question + answer, 0x0000, dns.QTYPE['A'])


def test_dns_query_never_raises_on_timeout(monkeypatch):
    import socket as socket_module

    class TimeoutSocket:
        def __init__(self, *a, **kw): pass
        def settimeout(self, t): pass
        def sendto(self, d, a): pass
        def recvfrom(self, n): raise socket_module.timeout()
        def close(self): pass

    monkeypatch.setattr(socket_module, 'socket', lambda *a, **kw: TimeoutSocket())
    result = dns.query('test.com', 'A')
    assert result['records'] == []
    assert 'Timeout' in result['error']


# --- WHOIS ---

def test_whois_parses_iso_date_and_computes_age():
    text = 'Creation Date: 2026-07-01T10:00:00Z\nRegistrar: Cheap Registrar LLC\n'
    result = wl.parse_whois_text(text)
    assert result['registrar'] == 'Cheap Registrar LLC'
    assert result['domain_age_days'] is not None
    assert result['domain_age_days'] >= 0


def test_whois_parses_cz_lowercase_format():
    text = 'created:      2015-03-12 14:22:10\nregistrar:    REG-ACTIVE24\n'
    result = wl.parse_whois_text(text)
    assert result['domain_age_days'] > 3000


def test_whois_parses_british_dd_mmm_yyyy_format():
    """Regresní test bugu opraveného v v0.13 - regex pro 'Registered on:'
    ořízl datum na '15-' kvůli character class bez písmen."""
    text = 'Registered on: 15-Jan-2020\nRegistrar: Some Registrar Inc.\n'
    result = wl.parse_whois_text(text)
    assert result['creation_date'] == '15-Jan-2020'
    assert result['domain_age_days'] is not None


def test_whois_extracts_multiple_nameservers():
    text = 'nserver: ns1.example.com\nnserver: ns2.example.com\n'
    result = wl.parse_whois_text(text)
    assert result['name_servers'] == ['ns1.example.com', 'ns2.example.com']


def test_whois_missing_data_returns_none_fields_no_crash():
    result = wl.parse_whois_text('Some unrelated WHOIS boilerplate text.\n')
    assert result['available'] is True
    assert result['creation_date'] is None
    assert result['domain_age_days'] is None
