"""
test_threat.py
Threat skóre - kontrola, že čisté e-maily dostanou nízké/nulové skóre a
phishing/malware fixture vysoké, plus regresní test stropu 100 % se
všemi kombinacemi volitelných enrichmentů (AbuseIPDB/VirusTotal/WHOIS).
"""

from itertools import product

from conftest import build_fp
from modules import threat


def test_clean_gmail_email_has_zero_threat():
    fp = build_fp('gmail_clean.eml')
    assert fp['threat']['score_pct'] == 0.0


def test_clean_exchange_email_has_zero_threat():
    fp = build_fp('exchange_clean.eml')
    assert fp['threat']['score_pct'] == 0.0


def test_spoofed_phishing_has_high_threat():
    fp = build_fp('spoofed_phishing.eml')
    assert fp['threat']['score_pct'] >= 60.0
    assert fp['threat']['verdict'] in ('VYSOCE RIZIKOVÝ', 'PODEZŘELÝ')


def test_spoofed_phishing_findings_are_weight_annotated_and_sorted():
    fp = build_fp('spoofed_phishing.eml')
    findings = fp['threat']['findings']
    assert len(findings) >= 4
    assert all(f.startswith('+') for f in findings)
    weights = [int(f.split()[0].lstrip('+')) for f in findings]
    assert weights == sorted(weights, reverse=True)


def test_malware_attachment_flags_double_extension():
    fp = build_fp('malware_attachment.eml')
    assert fp['threat']['score_pct'] > 0
    assert any('dvojitou příponu' in f for f in fp['threat']['findings'])


def test_broken_chain_fixture_flags_broken_chain_signal():
    fp = build_fp('broken_chain.eml')
    assert 'broken_chain' in fp['threat']['breakdown']


def test_ceiling_never_exceeds_100_with_optional_enrichment():
    base = {
        'auth_explained': {'SPF': {'verdict': 'fail'}, 'DKIM': {'verdict': 'fail'}, 'DMARC': {'verdict': 'fail'}},
        'urls_detail': [{'mismatch': True}],
        'link_domains': ['paypaI.com'],
        'from_domain': 'evil.com',
        'attachments_detail': [{'filename': 'x.pdf.exe'}],
        'received_chain': {'anomalies': [{'type': 'broken_link'}]},
        'html_fingerprint': {'tracking_pixels': 1, 'hidden_elements': 1, 'form_count': 1,
                              'form_action_domains': ['x.com']},
    }
    max_seen = 0
    combos = 0
    for abuse_on, vt_on, whois_on, vturl_on, vtatt_on in product([False, True], repeat=5):
        fp = dict(base)
        fp['abuseipdb'] = {'available': True, 'abuse_confidence_score': 90, 'total_reports': 50} if abuse_on else None
        fp['virustotal'] = {'available': True, 'malicious_votes': 20, 'reputation_score': 50,
                             'harmless_votes': 20} if vt_on else None
        fp['whois'] = {'available': True, 'domain_age_days': 5} if whois_on else None
        fp['virustotal_urls'] = [{'url': 'http://evil.ru',
                                   'result': {'available': True, 'malicious_votes': 10}}] if vturl_on else []
        fp['virustotal_attachments'] = [{'filename': 'x.exe',
                                          'result': {'available': True, 'malicious_votes': 40}}] if vtatt_on else []
        result = threat.assess(fp)
        combos += 1
        max_seen = max(max_seen, result['score_pct'])
        assert result['score_pct'] <= 100.0

    assert combos == 32
    assert max_seen == 100.0


def test_empty_fingerprint_has_zero_threat_no_crash():
    result = threat.assess({})
    assert result['score_pct'] == 0.0
    assert result['findings'] == []
