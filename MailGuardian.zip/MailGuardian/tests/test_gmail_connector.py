"""
test_gmail_connector.py
Gmail konektor - čistá logika (bez sítě), lokální OAuth redirect server
(skutečný HTTP request na localhost, žádná externí síť), a Gmail API
volání s mockovaným urlopen. Živé OAuth přihlášení a skutečné stažení
z Gmailu tady otestovat nejde - viz docs/architecture.md a README.
"""

import base64
import json
import threading
import time
import urllib.error
import urllib.request
from unittest.mock import MagicMock, patch

import pytest

from modules import database, gmail_connector as gc


# --- Čistá logika ---

def test_generate_filename_format():
    name = gc.generate_eml_filename(1720000000000, b'test content')
    assert name.startswith('20240703_')
    assert name.endswith('.eml')


def test_generate_filename_no_date_fallback():
    assert gc.generate_eml_filename(0, b'x').startswith('unknown_date_')
    assert gc.generate_eml_filename(None, b'x').startswith('unknown_date_')


def test_generate_filename_deterministic_for_same_content():
    n1 = gc.generate_eml_filename(1720000000000, b'same content')
    n2 = gc.generate_eml_filename(1720000000000, b'same content')
    assert n1 == n2


def test_validate_sync_limit_rejects_over_max_allowed():
    with pytest.raises(ValueError):
        gc.validate_sync_limit(100000, 1000)


def test_validate_sync_limit_allows_within_range():
    gc.validate_sync_limit(50, 1000)  # nesmí vyhodit výjimku


@pytest.mark.parametrize('encoded', ['YWJj', 'YWJjZA', 'YWJjZGU', 'YWJjZGVm'])
def test_b64url_decode_handles_all_padding_remainders(encoded):
    """Base64 řetězce různých délek (remainder 0/1/2/3 po dělení 4) -
    ověří, že výpočet paddingu funguje pro všechny případy."""
    result = gc._b64url_decode(encoded)
    assert isinstance(result, bytes)
    assert len(result) > 0


# --- OAuth redirect server (skutečný HTTP request na localhost) ---

def _run_server_in_thread(port, timeout=5):
    result = {}

    def run():
        try:
            result['code'] = gc._wait_for_oauth_redirect(port=port, timeout=timeout)
        except Exception as e:
            result['error'] = e

    t = threading.Thread(target=run)
    t.start()
    time.sleep(0.3)
    return t, result


def test_oauth_redirect_server_captures_code():
    t, result = _run_server_in_thread(port=8781)
    resp = urllib.request.urlopen('http://localhost:8781/?code=TEST_CODE_ABC&scope=x')
    assert resp.status == 200
    t.join(timeout=5)
    assert result.get('code') == 'TEST_CODE_ABC'


def test_oauth_redirect_server_handles_access_denied():
    t, result = _run_server_in_thread(port=8782)
    urllib.request.urlopen('http://localhost:8782/?error=access_denied')
    t.join(timeout=5)
    assert isinstance(result.get('error'), PermissionError)
    assert 'access_denied' in str(result['error'])


def test_oauth_redirect_server_times_out():
    t0 = time.time()
    with pytest.raises(TimeoutError):
        gc._wait_for_oauth_redirect(port=8783, timeout=1)
    assert time.time() - t0 < 3


# --- Gmail API volání (mockovaný urlopen) ---

def _mock_response(data: dict):
    m = MagicMock()
    m.read.return_value = json.dumps(data).encode()
    m.__enter__ = lambda self: m
    m.__exit__ = lambda self, *a: None
    return m


def test_refresh_access_token_success():
    with patch('urllib.request.urlopen', return_value=_mock_response({'access_token': 'tok123'})):
        result = gc.refresh_access_token('cid', 'csecret', 'refresh_x')
        assert result['access_token'] == 'tok123'


def test_refresh_access_token_http_error_raises_permission_error():
    err = urllib.error.HTTPError('url', 400, 'Bad Request', {}, None)
    err.read = lambda: b'{"error": "invalid_grant"}'
    with patch('urllib.request.urlopen', side_effect=err):
        with pytest.raises(PermissionError):
            gc.refresh_access_token('cid', 'csecret', 'bad_refresh')


def test_list_messages_returns_message_list():
    with patch('urllib.request.urlopen', return_value=_mock_response({'messages': [{'id': 'a'}, {'id': 'b'}]})):
        result = gc.list_messages('token', 'label:INBOX', 10)
        assert len(result) == 2


def test_list_messages_http_error_returns_empty_list_no_crash():
    err = urllib.error.HTTPError('url', 401, 'Unauthorized', {}, None)
    with patch('urllib.request.urlopen', side_effect=err):
        result = gc.list_messages('badtoken', 'q', 10)
        assert result == []


def test_fetch_raw_message_decodes_content_and_date():
    raw = b'From: a@b.com\r\nSubject: x\r\n\r\nbody'
    encoded = base64.urlsafe_b64encode(raw).decode().rstrip('=')
    with patch('urllib.request.urlopen',
               return_value=_mock_response({'raw': encoded, 'internalDate': '1720000000000'})):
        raw_bytes, internal_date = gc.fetch_raw_message('token', 'msg1')
        assert raw_bytes == raw
        assert internal_date == 1720000000000


# --- Orchestrace + dedup (dependency injection, žádná síť) ---

def test_sync_downloads_new_and_skips_duplicates(tmp_path):
    conn = database.connect(str(tmp_path / 'test.db'))
    out_dir = str(tmp_path / 'gmail_out')

    def fake_list(token, query, max_results):
        return [{'id': 'm1'}, {'id': 'm2'}]

    def fake_fetch(token, msg_id):
        return f'From: a@b.com\nSubject: {msg_id}\n\nbody'.encode(), 1720000000000

    with patch.object(gc, 'get_access_token', return_value='faketoken'):
        first = gc.sync_gmail_emails(conn, 'cid', 'secret', 'q', 10, 1000, out_dir,
                                      list_fn=fake_list, fetch_fn=fake_fetch)
        assert len(first) == 2

        second = gc.sync_gmail_emails(conn, 'cid', 'secret', 'q', 10, 1000, out_dir,
                                       list_fn=fake_list, fetch_fn=fake_fetch)
        assert len(second) == 0  # dedup - stejné message_id už zpracované

    assert database.is_gmail_message_processed(conn, 'm1')
    assert database.is_gmail_message_processed(conn, 'm2')
    assert not database.is_gmail_message_processed(conn, 'm3')


def test_sync_respects_safety_limit(tmp_path):
    conn = database.connect(str(tmp_path / 'test.db'))
    with pytest.raises(ValueError):
        gc.sync_gmail_emails(conn, 'cid', 'secret', 'q', 999999, 1000, str(tmp_path / 'out'))


def test_sync_files_actually_written_with_correct_content(tmp_path):
    conn = database.connect(str(tmp_path / 'test.db'))
    out_dir = str(tmp_path / 'gmail_out')

    def fake_list(token, query, max_results):
        return [{'id': 'm1'}]

    def fake_fetch(token, msg_id):
        return b'From: sender@test.com\nSubject: Hello\n\nBody text', 1720000000000

    with patch.object(gc, 'get_access_token', return_value='faketoken'):
        downloaded = gc.sync_gmail_emails(conn, 'cid', 'secret', 'q', 10, 1000, out_dir,
                                           list_fn=fake_list, fetch_fn=fake_fetch)
    assert len(downloaded) == 1
    with open(downloaded[0], 'rb') as f:
        content = f.read()
    assert b'sender@test.com' in content
