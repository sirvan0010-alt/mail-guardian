"""
test_case_name_security.py
Path traversal ochrana pro jména case - nalezeno vlastní bezpečnostní
kontrolou (ne fuzzingem): 'case create ../../tmp/evil' by bez validace
vytvořilo složku KDEKOLIV, kam má proces právo zapisovat, ne jen uvnitř
cases/. Viz README v0.20 changelog.
"""

import os

import pytest

from modules import case as case_module


MALICIOUS_NAMES = [
    '../../../tmp/evil',
    '/etc/passwd',
    '..',
    '.',
    'a/b',
    'a\\b',
    '..\\..\\windows',
    '',
    '   ',
    'a\x00b',
    '/',
    '../',
    './..',
]

LEGITIMATE_NAMES = [
    'phishing_july',
    'auto_20260706_abc12345',
    'test-case_123',
    'kampan.2026',
    'CASE-01',
]


@pytest.mark.parametrize('name', MALICIOUS_NAMES)
def test_malicious_case_names_rejected(name):
    with pytest.raises(case_module.InvalidCaseName):
        case_module.case_dir(name)


@pytest.mark.parametrize('name', LEGITIMATE_NAMES)
def test_legitimate_case_names_accepted(name):
    result = case_module.case_dir(name)
    assert result == os.path.join(case_module.CASES_ROOT, name)


def test_traversal_name_never_creates_directory_outside_cases_root(tmp_path, monkeypatch):
    """End-to-end ověření - i kdyby validace v case_dir() nějak selhala,
    create_case() se zlomyslným jménem nesmí nikdy zapsat mimo
    CASES_ROOT. (Tenhle test by beze validace reálně vytvořil adresář
    v /tmp mimo tmp_path - přesně to, co se stalo při ručním ověření.)"""
    monkeypatch.setattr(case_module, 'CASES_ROOT', str(tmp_path / 'cases'))
    outside_marker = tmp_path.parent / 'should_not_exist_mailguardian_test'

    with pytest.raises(case_module.InvalidCaseName):
        case_module.create_case(f'../{outside_marker.name}')

    assert not outside_marker.exists()


def test_case_exists_rejects_malicious_name_without_creating_anything(tmp_path, monkeypatch):
    monkeypatch.setattr(case_module, 'CASES_ROOT', str(tmp_path / 'cases'))
    with pytest.raises(case_module.InvalidCaseName):
        case_module.case_exists('../escape')
