"""
test_homoglyph.py
IDN homograph a typosquat detekce - regresní sada reálných útočných
vzorů + kontrola, že legitimní domény nedávají false positive.
"""

from modules import homoglyph


def test_mixed_cyrillic_latin_microsoft_detected():
    findings = homoglyph.analyze_domain('micr\u043esoft.com')
    types = {f['type'] for f in findings}
    assert 'mixed_script' in types
    assert 'typosquat_candidate' in types


def test_pure_cyrillic_paypal_detected_via_confusables():
    """Plně cyrilická doména bez namíchané latinky - jediný způsob, jak
    ji odhalit, je confusables normalizace (viz README v0.4 changelog,
    kde byl tenhle případ původně nedetekovaný bug)."""
    findings = homoglyph.analyze_domain('\u0440\u0430\u0443\u0440\u0430\u043b.com')
    types = {f['type'] for f in findings}
    assert 'confusable_homoglyph' in types


def test_typosquat_capital_i_for_lowercase_l():
    findings = homoglyph.analyze_domain('paypaI.com')
    assert any(f['type'] == 'typosquat_candidate' for f in findings)


def test_punycode_domain_decoded_and_flagged():
    findings = homoglyph.analyze_domain('xn--80ak6aa92e.com')
    assert len(findings) > 0


def test_legitimate_known_domain_is_clean():
    assert homoglyph.analyze_domain('google.com') == []
    assert homoglyph.analyze_domain('seznam.cz') == []


def test_unrelated_domain_is_clean():
    assert homoglyph.analyze_domain('completely-unrelated-startup.io') == []


def test_empty_domain_does_not_crash():
    assert homoglyph.analyze_domain('') == []
    assert homoglyph.analyze_domain(None) == []
