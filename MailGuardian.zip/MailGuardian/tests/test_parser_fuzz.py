"""
test_parser_fuzz.py
Fuzzing testy parseru přes hypothesis - cíl je najít vstupy, na kterých
parser SPADNE (vyhodí neočekávanou výjimku), ne ověřovat konkrétní
výstupní hodnoty. Parser musí být odolný vůči jakémukoliv bajtovému
vstupu (poškozený/zlomyslně sestavený .eml), i když z něj třeba nedokáže
vytáhnout smysluplná data - pád celého programu na jednom rozbitém
souboru je vždycky bug.

Vyžaduje `hypothesis` (viz requirements-dev.txt) - pokud není
nainstalovaný, testy v tomhle souboru se přeskočí.
"""

import os
import tempfile

import pytest

pytest.importorskip('hypothesis', reason="hypothesis není nainstalovaný - fuzzing testy se přeskakují")

from hypothesis import HealthCheck, given, settings, strategies as st  # noqa: E402

from modules import parser  # noqa: E402


def _parse_bytes(content: bytes):
    """Napíše bajty do dočasného .eml a zavolá parser - vrátí výsledek,
    nebo znovu vyhodí výjimku (test ji zachytí a nahlásí jako selhání)."""
    with tempfile.NamedTemporaryFile(suffix='.eml', delete=False, mode='wb') as f:
        f.write(content)
        path = f.name
    try:
        return parser.parse_eml(path)
    finally:
        os.remove(path)


@settings(max_examples=200, suppress_health_check=[HealthCheck.too_slow], deadline=None)
@given(st.binary(max_size=2000))
def test_parser_never_crashes_on_arbitrary_bytes(content):
    """Úplně náhodné bajty (většina nebude ani vypadat jako e-mail) -
    parser se musí vždy vrátit s nějakým (byť prázdným/nesmyslným)
    výsledkem, ne spadnout."""
    try:
        result = _parse_bytes(content)
        assert isinstance(result, dict)
    except Exception as e:
        pytest.fail(f"Parser spadl na náhodných bajtech {content!r}: {type(e).__name__}: {e}")


# Cílenější fuzzing - vezme rozumné "kostry" hlaviček a naplní je
# náhodným/uťatým textem, ať se trefí do zajímavějších okrajových
# případů rychleji než čistě náhodné bajty (které skoro nikdy nevytvoří
# nic, co se vůbec podobá hlavičce).
ADDRESS_HEADER_NAMES = st.sampled_from(['From', 'To', 'Cc', 'Bcc', 'Reply-To', 'Sender'])
TRUNCATED_ADDRESS_VALUES = st.sampled_from([
    'Jméno <', 'Jméno <a', 'Jméno <a@', 'Jméno <a@b', '<', '<>', '"unterminated quote <a@b.com>',
    'a@b.com, ', 'a@b.com, <', ', , ,', '<<<<<', '>>>>', '@', '@@@',
    'undisclosed-recipients:;', 'group:;', 'group: a@b.com, c@d.com;', 'group:',
])


@settings(max_examples=100, deadline=None)
@given(header_name=ADDRESS_HEADER_NAMES, header_value=TRUNCATED_ADDRESS_VALUES)
def test_parser_survives_truncated_address_headers(header_name, header_value):
    """Cíleně zkouší uťaté/rozbité adresové hlavičky (From/To/Cc/...) -
    tohle je přesná třída vstupu, na které stdlib email._header_value_parser
    umí spadnout s IndexError (viz oprava v parser.py - _raw_header_values
    fallback)."""
    content = f"{header_name}: {header_value}\nSubject: fuzz test\n\nbody".encode('utf-8', errors='replace')
    try:
        result = _parse_bytes(content)
        assert isinstance(result, dict)
    except Exception as e:
        pytest.fail(f"Parser spadl na {header_name}: {header_value!r} -> {type(e).__name__}: {e}")


MALFORMED_STRUCTURE_SAMPLES = st.sampled_from([
    b'',  # prazdny soubor
    b'\x00\x01\x02\x03',  # ciste binarni smeti
    b'From: a@b.com',  # zadne prazdne radky, zadne telo
    b'From: a@b.com\n\n',  # jen hlavicka + prazdne telo
    b'Content-Type: multipart/mixed; boundary="x"\n\n--x\nbroken',  # nedokoncene multipart
    b'Content-Type: multipart/mixed; boundary=\n\nbody',  # prazdny boundary
    b'Received: ' + b'a' * 5000,  # extremne dlouha hlavicka
    b'Subject: =?utf-8?b?????invalid-base64?=\n\nbody',  # rozbite MIME encoded-word
    b'From: a@b.com\nFrom: c@d.com\nFrom: e@f.com\n\nbody',  # duplicitni hlavicky
    'Předmět: český text s háčky a čárkami řžčšťďň\n\nbody'.encode('utf-8'),
    b'Message-ID: <\x00\x01@x>\n\nbody',  # nulovy bajt v Message-ID
])


@settings(max_examples=50, deadline=None)
@given(content=MALFORMED_STRUCTURE_SAMPLES)
def test_parser_survives_malformed_structure(content):
    """Různé strukturálně rozbité/neobvyklé .eml vstupy - prázdný soubor,
    binární smetí, nedokončený multipart, extrémně dlouhé hlavičky,
    rozbité MIME encoded-words, duplicitní hlavičky, nulové bajty."""
    try:
        result = _parse_bytes(content)
        assert isinstance(result, dict)
    except Exception as e:
        pytest.fail(f"Parser spadl na {content[:80]!r}... -> {type(e).__name__}: {e}")


def test_regression_truncated_from_header_no_crash():
    """Konkrétní regresní test na bug nalezený fuzzingem a opravený v
    parser.py - '<' bez ukončení v adresové hlavičce dřív vyhazovalo
    IndexError přímo z cpython stdlib parseru (email._header_value_parser.
    get_angle_addr), teď se to zachytí a spadne zpět na syrový text."""
    content = b'From: Jmeno <\nSubject: test\n\nbody'
    result = _parse_bytes(content)
    assert result['from'] == ''  # neplatná adresa - prázdné, ne pád


def test_regression_group_address_no_crash():
    """Regresní test na druhý bug nalezený mutation-based fuzzingem (viz
    README v0.19 changelog) - RFC 5322 'group' adresová syntaxe
    (např. 'undisclosed-recipients:;', běžně používaná k skrytí seznamu
    příjemců) vyhazovala AttributeError ('Group' object has no attribute
    'local_part') z cpython stdlib parseru - jiný typ výjimky než u
    uťaté adresy výše, proto byl potřeba širší except Exception, ne jen
    vyjmenované typy."""
    content = b'To: undisclosed-recipients:;\nFrom: a@b.com\nSubject: test\n\nbody'
    result = _parse_bytes(content)
    assert isinstance(result, dict)


def _iterative_nested_multipart(depth: int) -> bytes:
    """Sestaví hluboce vnořený multipart ITERATIVNĚ (ne rekurzivně) - ať
    samotný test generátor nenarazí na Python recursion limit dřív, než
    se vůbec dostane k testování parseru."""
    body = b'Content-Type: text/plain\n\nleaf body'
    for i in range(depth):
        boundary = f'b{i}'.encode()
        body = (b'Content-Type: multipart/mixed; boundary="' + boundary + b'"\n\n--' + boundary + b'\n'
                + body + b'\n--' + boundary + b'--')
    return body


def test_large_attachment_triggers_memory_warning(caplog):
    """Regresní test na v0.22 nález - Python stdlib email parser
    (`message_from_bytes()` pod `policy.default`) spotřebuje cca 15x
    víc RAM, než je velikost .eml souboru (ověřeno měřením: 20MB soubor
    -> ~300MB peak, uvnitř stdlib, ne v našem kódu - nejde to opravit
    bez architektonické změny). U nástroje analyzujícího potenciálně
    zlomyslné e-maily je to reálné DoS riziko - přidán transparentní
    warning nad LARGE_FILE_WARNING_THRESHOLD_MB, ne blokování (obří
    příloha může být legitimní důkaz)."""
    import base64
    import logging

    raw_bytes = b'x' * (25 * 1024 * 1024)  # 25MB > 20MB práh
    b64 = base64.b64encode(raw_bytes)
    content = (b'From: a@b.com\r\nSubject: test\r\nMessage-ID: <x@test.com>\r\n'
               b'Content-Type: multipart/mixed; boundary="X"\r\n\r\n'
               b'--X\r\nContent-Type: text/plain\r\n\r\ntest\r\n'
               b'--X\r\nContent-Type: application/octet-stream\r\n'
               b'Content-Disposition: attachment; filename="big.bin"\r\n'
               b'Content-Transfer-Encoding: base64\r\n\r\n' + b64 + b'\r\n--X--')

    logging.getLogger('mailguardian').setLevel(logging.WARNING)
    with caplog.at_level(logging.WARNING, logger='mailguardian.parser'):
        _parse_bytes(content)

    assert any('15x' in r.message or 'RAM' in r.message for r in caplog.records)


def test_small_email_does_not_trigger_memory_warning(caplog):
    import logging
    logging.getLogger('mailguardian').setLevel(logging.WARNING)
    with caplog.at_level(logging.WARNING, logger='mailguardian.parser'):
        _parse_bytes(b'From: a@b.com\nSubject: small\n\nbody')
    assert len(caplog.records) == 0


def test_regression_extremely_deep_multipart_raises_controlled_error():
    """Regresní test na třetí bug nalezený MIME fuzzingem (viz README
    v0.21 changelog) - extrémně hluboce vnořený multipart (~1000+ úrovní)
    vyčerpá Python rekurzní limit UVNITŘ `email.message_from_bytes()`
    samotné (stdlib), tedy dřív, než se spustí jakýkoliv náš kód -
    hloubkový limit v modules/mime_fp.py (MAX_MIME_DEPTH) tohle
    nezachytí. Musí to skončit kontrolovanou `UnparseableEmailError`
    (parser.py), ne nezachyceným `RecursionError`."""
    content = _iterative_nested_multipart(1000)
    with tempfile.NamedTemporaryFile(suffix='.eml', delete=False, mode='wb') as f:
        f.write(content)
        path = f.name
    try:
        with pytest.raises(parser.UnparseableEmailError):
            parser.parse_eml(path)
    finally:
        os.remove(path)


def test_moderately_deep_multipart_still_parses_correctly():
    """Ne všechno hluboké zanoření je 'příliš hluboké' - do MAX_MIME_DEPTH
    (50 úrovní v mime_fp.py) se musí pořád naparsovat normálně, jen
    extrémní případy (1000+) mají skončit řízenou chybou."""
    content = _iterative_nested_multipart(20)
    with tempfile.NamedTemporaryFile(suffix='.eml', delete=False, mode='wb') as f:
        f.write(content)
        path = f.name
    try:
        result = parser.parse_eml(path)
        assert 'multipart/mixed' in result['mime_fingerprint']['structure']
    finally:
        os.remove(path)
