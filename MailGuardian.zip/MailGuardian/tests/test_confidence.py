"""
test_confidence.py
Confidence skóre - kolik využitelných dat máme, ne jak podobný/nebezpečný
je e-mail. Bohatý fixture (kompletní hlavičky) by měl mít vyšší confidence
než minimální (skoro žádné hlavičky).
"""

from conftest import build_fp


def test_minimal_bare_has_low_confidence():
    fp = build_fp('minimal_bare.eml')
    assert fp['confidence']['score_pct'] < 30.0
    assert fp['confidence']['verdict'].startswith('NÍZKÁ')


def test_gmail_clean_has_higher_confidence_than_minimal():
    rich = build_fp('gmail_clean.eml')
    minimal = build_fp('minimal_bare.eml')
    assert rich['confidence']['score_pct'] > minimal['confidence']['score_pct']


def test_explain_list_covers_every_weight_key():
    from modules.confidence import CONFIDENCE_WEIGHTS
    fp = build_fp('gmail_clean.eml')
    explain = fp['confidence']['explain']
    assert len(explain) == len(CONFIDENCE_WEIGHTS)


def test_missing_items_show_zero_with_potential():
    fp = build_fp('minimal_bare.eml')
    missing_lines = [line for line in fp['confidence']['explain'] if line.startswith('+0')]
    assert len(missing_lines) > 0
    assert all('možných' in line for line in missing_lines)
