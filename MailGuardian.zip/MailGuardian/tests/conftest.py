"""
conftest.py
Sdílené pytest fixtures pro celou testovací sadu. Přidává kořen projektu
do sys.path (main.py/modules/ nejsou nainstalovaný balíček) a poskytuje
pohodlné fixtures na cesty k ukázkovým .eml a hotové fingerprinty.
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest

FIXTURES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'fixtures', 'eml')


def eml_path(name: str) -> str:
    return os.path.join(FIXTURES_DIR, name)


@pytest.fixture
def fixtures_dir():
    return FIXTURES_DIR


@pytest.fixture(params=[
    'gmail_clean.eml',
    'exchange_clean.eml',
    'postfix_newsletter.eml',
    'spoofed_phishing.eml',
    'malware_attachment.eml',
    'broken_chain.eml',
    'minimal_bare.eml',
])
def any_fixture_path(request):
    """Parametrizovaná fixture - testy použivající tohle se spustí jednou
    pro KAŽDÝ vzorový e-mail (užitečné pro 'nikdy to nespadne' testy)."""
    return eml_path(request.param)


@pytest.fixture
def parsed(request):
    """Použití: @pytest.mark.parametrize('parsed', ['gmail_clean.eml'], indirect=True)"""
    from modules import parser
    return parser.parse_eml(eml_path(request.param))


def build_fp(filename: str, **kwargs):
    """Pohodlná pomocná funkce (ne fixture) - naparsuje a otiskne jeden
    vzorový e-mail. enable_geoip=False, ať testy nezávisí na tom, jestli
    má prostředí nainstalovaný GeoLite2."""
    from modules import parser, fingerprint
    parsed_email = parser.parse_eml(eml_path(filename))
    return fingerprint.build_fingerprint(parsed_email, enable_geoip=False, **kwargs)
