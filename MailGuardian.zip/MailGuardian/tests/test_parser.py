"""
test_parser.py
Parser by nikdy neměl spadnout na žádném z fixture e-mailů, a klíčová
pole by měla sedět na známé hodnoty (regresní ochrana).
"""

from conftest import eml_path
from modules import parser


def test_parses_all_fixtures_without_crashing(any_fixture_path):
    result = parser.parse_eml(any_fixture_path)
    assert result['filepath'] == any_fixture_path
    assert isinstance(result['received_ips'], list)
    assert isinstance(result['urls'], list)
    assert isinstance(result['attachments'], list)


def test_gmail_fixture_fields():
    r = parser.parse_eml(eml_path('gmail_clean.eml'))
    assert r['from'] == 'jana.novakova@gmail.com'
    assert r['primary_ip'] == '209.85.161.41'
    assert r['auth_results'].get('SPF') == 'pass'
    assert r['message_id_fingerprint']['generator_guess'] == 'Gmail (Google)'


def test_exchange_fixture_message_id_generator():
    r = parser.parse_eml(eml_path('exchange_clean.eml'))
    assert r['message_id_fingerprint']['generator_guess'] == 'Microsoft Exchange/Outlook'


def test_postfix_newsletter_has_unsubscribe_link():
    r = parser.parse_eml(eml_path('postfix_newsletter.eml'))
    urls = [u['url'] for u in r['urls']]
    assert any('unsubscribe' in u for u in urls)
    assert r['link_domains'] == ['obchod-example.cz']


def test_spoofed_phishing_auth_all_fail():
    r = parser.parse_eml(eml_path('spoofed_phishing.eml'))
    assert r['auth_results'].get('SPF') == 'fail'
    assert r['auth_results'].get('DKIM') == 'fail'
    assert r['auth_results'].get('DMARC') == 'fail'


def test_spoofed_phishing_url_mismatch_detected():
    r = parser.parse_eml(eml_path('spoofed_phishing.eml'))
    mismatched = [u for u in r['urls'] if u.get('mismatch')]
    assert len(mismatched) >= 1


def test_spoofed_phishing_tracking_pixel_and_form_detected():
    r = parser.parse_eml(eml_path('spoofed_phishing.eml'))
    assert r['html_fingerprint']['tracking_pixels'] >= 1
    assert r['html_fingerprint']['form_count'] >= 1
    assert r['html_fingerprint']['hidden_elements'] >= 1


def test_malware_attachment_hash_present():
    r = parser.parse_eml(eml_path('malware_attachment.eml'))
    assert len(r['attachments']) == 1
    assert r['attachments'][0]['filename'] == 'Faktura_2026-0713.pdf.exe'
    assert len(r['attachments'][0]['sha256']) == 64  # platný SHA-256 hex digest


def test_broken_chain_anomaly_detected():
    r = parser.parse_eml(eml_path('broken_chain.eml'))
    anomaly_types = {a['type'] for a in r['received_chain']['anomalies']}
    assert 'broken_link' in anomaly_types


def test_minimal_bare_has_no_received_ips():
    r = parser.parse_eml(eml_path('minimal_bare.eml'))
    assert r['received_ips'] == []
    assert r['primary_ip'] is None


def test_deterministic_parse_same_file_twice():
    """Stejný soubor naparsovaný dvakrát musí dát bitově identický výsledek
    (viz Evidence mode / v0.9) - jinak nejde fingerprint hashovat jako důkaz."""
    import json
    r1 = parser.parse_eml(eml_path('gmail_clean.eml'))
    r2 = parser.parse_eml(eml_path('gmail_clean.eml'))
    assert json.dumps(r1, sort_keys=True, default=str) == json.dumps(r2, sort_keys=True, default=str)
