"""
test_app_gui.py
Headless smoke test pro app.py (Streamlit GUI) přes streamlit.testing.v1.AppTest
- skutečně spustí aplikaci (ne jen syntax check), simuluje kliknutí mezi
stránkami a nahrání souboru, ověří že to projde beze výjimky a že se
výsledek skutečně zapíše do databáze stejnou cestou jako CLI.

Vyžaduje `streamlit` (viz requirements-gui.txt) - pokud není nainstalovaný,
testy v tomhle souboru se přeskočí, ne selžou (GUI je volitelná
nadstavba, ne jádro nástroje).
"""

import os

import pytest
from conftest import eml_path

pytest.importorskip('streamlit', reason="streamlit není nainstalovaný - GUI testy se přeskakují "
                                         "(viz requirements-gui.txt)")

from streamlit.testing.v1 import AppTest  # noqa: E402

APP_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'app.py')

PAGES = [
    '📥 Přidat e-maily',
    '📊 Databáze',
    '🔍 Porovnat',
    '🗂️ Case mode',
    '📦 Evidence Bundle',
]


def test_app_starts_without_exception():
    at = AppTest.from_file(APP_PATH)
    at.run(timeout=30)
    assert at.exception == []


@pytest.mark.parametrize('page_name', PAGES)
def test_each_page_loads_without_exception(page_name):
    at = AppTest.from_file(APP_PATH)
    at.run(timeout=30)
    at.radio[0].set_value(page_name).run(timeout=30)
    assert at.exception == [], f"Stránka '{page_name}' vyhodila výjimku: {at.exception}"


def test_eml_help_expander_present_on_add_page():
    """Nápověda 'jak získám .eml soubor' (Gmail/Outlook/Seznam postup) se
    musí zobrazit vedle hlavního uploadu - přidáno na žádost uživatele
    (v0.23), ať není nutné hledat postup v README."""
    at = AppTest.from_file(APP_PATH)
    at.run(timeout=30)
    at.radio[0].set_value('📥 Přidat e-maily').run(timeout=30)
    labels = [e.label for e in at.expander]
    assert any('Jak získám' in label for label in labels)


def test_eml_help_mentions_format_and_size_guidance():
    """Rozšíření v0.24 - nápověda musí zmínit podporovaný formát (.eml,
    ne .msg/PDF/screenshot) a orientační velikostní práh, ne jen postup
    stažení. Hodnota prahu se musí dosadit ze skutečné konstanty
    (LARGE_FILE_WARNING_THRESHOLD_MB v modules/parser.py), ne být
    natvrdo napsaná v app.py odděleně - jinak by se časem rozjely."""
    from modules import parser as eml_parser

    at = AppTest.from_file(APP_PATH)
    at.run(timeout=30)
    at.radio[0].set_value('📥 Přidat e-maily').run(timeout=30)

    all_text = ' '.join(m.value for m in at.markdown)
    assert '.eml' in all_text
    assert '.msg' in all_text  # explicitně vyloučený formát
    assert f'{eml_parser.LARGE_FILE_WARNING_THRESHOLD_MB}MB' in all_text


def test_eml_help_expander_present_on_bundle_page():
    at = AppTest.from_file(APP_PATH)
    at.run(timeout=30)
    at.radio[0].set_value('📦 Evidence Bundle').run(timeout=30)
    labels = [e.label for e in at.expander]
    assert any('Jak získám' in label for label in labels)


def test_eml_help_expander_present_on_case_mode_tabs(tmp_path, monkeypatch):
    """Case mode má dvě záložky s vlastním uploadem (přidat do case /
    navrhnout case) - nápověda musí být u obou, ne jen u jedné. 'Vytvořit
    / přidat' záložka ukazuje upload jen když existuje aspoň jeden case,
    proto se tu jeden zakládá (jinak by se ta větev vůbec neprovedla a
    test by falešně prošel i bez nápovědy tam)."""
    from modules import case as case_module
    monkeypatch.setattr(case_module, 'CASES_ROOT', str(tmp_path / 'cases'))
    case_module.create_case('help_test_case')

    at = AppTest.from_file(APP_PATH)
    at.run(timeout=30)
    at.radio[0].set_value('🗂️ Case mode').run(timeout=30)
    labels = [e.label for e in at.expander]
    help_count = sum(1 for label in labels if 'Jak získám' in label)
    assert help_count == 2, f"Očekávány 2 nápovědy (case add + suggest), nalezeno {help_count}"


def _cleanup_real_project_state():
    """DB_PATH i UPLOAD_DIR jsou ukotvené k umístění main.py/app.py (ne k
    cwd), takže testy, co nahrávají soubory a zpracovávají je, zapisují
    do SKUTEČNÉHO projektového stavu - je potřeba to po sobě uklidit
    stejně pečlivě jako testy, co používají tmp_path."""
    import main as cli_main
    import app as app_module

    if os.path.exists(cli_main.DB_PATH):
        os.remove(cli_main.DB_PATH)
    if os.path.isdir(app_module.UPLOAD_DIR):
        for f in os.listdir(app_module.UPLOAD_DIR):
            os.remove(os.path.join(app_module.UPLOAD_DIR, f))


def test_upload_and_process_writes_to_database():
    """Nahraje fixture e-mail přes GUI file_uploader a klikne na
    zpracování - ověří, že se skutečně zapíše do databáze stejnou cestou
    jako `python3 main.py add` (žádná duplicitní logika)."""
    import main as cli_main
    from modules import database

    _cleanup_real_project_state()

    with open(eml_path('spoofed_phishing.eml'), 'rb') as f:
        content = f.read()

    try:
        at = AppTest.from_file(APP_PATH)
        at.run(timeout=30)
        at.radio[0].set_value('📥 Přidat e-maily').run(timeout=30)
        at.file_uploader[0].upload('spoofed_phishing.eml', content, 'message/rfc822').run(timeout=30)
        assert len(at.button) > 0, "Po nahrání souboru chybí tlačítko pro zpracování"
        at.button[0].click().run(timeout=30)

        assert at.exception == []

        conn = database.connect(cli_main.DB_PATH)
        emails = database.get_all_emails(conn)
        assert len(emails) == 1
        assert emails[0]['fingerprint']['threat']['score_pct'] > 0
    finally:
        _cleanup_real_project_state()


def test_upload_shows_threat_and_confidence_metrics():
    _cleanup_real_project_state()

    with open(eml_path('spoofed_phishing.eml'), 'rb') as f:
        content = f.read()

    try:
        at = AppTest.from_file(APP_PATH)
        at.run(timeout=30)
        at.radio[0].set_value('📥 Přidat e-maily').run(timeout=30)
        at.file_uploader[0].upload('spoofed_phishing.eml', content, 'message/rfc822').run(timeout=30)
        at.button[0].click().run(timeout=30)

        metric_labels = {m.label for m in at.metric}
        assert any('Threat' in label for label in metric_labels)
        assert any('Confidence' in label for label in metric_labels)
    finally:
        _cleanup_real_project_state()


def test_case_mode_page_shows_existing_case(tmp_path, monkeypatch):
    """Case založený přes CLI (`case add`) se musí objevit v GUI - jde o
    stejnou databázi/adresářovou strukturu, ne o oddělený stav.

    Pozn.: case_module.CASES_ROOT je taky ukotvená k umístění projektu
    (ne k cwd - viz oprava v case.py), takže se tu izoluje přes
    monkeypatch.setattr přímo, stejně jako ve zbytku testovací sady
    (test_case.py/test_case_auto_assign.py), ne přes chdir."""
    from modules import case as case_module, database, parser, fingerprint as fp_module
    import shutil

    monkeypatch.setattr(case_module, 'CASES_ROOT', str(tmp_path / 'cases'))

    case_module.create_case('gui_test_case')
    conn = database.connect(case_module.case_db_path('gui_test_case'))
    dest = os.path.join(case_module.case_originals_dir('gui_test_case'), 'spoofed_phishing.eml')
    shutil.copy2(eml_path('spoofed_phishing.eml'), dest)
    parsed = parser.parse_eml(dest)
    fp = fp_module.build_fingerprint(parsed, enable_geoip=False)
    database.store_email(conn, parsed, fp)

    at = AppTest.from_file(APP_PATH)
    at.run(timeout=30)
    at.radio[0].set_value('🗂️ Case mode').run(timeout=30)

    assert at.exception == []
    all_options = [opt for sb in at.selectbox for opt in sb.options]
    assert 'gui_test_case' in all_options


def test_uploaded_filename_path_traversal_stays_inside_upload_dir():
    """Bezpečnostní regresní test (v0.21) - `uploaded_file.name` je
    string, kterým se prohlížeč klienta chlubí, plně pod kontrolou toho,
    kdo GUI používá. Bez sanitizace by `../../../tmp/evil.eml` jako
    název nahraného souboru zapsal MIMO emails/uploaded/ (ověřeno ručně -
    kvůli neexistujícímu cílovému adresáři to tehdy selhalo náhodou, ne
    díky ochraně). Po opravě (`os.path.basename()` + explicitní kontrola
    '.'/'..'  v app.py `save_uploaded_file()`) musí soubor vždy skončit
    uvnitř UPLOAD_DIR, bez ohledu na název."""
    import app as app_module

    if os.path.isdir(app_module.UPLOAD_DIR):
        for f in os.listdir(app_module.UPLOAD_DIR):
            os.remove(os.path.join(app_module.UPLOAD_DIR, f))
    else:
        os.makedirs(app_module.UPLOAD_DIR, exist_ok=True)

    class FakeUploadedFile:
        def __init__(self, name, data):
            self.name = name
            self._data = data

        def getvalue(self):
            return self._data

    try:
        fake = FakeUploadedFile('../../../tmp/evil_traversal_regression.eml', b'test content')
        dest = app_module.save_uploaded_file(fake, app_module.UPLOAD_DIR)

        assert os.path.dirname(os.path.abspath(dest)) == os.path.abspath(app_module.UPLOAD_DIR)
        assert not os.path.exists('/tmp/evil_traversal_regression.eml')

        # '..' bez lomítek - basename() samo o sobě tohle nezachytí
        fake2 = FakeUploadedFile('..', b'test content 2')
        dest2 = app_module.save_uploaded_file(fake2, app_module.UPLOAD_DIR)
        assert os.path.dirname(os.path.abspath(dest2)) == os.path.abspath(app_module.UPLOAD_DIR)
    finally:
        if os.path.isdir(app_module.UPLOAD_DIR):
            for f in os.listdir(app_module.UPLOAD_DIR):
                os.remove(os.path.join(app_module.UPLOAD_DIR, f))


def test_extremely_deep_mime_upload_shows_error_not_hang():
    """Regresní test na v0.21 nález - nahrání extrémně hluboce
    vnořeného multipart (~1000+ úrovní, vyčerpá Python rekurzní limit
    UVNITŘ stdlib email parseru) dřív způsobilo, že `cli._process_file()`
    interně volalo `sys.exit()`, což ve Streamlitu vedlo k zaseknutí
    celého skriptu na timeout (ověřeno ručně - AppTest.run() timeoutoval
    po 30s), ne k hezké chybě. Po opravě (UnparseableEmailError se jen
    vyhodí, sys.exit() se nevolá, GUI volací místa ji odchytávají a
    zobrazí st.error()) musí doběhnout rychle a bez neošetřené výjimky."""
    def iterative_nested_multipart(depth):
        body = b'Content-Type: text/plain\n\nleaf body'
        for i in range(depth):
            boundary = f'b{i}'.encode()
            body = (b'Content-Type: multipart/mixed; boundary="' + boundary + b'"\n\n--' + boundary + b'\n'
                    + body + b'\n--' + boundary + b'--')
        return body

    content = iterative_nested_multipart(1000)

    at = AppTest.from_file(APP_PATH)
    at.run(timeout=30)
    at.radio[0].set_value('📥 Přidat e-maily').run(timeout=30)
    at.file_uploader[0].upload('deeply_nested_evil.eml', content, 'message/rfc822').run(timeout=15)
    at.button[0].click().run(timeout=15)  # dřív by tohle timeoutovalo na 30s

    assert at.exception == []
    assert any('příliš komplexní' in e.value for e in at.error)
